# PREFLOW on EComAgentBench

## Setup
1. Clone EComAgentBench at the commit in `patches/UPSTREAM_COMMIT`, then follow its instructions to download the product database and benchmark data.
2. Copy `src/`, `scripts/` and `configs/` from this folder into the clone, and apply `patches/upstream_llm.patch` (OpenRouter provider routing and an optional spending guard).
3. Set `OPENROUTER_API_KEY`.

## Files
- `src/prediction/preflow_compact_agent_v11.py`: the PREFLOW agent reported in the paper (it builds on `preflow_compact_agent_v9.py` and `_v9_1.py`), with `src/preflow/` (search ranking, evidence state) and `src/prompts/preflow_compact_v11.py`.
- `src/prediction/run_baseline_manifest.py`, `agent_gemini_safe.py`: run the benchmark's own agent with another LLM, unchanged except that a turn with several tool calls is replayed unedited, so Gemini's thought signatures stay valid.
- `src/llm/budget.py`: an optional cross-process spending cap.

## Reproducing the results
| Result | Command |
|---|---|
| All 662 tasks (accuracy, preference satisfaction, model calls) | `python scripts/run_preflow.py predict --split all662 --workers 4`, then `score`, then `report` |
| Same-LLM comparison, 100 held-out tasks: PREFLOW | the same predictions (the task IDs are in `configs/compare100_test_seed20261019.json`); judged with `scripts/run_compare100.py score --rubrics` |
| Same-LLM comparison: benchmark agent | `python -m src.prediction.run_baseline_manifest --config configs/compare100_paper_agent_gemini.yaml --manifest configs/compare100_test_seed20261019.json --output <file>` |
| Comparison table | `python scripts/compare100_table.py` |
| Outcome-and-evidence figure | `python scripts/make_ecom_outcome_evidence_full662.py` |

