#!/usr/bin/env python3
"""
Analyze one preference-aware WebShop log without plotting figures.

The script produces two analyses:

1. Performance versus LASER-style trajectory length.
   The primary trajectory length counts high-level controller transitions:
     - search
     - selecting/opening a product
     - leaving a product page via Back/Prev
     - committing via Buy Now
     - result-page navigation such as Next/Prev, inferred from result-page arrivals

   Product-page inspections and Safe Option Selection clicks are reported
   separately, but are not included in the primary trajectory length. This
   preserves the interpretation that search -> select -> buy has length 3.

   Episodes that reach deadline-aware Best-Seen Recovery are placed in a
   separate "forced-stop" group, matching the role of LASER's maximum-length
   group.

2. Performance versus number of user preferences.
   For post-hoc evaluation, the count is read from the logged WebShop gold
   schema:
       1 product type
       + number of gold attributes
       + number of gold selectable options
       + 1 price constraint when present

   Gold fields are used only to calculate evaluation statistics; they are not
   inputs to the agent.

Outputs:
  <prefix>_episodes.csv
  <prefix>_trajectory_exact.csv
  <prefix>_trajectory_bins.csv
  <prefix>_preference_count.csv
  <prefix>_preference_bins.csv
  <prefix>_summary.json

Only the Python standard library is required.
"""

from __future__ import annotations

import argparse
import ast
import csv
import json
import math
import re
import statistics
import sys
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Iterable, Optional, Sequence


NUMBER = r"[-+]?(?:\d+(?:\.\d*)?|\.\d+)"
NULLABLE_VALUE = rf"(?:{NUMBER}|n/a|none|null|nan)"

# Canonical raw WebShop logs mirror INFO messages in un-timestamped console output.
# Analyze only timestamped INFO records to avoid double-counting episodes.
INFO_RE = re.compile(r"^\d{4}-\d\d-\d\d .*? - INFO - (.*)$")

EPISODE_START_RE = re.compile(
    r"\[Episode\]\s+start\s+(?P<episode>\d+)", re.IGNORECASE
)
EPISODE_END_RE = re.compile(
    rf"\[Episode\]\s+end\s+reward=(?P<reward>{NUMBER})\s+"
    r"success=(?P<success>True|False)",
    re.IGNORECASE,
)
REWARD_BREAKDOWN_RE = re.compile(
    rf"""
    \[Reward\ Breakdown\]
    .*?r_type\((?P<type>{NULLABLE_VALUE})\)
    .*?\|\s*attributes\s+r_att=(?P<attributes>{NULLABLE_VALUE})
    .*?\|\s*options\s+r_option=(?P<options>{NULLABLE_VALUE})
    .*?\|\s*price\s+r_price=(?P<price>{NULLABLE_VALUE})
    """,
    re.IGNORECASE | re.VERBOSE,
)

GOLD_RE = re.compile(
    r"""
    price_upper=(?P<price>.*?)\s*\|\s*
    gold_attributes=(?P<attributes>\[.*?\])\s*\|\s*
    gold_options=(?P<options>\[.*\])\s*$
    """,
    re.IGNORECASE | re.VERBOSE,
)

OPTION_SCAN_RE = re.compile(
    r"\[Option Scan\]\s+scanned\s+(?P<pages>\d+)\s+extra page\(s\),\s+"
    r"recorded\s+(?P<candidates>\d+)\s+candidate\(s\)",
    re.IGNORECASE,
)


@dataclass
class EpisodeRecord:
    sequence_index: int
    episode_id: int

    reward: float
    success: bool

    # Decomposed preference-satisfaction metrics
    type_ps: Optional[float]
    attribute_ps: Optional[float]
    option_ps: Optional[float]
    price_ps: Optional[float]

    # Evaluation-only preference counts from the logged WebShop gold schema
    product_type_count: Optional[int]
    attribute_count: Optional[int]
    option_count: Optional[int]
    price_constraint_count: Optional[int]
    preference_count: Optional[int]

    # LASER-style high-level trajectory
    trajectory_length: Optional[int]
    trajectory_group_value: str
    forced_stop: bool

    search_actions: int
    product_select_actions: int
    item_back_actions: int
    buy_actions: int
    inferred_result_navigation_actions: int

    # Diagnostics excluded from the primary trajectory length
    inspection_actions: int
    safe_option_clicks: int
    extra_pages_scanned: int
    scan_candidates_recorded: int
    result_page_arrivals: int


@dataclass
class GroupStats:
    group: str
    episodes: int
    share_percent: float
    complete_ps_percent: float
    mean_ps_percent: float
    type_ps_percent: Optional[float]
    attribute_ps_percent: Optional[float]
    option_ps_percent: Optional[float]
    option_applicable_episodes: int
    price_ps_percent: Optional[float]
    mean_trajectory_length: Optional[float]
    mean_preference_count: Optional[float]


def parse_nullable_value(raw: str) -> Optional[float]:
    normalized = raw.strip().lower()
    if normalized in {"n/a", "none", "null", "nan"}:
        return None
    return float(normalized)


def safe_mean(values: Iterable[Optional[float]]) -> Optional[float]:
    applicable = [value for value in values if value is not None]
    if not applicable:
        return None
    return statistics.fmean(applicable)


def percent(value: Optional[float]) -> Optional[float]:
    return None if value is None else 100.0 * value


def parse_literal_list(raw: str, label: str, episode_id: int) -> Optional[list]:
    try:
        parsed = ast.literal_eval(raw)
    except (SyntaxError, ValueError) as error:
        print(
            f"Warning: episode {episode_id}: could not parse {label}: {error}",
            file=sys.stderr,
        )
        return None

    if not isinstance(parsed, list):
        print(
            f"Warning: episode {episode_id}: {label} is not a list.",
            file=sys.stderr,
        )
        return None
    return parsed


def price_is_present(raw: str) -> bool:
    return raw.strip().lower() not in {
        "",
        "none",
        "null",
        "n/a",
        "nan",
    }


def split_complete_episodes(lines: Sequence[str]) -> tuple[list[tuple[int, list[str]]], int]:
    """Split the log by explicit Episode start/end markers."""
    episodes: list[tuple[int, list[str]]] = []
    current_id: Optional[int] = None
    current_lines: list[str] = []
    incomplete = 0

    for line in lines:
        start_match = EPISODE_START_RE.search(line)
        if start_match:
            if current_id is not None:
                # A new episode began before the previous one ended.
                incomplete += 1
            current_id = int(start_match.group("episode"))
            current_lines = [line]
            continue

        if current_id is None:
            continue

        current_lines.append(line)
        if EPISODE_END_RE.search(line):
            episodes.append((current_id, current_lines))
            current_id = None
            current_lines = []

    if current_id is not None:
        incomplete += 1

    return episodes, incomplete


def count_trajectory(
    episode_lines: Sequence[str],
) -> tuple[
    Optional[int],
    str,
    bool,
    int,
    int,
    int,
    int,
    int,
    int,
    int,
    int,
    int,
]:
    """
    Reconstruct the controller's high-level transition count.

    The controller logs search, product selection, item-page back, and Buy Now
    explicitly. Main result-page Next/Prev actions are not printed directly.
    Each such action produces another "[Result Candidates]" arrival. We infer:

        result_navigation =
            result_page_arrivals - searches - item_page_backs

    because every search and every item-page back also yields one results-page
    arrival without requiring an additional navigation action.
    """
    searches = sum(
        "[Executive Controller] search search[" in line
        for line in episode_lines
    )
    selections = sum(
        "[Executive Controller] select click[" in line
        for line in episode_lines
    )
    item_backs = sum(
        (
            "[Executive Controller] decision=back" in line
            or "[Executive Controller] decision=Back to Search" in line
        )
        for line in episode_lines
    )
    buys = sum(
        "[Executive Controller] decision=Buy Now" in line
        for line in episode_lines
    )

    # An early commit may execute a buy without a controller Buy Now line.
    if (
        buys == 0
        and any("[Early Grounded Commit]" in line for line in episode_lines)
    ):
        buys = 1

    result_arrivals = sum(
        "[Result Candidates]" in line for line in episode_lines
    )
    inferred_navigation = max(
        0, result_arrivals - searches - item_backs
    )

    inspections = sum(
        "[Executive Controller] inspect " in line
        for line in episode_lines
    )
    safe_option_clicks = sum(
        "[Safe Option Selection] click[" in line
        for line in episode_lines
    )

    extra_pages = 0
    scan_candidates = 0
    for line in episode_lines:
        match = OPTION_SCAN_RE.search(line)
        if match:
            extra_pages += int(match.group("pages"))
            scan_candidates += int(match.group("candidates"))

    forced_stop = any(
        "[Best-Seen Recovery] entering deadline-aware recovery" in line
        for line in episode_lines
    )

    counted_length = (
        searches
        + selections
        + item_backs
        + buys
        + inferred_navigation
    )

    if forced_stop:
        # The implementation records these as -1 because the high-level
        # controller exhausted its budget before recovery.
        trajectory_length: Optional[int] = None
        group_value = "forced-stop"
    else:
        trajectory_length = counted_length
        group_value = str(counted_length)

    return (
        trajectory_length,
        group_value,
        forced_stop,
        searches,
        selections,
        item_backs,
        buys,
        inferred_navigation,
        inspections,
        safe_option_clicks,
        extra_pages,
        scan_candidates,
        result_arrivals,
    )


def parse_episode(
    sequence_index: int,
    episode_id: int,
    episode_lines: Sequence[str],
) -> Optional[EpisodeRecord]:
    end_match = next(
        (
            match
            for line in reversed(episode_lines)
            if (match := EPISODE_END_RE.search(line))
        ),
        None,
    )
    if end_match is None:
        return None

    reward = float(end_match.group("reward"))
    success = end_match.group("success").lower() == "true"

    breakdown_match = next(
        (
            match
            for line in reversed(episode_lines)
            if (match := REWARD_BREAKDOWN_RE.search(line))
        ),
        None,
    )
    if breakdown_match is None:
        print(
            f"Warning: episode {episode_id}: no Reward Breakdown found; skipped.",
            file=sys.stderr,
        )
        return None

    type_ps = parse_nullable_value(breakdown_match.group("type"))
    attribute_ps = parse_nullable_value(
        breakdown_match.group("attributes")
    )
    option_ps = parse_nullable_value(breakdown_match.group("options"))
    price_ps = parse_nullable_value(breakdown_match.group("price"))

    product_type_count: Optional[int] = None
    attribute_count: Optional[int] = None
    option_count: Optional[int] = None
    price_constraint_count: Optional[int] = None
    preference_count: Optional[int] = None

    gold_match = next(
        (
            match
            for line in episode_lines
            if "[Gold Target] asin=" in line
            and (match := GOLD_RE.search(line))
        ),
        None,
    )
    if gold_match is None:
        print(
            f"Warning: episode {episode_id}: gold preference fields not found; "
            "preference-count analysis will omit this episode.",
            file=sys.stderr,
        )
    else:
        attributes = parse_literal_list(
            gold_match.group("attributes"),
            "gold_attributes",
            episode_id,
        )
        options = parse_literal_list(
            gold_match.group("options"),
            "gold_options",
            episode_id,
        )
        if attributes is not None and options is not None:
            product_type_count = 1
            attribute_count = len(attributes)
            option_count = len(options)
            price_constraint_count = (
                1 if price_is_present(gold_match.group("price")) else 0
            )
            preference_count = (
                product_type_count
                + attribute_count
                + option_count
                + price_constraint_count
            )

    (
        trajectory_length,
        trajectory_group_value,
        forced_stop,
        searches,
        selections,
        item_backs,
        buys,
        inferred_navigation,
        inspections,
        safe_option_clicks,
        extra_pages,
        scan_candidates,
        result_arrivals,
    ) = count_trajectory(episode_lines)

    return EpisodeRecord(
        sequence_index=sequence_index,
        episode_id=episode_id,
        reward=reward,
        success=success,
        type_ps=type_ps,
        attribute_ps=attribute_ps,
        option_ps=option_ps,
        price_ps=price_ps,
        product_type_count=product_type_count,
        attribute_count=attribute_count,
        option_count=option_count,
        price_constraint_count=price_constraint_count,
        preference_count=preference_count,
        trajectory_length=trajectory_length,
        trajectory_group_value=trajectory_group_value,
        forced_stop=forced_stop,
        search_actions=searches,
        product_select_actions=selections,
        item_back_actions=item_backs,
        buy_actions=buys,
        inferred_result_navigation_actions=inferred_navigation,
        inspection_actions=inspections,
        safe_option_clicks=safe_option_clicks,
        extra_pages_scanned=extra_pages,
        scan_candidates_recorded=scan_candidates,
        result_page_arrivals=result_arrivals,
    )


def trajectory_bin(record: EpisodeRecord) -> str:
    if record.forced_stop:
        return "forced-stop"

    length = record.trajectory_length
    if length is None:
        return "unknown"
    if length < 3:
        return "<3"
    if length == 3:
        return "3"
    if 4 <= length <= 6:
        return "4-6"
    if 7 <= length <= 9:
        return "7-9"
    if 10 <= length <= 12:
        return "10-12"
    return "13+"


def preference_bin(record: EpisodeRecord) -> str:
    count = record.preference_count
    if count is None:
        return "unknown"
    if count < 3:
        return "<3"
    if count in {3, 4, 5}:
        return str(count)
    return "6+"


def group_stats(
    group: str,
    records: Sequence[EpisodeRecord],
    total: int,
) -> GroupStats:
    numeric_lengths = [
        float(record.trajectory_length)
        for record in records
        if record.trajectory_length is not None
    ]
    pref_counts = [
        float(record.preference_count)
        for record in records
        if record.preference_count is not None
    ]

    return GroupStats(
        group=group,
        episodes=len(records),
        share_percent=(100.0 * len(records) / total) if total else math.nan,
        complete_ps_percent=100.0
        * statistics.fmean(1.0 if record.success else 0.0 for record in records),
        mean_ps_percent=100.0
        * statistics.fmean(record.reward for record in records),
        type_ps_percent=percent(
            safe_mean(record.type_ps for record in records)
        ),
        attribute_ps_percent=percent(
            safe_mean(record.attribute_ps for record in records)
        ),
        option_ps_percent=percent(
            safe_mean(record.option_ps for record in records)
        ),
        option_applicable_episodes=sum(
            record.option_ps is not None for record in records
        ),
        price_ps_percent=percent(
            safe_mean(record.price_ps for record in records)
        ),
        mean_trajectory_length=(
            statistics.fmean(numeric_lengths)
            if numeric_lengths
            else None
        ),
        mean_preference_count=(
            statistics.fmean(pref_counts) if pref_counts else None
        ),
    )


def build_group_table(
    records: Sequence[EpisodeRecord],
    key_function,
    order: Sequence[str],
) -> list[GroupStats]:
    buckets: dict[str, list[EpisodeRecord]] = {}
    for record in records:
        key = key_function(record)
        buckets.setdefault(key, []).append(record)

    ordered_keys = [key for key in order if key in buckets]
    ordered_keys.extend(
        sorted(key for key in buckets if key not in set(ordered_keys))
    )
    return [
        group_stats(key, buckets[key], len(records))
        for key in ordered_keys
    ]


def exact_trajectory_order(records: Sequence[EpisodeRecord]) -> list[str]:
    numeric = sorted(
        {
            record.trajectory_length
            for record in records
            if record.trajectory_length is not None
        }
    )
    order = [str(value) for value in numeric]
    if any(record.forced_stop for record in records):
        order.append("forced-stop")
    return order


def exact_preference_order(records: Sequence[EpisodeRecord]) -> list[str]:
    counts = sorted(
        {
            record.preference_count
            for record in records
            if record.preference_count is not None
        }
    )
    order = [str(value) for value in counts]
    if any(record.preference_count is None for record in records):
        order.append("unknown")
    return order


def write_dataclass_csv(
    path: Path,
    rows: Sequence[object],
) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if not rows:
        return

    dictionaries = [asdict(row) for row in rows]
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(
            handle, fieldnames=list(dictionaries[0].keys())
        )
        writer.writeheader()
        writer.writerows(dictionaries)


def format_optional(value: Optional[float], decimals: int = 2) -> str:
    return "n/a" if value is None else f"{value:.{decimals}f}"


def print_group_table(title: str, rows: Sequence[GroupStats]) -> None:
    print(f"\n{title}")
    print(
        "Group        N   Share   Complete PS   Mean PS   "
        "Type   Attr   Option (n)   Price"
    )
    print("-" * 91)
    for row in rows:
        option_text = (
            "n/a"
            if row.option_ps_percent is None
            else f"{row.option_ps_percent:5.1f} "
                 f"({row.option_applicable_episodes})"
        )
        print(
            f"{row.group:<11}"
            f"{row.episodes:>4}  "
            f"{row.share_percent:>5.1f}%  "
            f"{row.complete_ps_percent:>10.1f}%  "
            f"{row.mean_ps_percent:>7.1f}%  "
            f"{format_optional(row.type_ps_percent, 1):>5}  "
            f"{format_optional(row.attribute_ps_percent, 1):>5}  "
            f"{option_text:>11}  "
            f"{format_optional(row.price_ps_percent, 1):>5}"
        )


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description=(
            "Calculate WebShop performance by trajectory length and by "
            "number of preferences from a preference-aware agent log."
        )
    )
    parser.add_argument("log", type=Path, help="Path to the log file.")
    parser.add_argument(
        "--output-prefix",
        type=Path,
        help=(
            "Output prefix. Defaults to '<log_stem>_analysis' beside the log."
        ),
    )
    parser.add_argument(
        "--first-n",
        type=int,
        help="Analyze only the first N complete parsed episodes.",
    )
    parser.add_argument(
        "--episode-start",
        type=int,
        help="Keep episodes whose logged episode ID is at least this value.",
    )
    parser.add_argument(
        "--episode-end",
        type=int,
        help="Keep episodes whose logged episode ID is at most this value.",
    )
    return parser.parse_args()


def main() -> int:
    args = parse_args()

    if not args.log.is_file():
        print(f"Error: log file not found: {args.log}", file=sys.stderr)
        return 1

    # Force a full-split audit. Truncating records or ID-range filtering can
    # conceal duplicates/missing runs and does not define the 500-task sample.
    if (args.first_n is not None or args.episode_start is not None
            or args.episode_end is not None):
        print("Error: full-500 audit does not allow --first-n, --episode-start, "
              "or --episode-end.", file=sys.stderr)
        return 1

    physical_lines = args.log.read_text(
        encoding="utf-8", errors="replace"
    ).splitlines()
    lines = [match.group(1) for line in physical_lines
             if (match := INFO_RE.match(line))]
    if not lines:
        print("Error: no timestamped INFO records found; cannot safely "
              "deduplicate this log format.", file=sys.stderr)
        return 1
    raw_episodes, incomplete_count = split_complete_episodes(lines)
    raw_ids = [episode_id for episode_id, _ in raw_episodes]
    expected_ids = set(range(500))
    missing = sorted(expected_ids.difference(raw_ids))
    extras = sorted(set(raw_ids).difference(expected_ids))
    duplicate_count = len(raw_ids) - len(set(raw_ids))
    if len(raw_ids) != 500 or missing or extras or duplicate_count or incomplete_count:
        print(f"Error: canonical INFO log has {len(raw_ids)} completed blocks, "
              f"{duplicate_count} duplicate IDs, {incomplete_count} incomplete "
              f"blocks; missing IDs: {missing[:25]}; extra IDs: {extras[:25]}. "
              "Expected exactly one completed episode for every ID 0..499.",
              file=sys.stderr)
        return 1

    records: list[EpisodeRecord] = []
    for sequence_index, (episode_id, episode_lines) in enumerate(raw_episodes):
        record = parse_episode(
            sequence_index=sequence_index,
            episode_id=episode_id,
            episode_lines=episode_lines,
        )
        if record is not None:
            records.append(record)

    if args.episode_start is not None:
        records = [
            record
            for record in records
            if record.episode_id >= args.episode_start
        ]
    if args.episode_end is not None:
        records = [
            record
            for record in records
            if record.episode_id <= args.episode_end
        ]
    if args.first_n is not None:
        if args.first_n < 1:
            print("Error: --first-n must be positive.", file=sys.stderr)
            return 1
        records = records[: args.first_n]

    if not records:
        print("Error: no complete analyzable episodes found.", file=sys.stderr)
        return 1
    if len(records) != 500 or set(r.episode_id for r in records) != expected_ids:
        print(f"Error: only {len(records)} of the 500 canonical episodes "
              "have complete usable reward breakdowns.", file=sys.stderr)
        return 1
    missing_prefs = [r.episode_id for r in records if r.preference_count is None]
    if missing_prefs:
        print(f"Error: {len(missing_prefs)} episodes lack preference counts: "
              f"{missing_prefs[:25]}", file=sys.stderr)
        return 1
    # Manuscript Appendix B.1 states 391/500 instructions require an option.
    option_applicable = sum(r.option_ps is not None for r in records)
    if option_applicable != 391:
        print(f"Error: {option_applicable} episodes have an applicable option "
              "score, but the manuscript expects 391/500. Verify that "
              "this is the correct V2 test log and reward breakdown format.",
              file=sys.stderr)
        return 1

    inconsistent = [r.episode_id for r in records
                    if r.success != (abs(r.reward - 1.0) < 1e-9)]
    if inconsistent:
        print("Error: recorded 'success' does not match reward=1.0 "
              f"for these episode IDs: {inconsistent[:25]}", file=sys.stderr)
        return 1

    output_prefix = args.output_prefix
    if output_prefix is None:
        output_prefix = args.log.with_name(
            f"{args.log.stem}_analysis"
        )

    trajectory_exact = build_group_table(
        records,
        lambda record: record.trajectory_group_value,
        exact_trajectory_order(records),
    )
    trajectory_bins = build_group_table(
        records,
        trajectory_bin,
        ["<3", "3", "4-6", "7-9", "10-12", "13+", "forced-stop"],
    )
    preference_exact = build_group_table(
        [
            record
            for record in records
            if record.preference_count is not None
        ],
        lambda record: str(record.preference_count),
        exact_preference_order(records),
    )
    preference_bins = build_group_table(
        [
            record
            for record in records
            if record.preference_count is not None
        ],
        preference_bin,
        ["<3", "3", "4", "5", "6+", "unknown"],
    )

    episodes_path = Path(f"{output_prefix}_episodes.csv")
    trajectory_exact_path = Path(
        f"{output_prefix}_trajectory_exact.csv"
    )
    trajectory_bins_path = Path(
        f"{output_prefix}_trajectory_bins.csv"
    )
    preference_exact_path = Path(
        f"{output_prefix}_preference_count.csv"
    )
    preference_bins_path = Path(
        f"{output_prefix}_preference_bins.csv"
    )
    summary_path = Path(f"{output_prefix}_summary.json")

    write_dataclass_csv(episodes_path, records)
    write_dataclass_csv(trajectory_exact_path, trajectory_exact)
    write_dataclass_csv(trajectory_bins_path, trajectory_bins)
    write_dataclass_csv(preference_exact_path, preference_exact)
    write_dataclass_csv(preference_bins_path, preference_bins)

    summary = {
        "log": str(args.log),
        "complete_episodes_in_file": len(raw_episodes),
        "analyzed_episodes": len(records),
        "incomplete_episode_blocks_ignored": incomplete_count,
        "episode_ids": [record.episode_id for record in records],
        "overall": asdict(group_stats("all", records, len(records))),
        "forced_stop_episodes": sum(
            record.forced_stop for record in records
        ),
        "preference_count_available": sum(
            record.preference_count is not None for record in records
        ),
        "trajectory_definition": (
            "search + product select + item-page exit/commit + inferred "
            "result-page navigation; inspections and safe-option clicks "
            "reported separately"
        ),
        "preference_count_definition": (
            "1 product type + gold attributes + gold options + price "
            "constraint when present; evaluation only"
        ),
        "outputs": {
            "episodes": str(episodes_path),
            "trajectory_exact": str(trajectory_exact_path),
            "trajectory_bins": str(trajectory_bins_path),
            "preference_count": str(preference_exact_path),
            "preference_bins": str(preference_bins_path),
        },
    }
    summary_path.parent.mkdir(parents=True, exist_ok=True)
    summary_path.write_text(
        json.dumps(summary, indent=2), encoding="utf-8"
    )

    overall = summary["overall"]
    # The published, full-sample V2 values in Tables 3 and 4. Verify before
    # presenting a replacement for Table 7; never silently adjust results.
    published_cps, published_mps = 55.8, 78.1
    actual_cps, actual_mps = (overall["complete_ps_percent"],
                              overall["mean_ps_percent"])
    print(f"Manuscript Tables 3/4 V2: Complete PS={published_cps:.1f}%, "
          f"Mean PS={published_mps:.1f}%")
    print(f"Recomputed from 500:       Complete PS={actual_cps:.2f}%, "
          f"Mean PS={actual_mps:.2f}%")
    manuscript_match = (round(actual_cps, 1) == published_cps and
                        round(actual_mps, 1) == published_mps)
    print("TABLES 3/4 AGREEMENT: " + ("PASS" if manuscript_match else "FAIL"))
    print(f"Option-applicable episode count: {option_applicable} (expected 391)")
    print(f"Complete episode blocks in file: {len(raw_episodes)}")
    print(f"Episodes analyzed: {len(records)}")
    if incomplete_count:
        print(f"Incomplete episode blocks ignored: {incomplete_count}")
    print(
        "Episode ID range: "
        f"{min(record.episode_id for record in records)}-"
        f"{max(record.episode_id for record in records)}"
    )
    print(
        f"Overall Complete PS: "
        f"{overall['complete_ps_percent']:.2f}%"
    )
    print(
        f"Overall Mean PS: {overall['mean_ps_percent']:.2f}%"
    )
    print(
        f"Forced-stop/recovery episodes: "
        f"{summary['forced_stop_episodes']}"
    )

    print_group_table(
        "Performance by exact trajectory length",
        trajectory_exact,
    )
    print_group_table(
        "Performance by trajectory-length bin",
        trajectory_bins,
    )
    print_group_table(
        "Performance by exact number of preferences",
        preference_exact,
    )
    print_group_table(
        "Performance by preference-count bin",
        preference_bins,
    )

    print("\nFiles written:")
    for path in [
        episodes_path,
        trajectory_exact_path,
        trajectory_bins_path,
        preference_exact_path,
        preference_bins_path,
        summary_path,
    ]:
        print(f"  {path}")

    if not manuscript_match:
        print("WARNING: full 500-task run DOES NOT match manuscript "
              "Tables 3/4 V2 (55.8%, 78.1%). Do not publish this output "
              "without reconciling run/version and metrics.", file=sys.stderr)
        return 2
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
