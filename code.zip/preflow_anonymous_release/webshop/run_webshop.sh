#!/bin/bash
# Exact commands for the reported WebShop results (Gemini-3-Flash via OpenRouter; set OPENROUTER_API_KEY).
# 500 test instructions, cumulative ablation (Table: V0/V1/V2)
ENABLE_PREFERENCE_LAYER=0 WEBSHOP_START=0 WEBSHOP_NUM_EPISODES=500 python preflow_webshop_agent.py | tee logs/v0_500.log
ENABLE_COMMIT_VERIFIER=0  WEBSHOP_START=0 WEBSHOP_NUM_EPISODES=500 python preflow_webshop_agent.py | tee logs/v1_500.log
                          WEBSHOP_START=0 WEBSHOP_NUM_EPISODES=500 python preflow_webshop_agent.py | tee logs/v2_500.log
# 100 instructions (two-LLM table), default configuration
python run_agent_on_custom_goals.py --agent preflow_webshop_agent.py --goals laser_goals.json --start 0 --num-episodes 100 | tee logs/preflow_100.log
