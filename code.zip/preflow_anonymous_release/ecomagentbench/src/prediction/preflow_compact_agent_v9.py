"""Conservative v9 PREFLOW adapter for EComAgentBench.

The v7 path is preserved through the first verification. v9 adds a bounded
post-verification rescue that can replace the incumbent only under a strict
Pareto/monotonic evidence gate. All catalog interaction uses the benchmark's
public tools; target products, rubrics, hidden clarification fields and trigger
keywords are never read by this class.
"""
from __future__ import annotations

import json
import logging
import re
from typing import Any

from src.database.product_db import ProductDB
from src.llm import LLMClient
from src.preflow import EvidenceLedger, RequirementPlan
from src.preflow.state import normalize_verification_payload
from src.prompts.preflow_compact_v9 import PLAN_PROMPT, RESCUE_VERIFY_PROMPT, SELECT_VERIFY_PROMPT, SHORTLIST_PROMPT
from src.tools import create_tools

logger = logging.getLogger(__name__)

_REVIEW_TERMS = (
    "review", "rating", "stars", "durab", "quality", "comfort", "fit", "works well",
    "performance", "feedback", "users", "customers", "reliable", "sturdy", "soft", "firm",
)


def _clean_text(value: Any, limit: int) -> str:
    if value is None:
        return ""
    if isinstance(value, list):
        value = " | ".join(str(x) for x in value if x is not None)
    elif isinstance(value, dict):
        value = json.dumps(value, ensure_ascii=False, sort_keys=True)
    text = " ".join(str(value).split())
    return text[:limit]


def _dedupe(seq: list[str], limit: int | None = None) -> list[str]:
    out: list[str] = []
    seen: set[str] = set()
    for x in seq:
        x = " ".join(str(x or "").split()).strip()
        if not x:
            continue
        key = x.casefold()
        if key in seen:
            continue
        seen.add(key)
        out.append(x)
        if limit is not None and len(out) >= limit:
            break
    return out


def _title_query_variants(query: str, max_variants: int = 16) -> list[str]:
    """Relax a title-only conjunctive query without another model call."""
    tokens = re.findall(r"[A-Za-z0-9][A-Za-z0-9+._/-]*", str(query or ""))
    if not tokens:
        return []
    candidates = [" ".join(tokens)]
    max_n = min(5, len(tokens))
    for n in range(max_n, 1, -1):
        for i in range(0, len(tokens) - n + 1):
            candidates.append(" ".join(tokens[i:i+n]))
    return _dedupe(candidates, max_variants)


def _norm_tokens(text: str) -> set[str]:
    return {t for t in re.findall(r"[a-z0-9]+", str(text or "").casefold()) if len(t) >= 2}


def _substantial_tokens(text: str) -> set[str]:
    stop = {"brand", "color", "compatible", "devices", "device", "style", "size", "material",
            "preference", "must", "need", "require", "required", "product", "item"}
    return {t for t in _norm_tokens(text) if t not in stop and len(t) >= 3}


def _rescue_tokens(text: str) -> set[str]:
    """Content tokens used only to rank public-title rescue candidates."""
    stop = {
        "brand", "color", "compatible", "devices", "device", "style", "size", "material",
        "preference", "must", "need", "require", "required", "product", "item", "type",
        "well", "reviewed", "looking", "find", "with", "from", "that", "this", "have",
        "has", "should", "using", "used", "made", "into", "under", "over", "least",
        "exactly", "same", "standard", "specific", "want", "needs", "only",
    }
    return {t for t in _norm_tokens(text) if t not in stop and len(t) >= 3}


class CompactPreflowShoppingAgent:
    def __init__(
        self,
        db: ProductDB,
        llm_client: LLMClient,
        *,
        max_model_calls: int = 4,
        max_questions: int = 4,
        max_search_queries: int = 4,
        shortlist_size: int = 7,
        max_repair_candidates: int = 4,
        max_evidence_chars_per_candidate: int = 6500,
        rescue_max_candidates: int = 12,
        rescue_store_pages: int = 5,
        rescue_title_search_calls: int = 12,
        rescue_review_tool_calls: int = 12,
    ) -> None:
        self.db = db
        self.llm = llm_client
        self.max_model_calls = max(2, int(max_model_calls))
        self.max_questions = max(0, int(max_questions))
        self.max_search_queries = max(1, int(max_search_queries))
        self.shortlist_size = max(3, int(shortlist_size))
        self.max_repair_candidates = max(0, int(max_repair_candidates))
        self.max_evidence_chars_per_candidate = max(2500, int(max_evidence_chars_per_candidate))
        self.rescue_max_candidates = max(1, int(rescue_max_candidates))
        self.rescue_store_pages = max(2, int(rescue_store_pages))
        self.rescue_title_search_calls = max(2, int(rescue_title_search_calls))
        self.rescue_review_tool_calls = max(0, int(rescue_review_tool_calls))
        self._model_calls = 0

    def _json_call(self, system: str, user: str, max_tokens: int) -> dict[str, Any]:
        if self._model_calls >= self.max_model_calls:
            raise RuntimeError("PREFLOW compact model-call budget exhausted")
        self._model_calls += 1
        return self.llm.chat_json(
            [{"role": "system", "content": system}, {"role": "user", "content": user}],
            max_tokens=max_tokens,
        )

    @staticmethod
    def _profile_requirement_label(key: str) -> str:
        mapping = {
            "color_preference": "Color",
            "device_compatibility": "Compatible Devices",
            "material_need": "Material",
            "style_preference": "Style",
            "phone_model_compatibility": "Compatible Phone Models",
            "size_preference": "Size",
            "brand_preference": "Brand",
            "water_resistance_need": "Water Resistance Level",
            "power_source_preference": "Power Source",
            "form_factor_preference": "Form Factor",
            "os_preference": "Operating System",
            "storage_capacity_preference": "Memory Storage Capacity",
            "lens_preference": "Lens Type",
            "ram_requirement": "RAM",
            "storage_preference": "Storage",
            "wireless_preference": "Wireless Type",
            "skin_type": "Skin Type",
            "processor_preference": "Processor",
            "avoid_preferences": "Avoid",
        }
        if key in mapping:
            return mapping[key]
        label = str(key).replace("_preference", "").replace("_requirement", "")
        label = label.replace("_need", "").replace("_", " ").strip()
        return label.title()

    def _build_plan(self, user_query: str, profile: dict[str, Any], planning: dict[str, Any]) -> RequirementPlan:
        """Build the plan while keeping source provenance deterministic.

        The planner may paraphrase explicit query requirements, but it is not allowed to
        smuggle saved-profile values into the query source. Profile requirements are
        appended directly from the public profile tool with source=profile.
        """
        plan = RequirementPlan()
        product_requirements = (profile or {}).get("product_requirements", {}) or {}
        profile_values = []
        if isinstance(product_requirements, dict):
            profile_values = [str(v) for v in product_requirements.values() if v not in (None, "", [])]

        query_items = planning.get("query_requirements", []) if isinstance(planning, dict) else []
        if isinstance(query_items, list):
            for item in query_items:
                if not isinstance(item, dict):
                    continue
                text = " ".join(str(item.get("text", "")).split()).strip()
                if not text:
                    continue
                # If a planner-generated query requirement contains a distinctive profile
                # value that is absent from the user's query, it is profile leakage. Drop
                # that copy; the profile value is added below with correct provenance.
                text_tokens = _substantial_tokens(text)
                query_tokens = _substantial_tokens(user_query)
                leaked = False
                for value in profile_values:
                    value_tokens = _substantial_tokens(value)
                    if not value_tokens:
                        continue
                    if value_tokens <= text_tokens and not value_tokens <= query_tokens:
                        leaked = True
                        break
                if leaked:
                    logger.info("Dropped planner requirement with profile leakage: %s", text)
                    continue
                plan.add(text, source="query", field_hint=item.get("field_hint", ""))

        if not any(r.source == "query" for r in plan.requirements):
            # Safe fallback: preserve the entire visible request rather than losing it.
            plan.add(user_query, source="query")

        if isinstance(product_requirements, dict):
            for key, value in product_requirements.items():
                if value is None or value == "" or value == []:
                    continue
                label = self._profile_requirement_label(str(key))
                plan.add(f"{label}: {value}", source="profile", field_hint=label)
        return plan

    @staticmethod
    def _plan_covers(plan: RequirementPlan, *terms: str) -> bool:
        terms_cf = [t.casefold() for t in terms]
        for r in plan.requirements:
            hint = r.field_hint.casefold()
            text = r.text.casefold()
            if any(t in hint for t in terms_cf):
                return True
            # Fall back to text only for reasonably specific multi-character terms.
            if any(len(t) >= 5 and t in text for t in terms_cf):
                return True
        return False

    @staticmethod
    def _required_store_names(plan: RequirementPlan) -> list[str]:
        names: list[str] = []
        for r in plan.requirements:
            hint = r.field_hint.casefold().strip()
            text = r.text.strip()
            if "brand" not in hint and not re.search(r"\bbrand\b", text, flags=re.I):
                continue
            value = ""
            if ":" in text:
                value = text.split(":", 1)[1].strip()
            else:
                # Accept both common planner phrasings:
                #   "Brand Wymisnit" / "brand must be Wymisnit"
                #   "Wymisnit brand"
                # The v6 parser only handled the first family, so a perfectly valid
                # suffix form could silently skip required-store acquisition.
                m = re.search(
                    r"\bbrand(?:\s+preference)?(?:\s+must\s+be|\s+is|\s+)?\s*[:=-]?\s*"
                    r"([A-Za-z0-9][A-Za-z0-9 .&'_-]{1,60})$",
                    text,
                    flags=re.I,
                )
                if m:
                    value = m.group(1).strip()
                else:
                    m = re.search(
                        r"^([A-Za-z0-9][A-Za-z0-9 .&'_-]{1,60}?)\s+brand(?:\s+preference)?$",
                        text,
                        flags=re.I,
                    )
                    if m:
                        value = m.group(1).strip()
            value = re.sub(r"^(must\s+be|preference)\s+", "", value, flags=re.I).strip(" .")
            if value:
                names.append(value)
        return _dedupe(names, 3)

    @staticmethod
    def _positive_requirement(text: str) -> bool:
        t = str(text or "").casefold()
        return not bool(re.search(r"\b(avoid|exclude|excluding|not|no|without|mustn'?t|do not|don'?t)\b", t))

    @classmethod
    def _rescue_required_store_names(cls, plan: RequirementPlan) -> list[str]:
        """More tolerant brand parser used ONLY after the v7 incumbent exists.

        The baseline path deliberately keeps v7's parser unchanged.  Rescue accepts a
        planner form such as text="Boao", field_hint="brand", while explicitly
        rejecting negative brand constraints such as "avoid Spigen".
        """
        names: list[str] = []
        for r in plan.requirements:
            hint = r.field_hint.casefold().strip()
            text = r.text.strip()
            if not cls._positive_requirement(text):
                continue
            if "brand" not in hint and not re.search(r"\bbrand\b", text, flags=re.I):
                continue
            value = ""
            if ":" in text:
                value = text.split(":", 1)[1].strip()
            else:
                m = re.search(
                    r"\bbrand(?:\s+preference)?(?:\s+must\s+be|\s+is|\s+)?\s*[:=-]?\s*"
                    r"([A-Za-z0-9][A-Za-z0-9 .&'_-]{1,60})$",
                    text,
                    flags=re.I,
                )
                if m:
                    value = m.group(1).strip()
                else:
                    m = re.search(
                        r"^([A-Za-z0-9][A-Za-z0-9 .&'_-]{1,60}?)\s+brand(?:\s+preference)?$",
                        text,
                        flags=re.I,
                    )
                    if m:
                        value = m.group(1).strip()
                    elif "brand" in hint:
                        value = text
            value = re.sub(r"^(must\s+be|preference)\s+", "", value, flags=re.I).strip(" .")
            if value:
                names.append(value)
        return _dedupe(names, 3)

    def _rescue_store_acquisition(
        self, tools: dict[str, Any], plan: RequirementPlan, ledger: EvidenceLedger
    ) -> tuple[list[dict], int]:
        """Bounded extra store scan used only when the incumbent has evidence gaps."""
        rows: list[dict] = []
        calls = 0
        seen: set[str] = set()
        for store in self._rescue_required_store_names(plan):
            for page in range(self.rescue_store_pages):
                args = {"store_name": store, "page": page}
                result = tools["get_store_products"].call(args)
                calls += 1
                ledger.record_tool_result("get_store_products", args, result)
                products = (result or {}).get("products", []) or []
                for p in products:
                    pid = str(p.get("product_id", ""))
                    if not pid or pid in seen:
                        continue
                    seen.add(pid)
                    rows.append({
                        "product_id": pid,
                        "title": _clean_text(p.get("title", ""), 220),
                        "query": f"store:{store}",
                        "rescue_source": "required_store",
                    })
                total = int((result or {}).get("total_count", 0) or 0)
                if not products or (page + 1) * 20 >= total:
                    break
        if calls:
            logger.info(
                "PREFLOW rescue store scan: %d candidates from %d public-tool call(s)",
                len(rows), calls,
            )
        return rows, calls

    def _store_acquisition(self, tools: dict[str, Any], plan: RequirementPlan, ledger: EvidenceLedger) -> tuple[list[dict], int]:
        """Always acquire candidates from explicitly required brands/stores.

        This uses the benchmark's public get_store_products tool and does not inspect
        hidden targets or rubrics. It prevents title-only search from silently dropping
        an explicit brand constraint.
        """
        rows: list[dict] = []
        calls = 0
        seen: set[str] = set()
        for store in self._required_store_names(plan):
            # Page 0 is normally enough; page 1 is a bounded fallback for larger stores.
            for page in (0, 1):
                args = {"store_name": store, "page": page}
                result = tools["get_store_products"].call(args)
                calls += 1
                ledger.record_tool_result("get_store_products", args, result)
                products = (result or {}).get("products", []) or []
                for p in products:
                    pid = str(p.get("product_id", ""))
                    if not pid or pid in seen:
                        continue
                    seen.add(pid)
                    rows.append({
                        "product_id": pid,
                        "title": _clean_text(p.get("title", ""), 220),
                        "query": f"store:{store}",
                    })
                total = int((result or {}).get("total_count", 0) or 0)
                if total <= 20 or not products:
                    break
        if calls:
            logger.info("Compact required-store acquisition: %d candidates from %d public-tool call(s)", len(rows), calls)
        return rows, calls

    @staticmethod
    def _is_nonanswer(text: str) -> bool:
        t = str(text or "").casefold()
        return (not t.strip()) or any(m in t for m in (
            "i'm not sure", "i am not sure", "could you ask", "can't answer", "cannot answer",
            "not interested in answering", "you have asked too much",
        ))

    def _planning_call(self, user_query: str, profile: dict[str, Any]) -> dict[str, Any]:
        # Full profile is available to benchmark agents, but keep the prompt compact.
        compact_profile = {
            "product_requirements": (profile or {}).get("product_requirements", {}),
            "lifestyle": (profile or {}).get("lifestyle", {}),
        }
        prompt = (
            "SHOPPING REQUEST:\n" + user_query
            + "\n\nSAVED PROFILE:\n" + json.dumps(compact_profile, ensure_ascii=False)
        )
        try:
            return self._json_call(PLAN_PROMPT, prompt, max_tokens=1300)
        except Exception as exc:
            logger.warning("Compact planning call failed; using deterministic fallback: %s", exc)
            return {"query_requirements": [], "clarification_questions": [], "search_queries": [user_query], "review_queries": []}

    @staticmethod
    def _fallback_search_queries(user_query: str, plan: RequirementPlan) -> list[str]:
        # Keep semantic anchors; _run_searches will relax them for title-only FTS.
        hinted = [r.text for r in plan.requirements if r.source == "query"][:3]
        return _dedupe(hinted + [user_query], 4)

    def _run_searches(self, tools: dict[str, Any], queries: list[str], ledger: EvidenceLedger) -> tuple[list[dict], int]:
        rows: list[dict] = []
        tool_calls = 0
        seen_ids: set[str] = set()
        attempted: set[str] = set()

        for query in _dedupe(queries, self.max_search_queries):
            for variant in _title_query_variants(query):
                key = variant.casefold()
                if key in attempted:
                    continue
                attempted.add(key)
                args = {"query": variant, "page": 0}
                result = tools["search_products"].call(args)
                tool_calls += 1
                ledger.record_tool_result("search_products", args, result)
                products = (result or {}).get("products", []) or []
                if not products:
                    continue
                for p in products:
                    pid = str(p.get("product_id", ""))
                    if not pid or pid in seen_ids:
                        continue
                    seen_ids.add(pid)
                    rows.append({
                        "product_id": pid,
                        "title": _clean_text(p.get("title", ""), 220),
                        "query": variant,
                    })
                # Stop relaxing this semantic query once a useful form returns hits.
                break

        logger.info("Compact local search: %d unique candidates from %d title queries", len(rows), tool_calls)
        return rows, tool_calls

    def _store_fallback(self, tools: dict[str, Any], plan: RequirementPlan, ledger: EvidenceLedger) -> tuple[list[dict], int]:
        return self._store_acquisition(tools, plan, ledger)

    def _shortlist(self, plan: RequirementPlan, search_rows: list[dict]) -> list[str]:
        if not search_rows:
            return []
        compact_rows = search_rows[:80]
        prompt = "REQUIREMENTS:\n" + plan.render() + "\n\nSEARCH RESULTS:\n" + json.dumps(compact_rows, ensure_ascii=False)
        try:
            payload = self._json_call(SHORTLIST_PROMPT, prompt, max_tokens=700)
            ids = payload.get("candidate_ids", []) if isinstance(payload, dict) else []
            valid = {r["product_id"] for r in search_rows}
            selected = [str(x) for x in ids if str(x) in valid]
            selected = _dedupe(selected, self.shortlist_size)
            if len(selected) >= 3:
                return selected
        except Exception as exc:
            logger.warning("Compact shortlist call failed; using BM25-order fallback: %s", exc)
        return _dedupe([r["product_id"] for r in search_rows], self.shortlist_size)

    @staticmethod
    def _rescue_identity_requirements(plan: RequirementPlan) -> list[str]:
        out: list[str] = []
        for r in plan.requirements:
            hint = r.field_hint.casefold().strip()
            if hint in {"product_type", "product type", "category", "entity", "item_type", "type"}:
                out.append(r.text)
            elif "product" in hint and "type" in hint:
                out.append(r.text)
        return _dedupe(out, 2)

    @staticmethod
    def _verification_gap_ids(verification: Any) -> set[str]:
        if verification is None:
            return set()
        return set(verification.contradicted_ids) | set(verification.unresolved_ids)

    def _rescue_search_queries(
        self,
        plan: RequirementPlan,
        verification: Any,
        repair_queries: list[str],
    ) -> list[str]:
        """Build a few public title-search probes from the agent's visible state."""
        queries: list[str] = list(repair_queries or [])
        identities = self._rescue_identity_requirements(plan)
        queries.extend(identities)
        gap_ids = self._verification_gap_ids(verification)
        by_id = {r.id: r for r in plan.requirements}
        stores = self._rescue_required_store_names(plan)

        for rid in gap_ids:
            req = by_id.get(rid)
            if req is None:
                continue
            if identities:
                queries.append(f"{identities[0]} {req.text}")
            else:
                queries.append(req.text)

        if stores and identities:
            queries.insert(0, f"{stores[0]} {identities[0]}")

        # Compatibility/model constraints are often title-visible and useful for repair.
        for r in plan.requirements:
            hint = r.field_hint.casefold()
            if "compatib" in hint or "model" in hint:
                if identities:
                    queries.append(f"{identities[0]} {r.text}")
                else:
                    queries.append(r.text)
                break
        return _dedupe(queries, 6)

    def _run_rescue_searches(
        self,
        tools: dict[str, Any],
        queries: list[str],
        ledger: EvidenceLedger,
    ) -> tuple[list[dict], int]:
        """Slightly deeper title retrieval, isolated from the v7 baseline path."""
        rows: list[dict] = []
        calls = 0
        seen: set[str] = set()
        attempted: set[str] = set()
        for query in queries:
            for variant in _title_query_variants(query, max_variants=10):
                if calls >= self.rescue_title_search_calls:
                    break
                key = variant.casefold()
                if key in attempted:
                    continue
                attempted.add(key)
                args = {"query": variant, "page": 0}
                result = tools["search_products"].call(args)
                calls += 1
                ledger.record_tool_result("search_products", args, result)
                products = (result or {}).get("products", []) or []
                if not products:
                    continue
                for p in products:
                    pid = str(p.get("product_id", ""))
                    if not pid or pid in seen:
                        continue
                    seen.add(pid)
                    rows.append({
                        "product_id": pid,
                        "title": _clean_text(p.get("title", ""), 220),
                        "query": variant,
                        "rescue_source": "targeted_search",
                    })
                if len(products) >= 20 and calls < self.rescue_title_search_calls:
                    args2 = {"query": variant, "page": 1}
                    result2 = tools["search_products"].call(args2)
                    calls += 1
                    ledger.record_tool_result("search_products", args2, result2)
                    for p in (result2 or {}).get("products", []) or []:
                        pid = str(p.get("product_id", ""))
                        if not pid or pid in seen:
                            continue
                        seen.add(pid)
                        rows.append({
                            "product_id": pid,
                            "title": _clean_text(p.get("title", ""), 220),
                            "query": variant,
                            "rescue_source": "targeted_search",
                        })
                # Stop relaxing this semantic query after its first useful form.
                break
            if calls >= self.rescue_title_search_calls:
                break
        if calls:
            logger.info("PREFLOW rescue title search: %d candidates from %d calls", len(rows), calls)
        return rows, calls

    @staticmethod
    def _rescue_row_score(
        plan: RequirementPlan,
        verification: Any,
        row: dict[str, Any],
    ) -> float:
        title_tokens = _rescue_tokens(row.get("title", ""))
        score = 0.0
        gap_ids = CompactPreflowShoppingAgent._verification_gap_ids(verification)
        stores = CompactPreflowShoppingAgent._rescue_required_store_names(plan)
        query_cf = str(row.get("query", "")).casefold()
        title_cf = str(row.get("title", "")).casefold()

        for store in stores:
            store_cf = store.casefold()
            if query_cf == f"store:{store_cf}":
                score += 20.0
            if store_cf and store_cf in title_cf:
                score += 12.0

        identity_tokens: set[str] = set()
        for text in CompactPreflowShoppingAgent._rescue_identity_requirements(plan):
            identity_tokens |= _rescue_tokens(text)
        overlap = len(title_tokens & identity_tokens)
        score += 15.0 * overlap
        if identity_tokens and identity_tokens <= title_tokens:
            score += 25.0

        for req in plan.requirements:
            req_tokens = _rescue_tokens(req.text)
            n = len(title_tokens & req_tokens)
            if not n:
                continue
            hint = req.field_hint.casefold()
            if req.id in gap_ids:
                score += 4.0 * n
            elif "compatib" in hint or "model" in hint or "connector" in hint:
                score += 4.0 * n
            else:
                score += 1.5 * n

        if row.get("rescue_source") == "targeted_search":
            score += 2.0
        return score

    def _rank_rescue_ids(
        self,
        plan: RequirementPlan,
        verification: Any,
        rows: list[dict],
        already_opened: set[str],
    ) -> list[str]:
        best: dict[str, tuple[float, int]] = {}
        for order, row in enumerate(rows):
            pid = str(row.get("product_id", ""))
            if not pid or pid in already_opened:
                continue
            score = self._rescue_row_score(plan, verification, row)
            previous = best.get(pid)
            if previous is None or score > previous[0]:
                best[pid] = (score, order)
        ranked = sorted(best, key=lambda pid: (-best[pid][0], best[pid][1]))
        return ranked[: self.rescue_max_candidates]

    @staticmethod
    def _review_query_variants(query: str) -> list[str]:
        stop = {
            "the", "a", "an", "and", "or", "for", "with", "that", "this", "is", "are",
            "it", "to", "of", "in", "on", "i", "want", "need", "needs", "must", "should",
            "review", "reviews", "mention", "mentions", "say", "says", "product", "item",
        }
        tokens = [
            t for t in re.findall(r"[A-Za-z0-9][A-Za-z0-9'-]*", str(query or ""))
            if t.casefold() not in stop and len(t) >= 3
        ]
        variants: list[str] = []
        if tokens:
            variants.append(" ".join(tokens))
        if len(tokens) >= 3:
            variants.extend(" ".join(tokens[i:i + 3]) for i in range(len(tokens) - 2))
        if len(tokens) >= 2:
            variants.extend(" ".join(tokens[i:i + 2]) for i in range(len(tokens) - 1))
        return _dedupe(variants, 6)

    def _supplement_rescue_reviews(
        self,
        tools: dict[str, Any],
        candidate_ids: list[str],
        plan: RequirementPlan,
        review_queries: list[str],
        snapshots: dict[str, dict[str, Any]],
        ledger: EvidenceLedger,
    ) -> int:
        """Relax review FTS only for rescue candidates whose first review query missed."""
        if not self._needs_reviews(plan, review_queries) or self.rescue_review_tool_calls <= 0:
            return 0
        queries = _dedupe(review_queries or self._default_review_queries(plan), 2)
        calls = 0
        for pid in candidate_ids:
            if snapshots.get(pid, {}).get("reviews"):
                continue
            for query in queries:
                for variant in self._review_query_variants(query):
                    if calls >= self.rescue_review_tool_calls:
                        return calls
                    args = {"query": variant[:120], "product_id": pid}
                    result = tools["get_review_content"].call(args)
                    calls += 1
                    ledger.record_tool_result("get_review_content", args, result)
                    reviews = (result or {}).get("reviews", []) or []
                    for rv in reviews[:3]:
                        snapshots[pid]["reviews"].append({
                            "query": variant[:120],
                            "rating": rv.get("rating"),
                            "title": _clean_text(rv.get("title", ""), 140),
                            "text": _clean_text(rv.get("text", ""), 600),
                        })
                    if reviews:
                        break
                if snapshots.get(pid, {}).get("reviews"):
                    break
        return calls

    @staticmethod
    def _needs_reviews(plan: RequirementPlan, review_queries: list[str]) -> bool:
        if review_queries:
            return True
        text = " ".join(r.text.casefold() for r in plan.requirements)
        return any(term in text for term in _REVIEW_TERMS)

    @staticmethod
    def _default_review_queries(plan: RequirementPlan) -> list[str]:
        matches = []
        for r in plan.requirements:
            t = r.text.casefold()
            if any(term in t for term in _REVIEW_TERMS):
                matches.append(r.text)
        return _dedupe(matches, 2)

    def _collect_candidate_evidence(
        self,
        tools: dict[str, Any],
        candidate_ids: list[str],
        plan: RequirementPlan,
        ledger: EvidenceLedger,
        review_queries: list[str],
    ) -> tuple[dict[str, dict[str, Any]], int]:
        snapshots: dict[str, dict[str, Any]] = {}
        tool_calls = 0
        ids = _dedupe(candidate_ids, self.shortlist_size + self.max_repair_candidates)

        for pid in ids:
            args = {"product_id": pid}
            details_result = tools["get_product_details"].call(args)
            tool_calls += 1
            ledger.record_tool_result("get_product_details", args, details_result)
            p = (details_result or {}).get("product", {}) or {}
            snapshots[pid] = {
                "product_id": pid,
                "title": _clean_text(p.get("title", ""), 260),
                "category": _clean_text(p.get("main_category", ""), 100),
                "store": _clean_text(p.get("store", ""), 100),
                "price": p.get("price"),
                "details": {str(k): _clean_text(v, 260) for k, v in list((p.get("details", {}) or {}).items())[:24]},
                "features": [_clean_text(x, 320) for x in (p.get("features", []) or [])[:10]],
                "description": [_clean_text(x, 360) for x in (p.get("description", []) or [])[:4]],
                "rating": {},
                "reviews": [],
            }

        # The public stats tool accepts at most ten IDs per call. Baseline v7 opens
        # seven candidates, so this is byte-equivalent there; rescue may open eleven.
        for start in range(0, len(ids), 10):
            batch = ids[start:start + 10]
            if not batch:
                continue
            stats_args = {"product_ids": batch}
            stats = tools["get_product_review_stats"].call(stats_args)
            tool_calls += 1
            ledger.record_tool_result("get_product_review_stats", stats_args, stats)
            for item in (stats or {}).get("products", []) or []:
                pid = str(item.get("product_id", ""))
                if pid in snapshots:
                    snapshots[pid]["rating"] = {
                        "average_rating": item.get("average_rating"),
                        "rating_number": item.get("rating_number"),
                    }

        if self._needs_reviews(plan, review_queries):
            queries = _dedupe(review_queries or self._default_review_queries(plan), 2)
            for pid in ids:
                for query in queries:
                    args = {"query": query[:120], "product_id": pid}
                    result = tools["get_review_content"].call(args)
                    tool_calls += 1
                    ledger.record_tool_result("get_review_content", args, result)
                    for rv in ((result or {}).get("reviews", []) or [])[:2]:
                        snapshots[pid]["reviews"].append({
                            "query": query[:120],
                            "rating": rv.get("rating"),
                            "title": _clean_text(rv.get("title", ""), 140),
                            "text": _clean_text(rv.get("text", ""), 600),
                        })
        return snapshots, tool_calls

    def _compact_snapshot_text(self, snapshots: dict[str, dict[str, Any]]) -> str:
        blocks = []
        for pid, data in snapshots.items():
            text = json.dumps(data, ensure_ascii=False, separators=(",", ":"))
            if len(text) > self.max_evidence_chars_per_candidate:
                text = text[: self.max_evidence_chars_per_candidate]
            blocks.append(text)
        return "\n".join(blocks)

    @staticmethod
    def _available_detail_keys(snapshots: dict[str, dict[str, Any]]) -> set[str]:
        keys: set[str] = set()
        for data in snapshots.values():
            for key in (data.get("details", {}) or {}).keys():
                keys.add(str(key).casefold())
            rating = data.get("rating", {}) or {}
            if rating.get("average_rating") is not None:
                keys.add("average_rating")
            if rating.get("rating_number") is not None:
                keys.add("rating_number")
        return keys

    def _decision_clarification_questions(self, plan: RequirementPlan, snapshots: dict[str, dict[str, Any]]) -> list[tuple[str, str]]:
        """Choose natural, field-level clarification questions from observed candidate state.

        No hidden clarification script, trigger keywords, target product, or rubric is read.
        Questions are only about product dimensions that exist in the public candidate
        evidence and are not already fixed by query/profile requirements.
        """
        keys = self._available_detail_keys(snapshots)
        specs = [
            ("screen size", ("screen size", "size"), "Do you require a specific screen size?"),
            ("finish type", ("finish",), "Do you require a specific finish type?"),
            ("shape", ("shape",), "Do you require a specific product shape?"),
            ("mounting type", ("mounting",), "Do you require a specific mounting style?"),
            ("special feature", ("special feature",), "Are there any special features you require?"),
            ("average_rating", ("average rating", "stars"), "Do you have a minimum average rating requirement?"),
            ("rating_number", ("rating count", "number of ratings"), "Do you require a minimum number of customer ratings?"),
            ("number of items", ("quantity", "number of items"), "Do you require a specific number of items?"),
            ("color", ("color",), "Do you require a specific color?"),
            ("material", ("material",), "Do you require a specific material?"),
        ]
        out: list[tuple[str, str]] = []
        for key, cover_terms, question in specs:
            if key not in keys:
                continue
            if self._plan_covers(plan, *cover_terms):
                continue
            out.append((question, key))
            if len(out) >= self.max_questions:
                break
        return out

    def _ask_decision_clarifications(
        self, tools: dict[str, Any], plan: RequirementPlan, snapshots: dict[str, dict[str, Any]]
    ) -> tuple[list[dict[str, str]], int]:
        transcript: list[dict[str, str]] = []
        calls = 0
        for question, field_hint in self._decision_clarification_questions(plan, snapshots):
            result = tools["ask_user"].call({"question": question[:99]})
            calls += 1
            answer = str((result or {}).get("user_response", ""))
            transcript.append({"question": question[:99], "answer": answer})
            if not self._is_nonanswer(answer):
                plan.add(answer, source="clarification", field_hint=field_hint)
        return transcript, calls

    def _select_verify(self, plan: RequirementPlan, snapshots: dict[str, dict[str, Any]], ledger: EvidenceLedger):
        if not snapshots:
            return None, None, []
        prompt = (
            "REQUIREMENTS:\n" + json.dumps(plan.as_list(), ensure_ascii=False)
            + "\n\nCANDIDATE EVIDENCE:\n" + self._compact_snapshot_text(snapshots)
        )
        payload = self._json_call(SELECT_VERIFY_PROMPT, prompt, max_tokens=2200)
        pid = str(payload.get("selected_product_id", "")).strip()
        if pid not in snapshots:
            pid = next(iter(snapshots))
        result = normalize_verification_payload(payload, plan, pid)
        ledger.set_verification(result)
        repairs = payload.get("repair_search_queries", []) if isinstance(payload, dict) else []
        repairs = _dedupe([str(x) for x in repairs if isinstance(x, str)], 2)
        return pid, result, repairs

    def _rescue_verify(
        self,
        plan: RequirementPlan,
        incumbent: Any,
        challenger_snapshots: dict[str, dict[str, Any]],
        ledger: EvidenceLedger,
    ):
        if not challenger_snapshots:
            return None, None
        prompt = (
            "REQUIREMENTS:\n" + json.dumps(plan.as_list(), ensure_ascii=False)
            + "\n\nINCUMBENT VERIFICATION (context only; incumbent is not selectable):\n"
            + json.dumps(incumbent.as_dict() if incumbent else {}, ensure_ascii=False)
            + "\n\nCHALLENGER EVIDENCE:\n" + self._compact_snapshot_text(challenger_snapshots)
        )
        payload = self._json_call(RESCUE_VERIFY_PROMPT, prompt, max_tokens=2400)
        pid = str(payload.get("selected_product_id", "")).strip()
        if pid not in challenger_snapshots:
            return None, None
        result = normalize_verification_payload(payload, plan, pid)
        ledger.set_verification(result)
        return pid, result

    @staticmethod
    def _strict_monotonic_improvement(incumbent: Any, challenger: Any) -> tuple[bool, str]:
        """Allow a switch only when requirement state is Pareto-better.

        supported > unresolved > contradicted.  A challenger may not degrade a single
        requirement and must turn at least one incumbent gap into direct support.  An
        incumbent already marked all-supported is frozen.
        """
        if incumbent is None or challenger is None:
            return False, "missing verification"
        if incumbent.all_supported:
            return False, "incumbent already all-supported"
        rank = {"contradicted": 0, "unresolved": 1, "supported": 2}
        improved_to_supported = False
        strict = False
        for rid, old_status in incumbent.statuses.items():
            new_status = challenger.statuses.get(rid, "unresolved")
            if rank.get(new_status, 1) < rank.get(old_status, 1):
                return False, f"would degrade {rid}: {old_status}->{new_status}"
            if rank.get(new_status, 1) > rank.get(old_status, 1):
                strict = True
                if new_status == "supported":
                    quote = str(challenger.evidence_quotes.get(rid, "")).strip()
                    if quote:
                        improved_to_supported = True
        if not strict:
            return False, "no strict requirement improvement"
        if not improved_to_supported:
            return False, "no evidence-backed gap resolved to supported"
        return True, "strict Pareto improvement"

    def run(self, sample: dict) -> dict[str, Any]:
        self._model_calls = 0
        tools = create_tools(self.db, sample_data=sample)
        ledger = EvidenceLedger()
        user_query = str(sample["user_query"])
        total_tool_calls = 0
        ask_user_calls = 0
        get_profile_calls = 0
        clarification_transcript: list[dict[str, str]] = []
        verification_events: list[dict[str, Any]] = []
        trajectory: list[dict[str, Any]] = []

        profile_result = tools["get_user_profile"].call({})
        total_tool_calls += 1
        get_profile_calls += 1
        profile = (profile_result or {}).get("profile", {}) or {}

        planning = self._planning_call(user_query, profile)
        plan = self._build_plan(user_query, profile, planning)

        search_queries = planning.get("search_queries", []) if isinstance(planning, dict) else []
        search_queries = _dedupe([str(q) for q in search_queries if isinstance(q, str)], self.max_search_queries)
        if not search_queries:
            search_queries = self._fallback_search_queries(user_query, plan)
        search_rows, ntools = self._run_searches(tools, search_queries, ledger)
        total_tool_calls += ntools

        # Explicit brand/store requirements get their own public-tool acquisition path
        # regardless of whether generic title search returned other products.
        store_rows, ntools = self._store_acquisition(tools, plan, ledger)
        total_tool_calls += ntools
        merged: list[dict] = []
        seen_pids: set[str] = set()
        # Put required-store candidates first so the shortlister cannot lose them merely
        # because title BM25 surfaced many generic products.
        for row in store_rows + search_rows:
            pid = str(row.get("product_id", ""))
            if not pid or pid in seen_pids:
                continue
            seen_pids.add(pid)
            merged.append(row)
        search_rows = merged

        if not search_rows:
            fallback_queries = self._fallback_search_queries(user_query, plan)
            search_rows, ntools = self._run_searches(tools, fallback_queries, ledger)
            total_tool_calls += ntools
        if not search_rows:
            search_rows, ntools = self._store_fallback(tools, plan, ledger)
            total_tool_calls += ntools

        candidate_ids = self._shortlist(plan, search_rows)
        review_queries = planning.get("review_queries", []) if isinstance(planning, dict) else []
        review_queries = _dedupe([str(q) for q in review_queries if isinstance(q, str)], 2)
        snapshots, ntools = self._collect_candidate_evidence(tools, candidate_ids, plan, ledger, review_queries)
        total_tool_calls += ntools

        # Ask only after observing candidate evidence, so questions target unresolved
        # decision dimensions rather than speculative generic dialogue. No extra LLM call.
        clar_rows, ntools = self._ask_decision_clarifications(tools, plan, snapshots)
        total_tool_calls += ntools
        ask_user_calls += ntools
        clarification_transcript.extend(clar_rows)

        selected_id = None
        verification = None
        repair_queries: list[str] = []
        if snapshots:
            selected_id, verification, repair_queries = self._select_verify(plan, snapshots, ledger)
            if verification:
                verification_events.append(verification.as_dict())

        repair_used = False
        rescue_diagnostics: dict[str, Any] = {
            "attempted": False,
            "baseline_selected_product_id": selected_id,
            "candidate_ids_opened": [],
            "challenger_product_id": None,
            "accepted": False,
            "gate_reason": "not needed",
        }

        # v9 rescue is isolated AFTER the v7 incumbent exists.  The original selection
        # is frozen unless a newly inspected challenger is Pareto-better on requirement
        # state: no supported requirement may be lost, and at least one gap must become
        # directly supported.  This prevents the broad-search regressions seen in v8.
        if (
            selected_id
            and verification
            and not verification.all_supported
            and self._model_calls < self.max_model_calls
        ):
            repair_used = True
            rescue_diagnostics["attempted"] = True
            rescue_rows: list[dict] = list(search_rows)

            store_rows2, ntools = self._rescue_store_acquisition(tools, plan, ledger)
            total_tool_calls += ntools
            rescue_rows.extend(store_rows2)

            rescue_queries = self._rescue_search_queries(plan, verification, repair_queries)
            targeted_rows, ntools = self._run_rescue_searches(tools, rescue_queries, ledger)
            total_tool_calls += ntools
            rescue_rows.extend(targeted_rows)

            rescue_ids = self._rank_rescue_ids(
                plan, verification, rescue_rows, already_opened=set(snapshots)
            )
            rescue_diagnostics["candidate_ids_opened"] = list(rescue_ids)

            challenger_snapshots: dict[str, dict[str, Any]] = {}
            if rescue_ids:
                challenger_snapshots, ntools = self._collect_candidate_evidence(
                    tools, rescue_ids, plan, ledger, review_queries
                )
                total_tool_calls += ntools
                ntools = self._supplement_rescue_reviews(
                    tools, rescue_ids, plan, review_queries, challenger_snapshots, ledger
                )
                total_tool_calls += ntools

            if challenger_snapshots and self._model_calls < self.max_model_calls:
                challenger_id, challenger_verification = self._rescue_verify(
                    plan, verification, challenger_snapshots, ledger
                )
                rescue_diagnostics["challenger_product_id"] = challenger_id
                if challenger_verification is not None:
                    rescue_diagnostics["challenger_verification"] = challenger_verification.as_dict()
                    accept, gate_reason = self._strict_monotonic_improvement(
                        verification, challenger_verification
                    )
                    rescue_diagnostics["accepted"] = accept
                    rescue_diagnostics["gate_reason"] = gate_reason
                    if accept:
                        logger.info(
                            "PREFLOW monotonic rescue accepted %s -> %s (%s)",
                            selected_id, challenger_id, gate_reason,
                        )
                        selected_id = challenger_id
                        verification = challenger_verification
                        verification_events.append(verification.as_dict())
                    else:
                        logger.info(
                            "PREFLOW monotonic rescue kept incumbent %s; challenger=%s reason=%s",
                            selected_id, challenger_id, gate_reason,
                        )
                else:
                    rescue_diagnostics["gate_reason"] = "challenger verifier returned no valid candidate"
            elif not rescue_ids:
                rescue_diagnostics["gate_reason"] = "no unopened rescue candidates"
            else:
                rescue_diagnostics["gate_reason"] = "model-call budget unavailable"

        if not selected_id:
            selected_id = ledger.best_observed_candidate()
        finished = bool(selected_id and self.db.get_product(selected_id))
        reasoning = "PREFLOW selected the candidate with the strongest requirement-level support in the bounded evidence search."
        if selected_id and verification and not verification.all_supported:
            reasoning += " Some requirements remained unresolved or contradicted at the benchmark recommendation boundary."

        if selected_id:
            trajectory.append({
                "role": "assistant",
                "content": reasoning,
                "preflow_selected_product_id": selected_id,
                "preflow_verification": verification.as_dict() if verification else None,
            })

        return {
            "predicted_product_id": selected_id,
            "reasoning": reasoning,
            "trajectory": trajectory,
            "reasoning_trace": [],
            "total_tool_calls": total_tool_calls,
            "ask_user_calls": ask_user_calls,
            "get_profile_calls": get_profile_calls,
            "finished": finished,
            "model_calls": self._model_calls,
            "repair_used": repair_used,
            "preflow_rescue": rescue_diagnostics,
            "preflow_requirement_plan": plan.as_list(),
            "preflow_clarification_transcript": clarification_transcript,
            "preflow_verification_events": verification_events,
            "preflow_evidence_ledger": ledger.snapshot(),
        }
