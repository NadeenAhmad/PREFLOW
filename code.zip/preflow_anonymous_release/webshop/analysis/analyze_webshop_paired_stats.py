#!/usr/bin/env python3
"""
Paired task-level uncertainty analysis for WebShop V0/V1/V2.

Inputs:
  v0_500.log
  v1_500.log
  v2_500.log
  analyze_webshop_logs.py  (must be in the same folder)

Outputs:
  webshop_paired_stats.json
  webshop_paired_stats.md

Reports for V0->V1, V1->V2, and V0->V2:
- paired Complete Preference Satisfaction difference
- exact McNemar/binomial test using discordant success pairs
- paired bootstrap 95% CI for success-rate difference
- paired Mean Preference Satisfaction / reward difference
- paired bootstrap 95% CI for mean reward difference

The bootstrap quantifies uncertainty over the evaluated task sample.
It does NOT estimate stochastic variation across repeated model runs.
"""

from __future__ import annotations

import argparse
import json
import math
import sys
from pathlib import Path

import numpy as np

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
try:
    import analyze_webshop_logs as base
except ImportError as e:
    raise SystemExit(
        "Put analyze_webshop_logs.py in the same directory as this script."
    ) from e


def exact_two_sided_binomial(k, n):
    """Two-sided exact sign/binomial test under p=0.5."""
    if n == 0:
        return 1.0
    m = min(k, n - k)
    tail = sum(math.comb(n, i) for i in range(m + 1)) / (2 ** n)
    return min(1.0, 2.0 * tail)


def bootstrap_ci(deltas, rng, n_boot=20000, alpha=0.05):
    deltas = np.asarray(deltas, dtype=float)
    n = len(deltas)

    # Chunk to keep memory modest.
    vals = []
    remaining = n_boot
    while remaining:
        b = min(2000, remaining)
        idx = rng.integers(0, n, size=(b, n))
        vals.append(deltas[idx].mean(axis=1))
        remaining -= b

    vals = np.concatenate(vals)
    lo, hi = np.quantile(vals, [alpha / 2, 1 - alpha / 2])
    return float(lo), float(hi)


def load(path):
    eps = base.episode_outcomes(Path(path))
    if sorted(eps) != list(range(500)):
        raise RuntimeError(
            f"{path}: expected exactly one final record for episodes 0..499; "
            f"found {len(eps)} unique episodes."
        )
    return eps


def compare(name, a, b, rng, n_boot):
    ids = range(500)

    a_success = np.array([bool(a[i]["success"]) for i in ids], dtype=int)
    b_success = np.array([bool(b[i]["success"]) for i in ids], dtype=int)
    a_reward = np.array([float(a[i]["reward"]) for i in ids])
    b_reward = np.array([float(b[i]["reward"]) for i in ids])

    success_delta = b_success - a_success
    reward_delta = b_reward - a_reward

    false_to_true = int(np.sum((a_success == 0) & (b_success == 1)))
    true_to_false = int(np.sum((a_success == 1) & (b_success == 0)))
    discordant = false_to_true + true_to_false

    return {
        "comparison": name,
        "n_tasks": 500,
        "complete_preference_satisfaction": {
            "from_rate": float(a_success.mean()),
            "to_rate": float(b_success.mean()),
            "paired_difference": float(success_delta.mean()),
            "paired_difference_percentage_points": float(100 * success_delta.mean()),
            "bootstrap_95_ci_difference": bootstrap_ci(
                success_delta, rng, n_boot=n_boot
            ),
            "false_to_true": false_to_true,
            "true_to_false": true_to_false,
            "unchanged": int(500 - discordant),
            "exact_mcnemar_p": exact_two_sided_binomial(
                false_to_true, discordant
            ),
        },
        "mean_preference_satisfaction": {
            "from_mean": float(a_reward.mean()),
            "to_mean": float(b_reward.mean()),
            "paired_difference": float(reward_delta.mean()),
            "paired_difference_percentage_points": float(100 * reward_delta.mean()),
            "bootstrap_95_ci_difference": bootstrap_ci(
                reward_delta, rng, n_boot=n_boot
            ),
            "improved_tasks": int(np.sum(reward_delta > 1e-12)),
            "worse_tasks": int(np.sum(reward_delta < -1e-12)),
            "unchanged_tasks": int(np.sum(np.abs(reward_delta) <= 1e-12)),
        },
        "interpretation": (
            "Task-paired analysis. Bootstrap intervals reflect variation across "
            "the evaluated tasks, not repeated stochastic model runs."
        ),
    }


def pct(x):
    return f"{100*x:.2f}%"


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--v0", default="v0_500.log")
    ap.add_argument("--v1", default="v1_500.log")
    ap.add_argument("--v2", default="v2_500.log")
    ap.add_argument("--out-prefix", default="webshop_paired_stats")
    ap.add_argument("--bootstrap", type=int, default=20000)
    ap.add_argument("--seed", type=int, default=2026)
    args = ap.parse_args()

    runs = {
        "V0": load(args.v0),
        "V1": load(args.v1),
        "V2": load(args.v2),
    }

    rng = np.random.default_rng(args.seed)

    results = {
        "analysis_note": (
            "Paired task-level uncertainty only. This does not estimate run-to-run "
            "LLM stochasticity because only one run per condition is available."
        ),
        "bootstrap_replicates": args.bootstrap,
        "bootstrap_seed": args.seed,
        "comparisons": [
            compare("V0 -> V1", runs["V0"], runs["V1"], rng, args.bootstrap),
            compare("V1 -> V2", runs["V1"], runs["V2"], rng, args.bootstrap),
            compare("V0 -> V2", runs["V0"], runs["V2"], rng, args.bootstrap),
        ],
    }

    json_path = Path(args.out_prefix + ".json")
    json_path.write_text(json.dumps(results, indent=2), encoding="utf-8")

    lines = [
        "# WebShop paired task-level analysis",
        "",
        results["analysis_note"],
        "",
    ]
    for r in results["comparisons"]:
        s = r["complete_preference_satisfaction"]
        m = r["mean_preference_satisfaction"]
        lines += [
            f"## {r['comparison']}",
            "",
            (
                f"- Complete Preference Satisfaction: {pct(s['from_rate'])} -> "
                f"{pct(s['to_rate'])}; paired delta "
                f"{s['paired_difference_percentage_points']:+.2f} pp."
            ),
            (
                f"- Success transitions: {s['false_to_true']} false->true, "
                f"{s['true_to_false']} true->false; exact paired p="
                f"{s['exact_mcnemar_p']:.6g}."
            ),
            (
                "- Bootstrap 95% CI for paired Complete Satisfaction delta: "
                f"[{100*s['bootstrap_95_ci_difference'][0]:+.2f}, "
                f"{100*s['bootstrap_95_ci_difference'][1]:+.2f}] pp."
            ),
            (
                f"- Mean Preference Satisfaction: {pct(m['from_mean'])} -> "
                f"{pct(m['to_mean'])}; paired delta "
                f"{m['paired_difference_percentage_points']:+.2f} pp."
            ),
            (
                "- Bootstrap 95% CI for paired Mean Satisfaction delta: "
                f"[{100*m['bootstrap_95_ci_difference'][0]:+.2f}, "
                f"{100*m['bootstrap_95_ci_difference'][1]:+.2f}] pp."
            ),
            (
                f"- Reward improved/worse/unchanged tasks: "
                f"{m['improved_tasks']}/{m['worse_tasks']}/{m['unchanged_tasks']}."
            ),
            "",
        ]

    md_path = Path(args.out_prefix + ".md")
    md_path.write_text("\n".join(lines), encoding="utf-8")

    print(f"Wrote {json_path}")
    print(f"Wrote {md_path}")


if __name__ == "__main__":
    main()
