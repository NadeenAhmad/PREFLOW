#!/usr/bin/env python3
"""Run an unchanged WebShop agent on an ordered custom goal set.

The runner imports the agent file without editing it, replaces only the
WebShop environment factory, and orders the environment's own runtime goals to
match the supplied JSON goals. Using the runtime-equivalent goals preserves
WebShop's generated product prices and reward semantics.

Python 3.8 compatible.
"""

import argparse
import importlib.util
import itertools
import json
import os
import re
import sys
from difflib import SequenceMatcher
from pathlib import Path


_PRICE_SUFFIX_RE = re.compile(
    r",?\s*and\s+price\s+(?:lower\s+than|less\s+than|under|below)\s+"
    r"\$?\s*\d+(?:\.\d+)?\s*dollars?\s*$",
    re.IGNORECASE,
)


def normalize_text(value):
    return " ".join(re.findall(r"[a-z0-9]+", str(value).lower()))


def strip_price_suffix(instruction):
    return _PRICE_SUFFIX_RE.sub("", str(instruction)).strip(" ,")


def normalized_list(values):
    return tuple(normalize_text(v) for v in (values or []))


def candidate_score(supplied, actual):
    """Rank same-ASIN environment goals without using hidden reward data."""
    score = 0.0

    supplied_base = normalize_text(strip_price_suffix(supplied.get("instruction_text", "")))
    actual_base = normalize_text(strip_price_suffix(actual.get("instruction_text", "")))
    if supplied_base == actual_base:
        score += 1000.0
    else:
        score += 100.0 * SequenceMatcher(None, supplied_base, actual_base).ratio()

    if normalized_list(supplied.get("attributes")) == normalized_list(actual.get("attributes")):
        score += 200.0
    if normalized_list(supplied.get("goal_options")) == normalized_list(actual.get("goal_options")):
        score += 200.0
    if normalize_text(supplied.get("name", "")) == normalize_text(actual.get("name", "")):
        score += 100.0
    if normalize_text(supplied.get("query", "")) == normalize_text(actual.get("query", "")):
        score += 50.0

    return score


def load_json_goals(path):
    with path.open("r", encoding="utf-8") as handle:
        goals = json.load(handle)
    if not isinstance(goals, list) or not goals:
        raise SystemExit("--goals must contain a non-empty JSON list")
    for index, goal in enumerate(goals):
        if not isinstance(goal, dict):
            raise SystemExit("Goal at index %d is not a JSON object" % index)
        if not goal.get("asin"):
            raise SystemExit("Goal at index %d has no ASIN" % index)
    return goals


def load_agent_module(agent_path):
    module_name = "webshop_agent_under_test"
    spec = importlib.util.spec_from_file_location(module_name, str(agent_path))
    if spec is None or spec.loader is None:
        raise SystemExit("Could not import agent file: %s" % agent_path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[module_name] = module
    spec.loader.exec_module(module)
    return module


def map_to_runtime_goals(supplied_goals, runtime_goals):
    by_asin = {}
    for goal in runtime_goals:
        asin = str(goal.get("asin", "")).upper()
        by_asin.setdefault(asin, []).append(goal)

    ordered = []
    mapping_rows = []
    failures = []

    for index, supplied in enumerate(supplied_goals):
        asin = str(supplied.get("asin", "")).upper()
        candidates = by_asin.get(asin, [])
        if not candidates:
            failures.append((index, asin, "ASIN not present in runtime goals"))
            continue

        ranked = sorted(
            ((candidate_score(supplied, actual), actual) for actual in candidates),
            key=lambda pair: pair[0],
            reverse=True,
        )
        score, best = ranked[0]

        supplied_base = normalize_text(strip_price_suffix(supplied.get("instruction_text", "")))
        actual_base = normalize_text(strip_price_suffix(best.get("instruction_text", "")))
        same_constraints = (
            normalized_list(supplied.get("attributes")) == normalized_list(best.get("attributes"))
            and normalized_list(supplied.get("goal_options")) == normalized_list(best.get("goal_options"))
        )

        if supplied_base != actual_base or not same_constraints:
            failures.append((index, asin, "no equivalent runtime goal found"))
            continue

        ordered.append(best)
        mapping_rows.append(
            {
                "index": index,
                "asin": asin,
                "exact": supplied == best,
                "runtime_price_changed": supplied.get("price_upper") != best.get("price_upper"),
                "supplied_instruction": supplied.get("instruction_text"),
                "runtime_instruction": best.get("instruction_text"),
                "match_score": score,
            }
        )

    if failures:
        preview = "\n".join(
            "  index=%s asin=%s: %s" % row for row in failures[:10]
        )
        raise SystemExit(
            "Could not safely map %d goal(s):\n%s" % (len(failures), preview)
        )

    return ordered, mapping_rows


def install_custom_environment(agent_module, supplied_goals, mapping_report_path):
    original_get_env = agent_module.get_env

    def get_custom_env():
        env = original_get_env()
        runtime_goals = list(env.server.goals)
        ordered_goals, mapping_rows = map_to_runtime_goals(supplied_goals, runtime_goals)

        # Only the goal list/order changes. Products, prices, search engine,
        # actions, reward function, and all agent/controller code stay untouched.
        env.server.goals = ordered_goals
        env.server.weights = [float(goal.get("weight", 1.0)) for goal in ordered_goals]
        env.server.cum_weights = [0.0] + list(itertools.accumulate(env.server.weights))
        env.server.user_sessions.clear()
        env.server.assigned_instruction_text = None

        exact = sum(1 for row in mapping_rows if row["exact"])
        price_changed = sum(1 for row in mapping_rows if row["runtime_price_changed"])
        print(
            "[Custom Goal Runner] loaded %d ordered goals; exact=%d; "
            "runtime-price-adjusted=%d"
            % (len(ordered_goals), exact, price_changed)
        )

        with mapping_report_path.open("w", encoding="utf-8") as handle:
            json.dump(mapping_rows, handle, indent=2, ensure_ascii=False)
        print("[Custom Goal Runner] mapping report: %s" % mapping_report_path)
        return env

    agent_module.get_env = get_custom_env


def parse_args():
    parser = argparse.ArgumentParser(
        description="Run an unchanged WebShop agent on ordered custom goals."
    )
    parser.add_argument("--agent", required=True, type=Path, help="Agent Python file")
    parser.add_argument("--goals", required=True, type=Path, help="Custom goal JSON list")
    parser.add_argument("--start", type=int, default=0, help="First custom goal index")
    parser.add_argument(
        "--num-episodes",
        type=int,
        default=None,
        help="Number of goals to run; default: all goals after --start",
    )
    parser.add_argument(
        "--cache-dir",
        default="./cache/laser_custom_goals",
        help="Separate Joblib cache directory for this evaluation",
    )
    parser.add_argument(
        "--mapping-report",
        type=Path,
        default=Path("laser_goal_runtime_mapping.json"),
        help="Where to save supplied-to-runtime goal mappings",
    )
    return parser.parse_args()


def main():
    args = parse_args()
    agent_path = args.agent.resolve()
    goals_path = args.goals.resolve()

    if not agent_path.is_file():
        raise SystemExit("Agent file not found: %s" % agent_path)
    if not goals_path.is_file():
        raise SystemExit("Goals file not found: %s" % goals_path)
    if args.start < 0:
        raise SystemExit("--start must be non-negative")

    supplied_goals = load_json_goals(goals_path)
    if args.start >= len(supplied_goals):
        raise SystemExit("--start is outside the %d supplied goals" % len(supplied_goals))

    remaining = len(supplied_goals) - args.start
    num_episodes = remaining if args.num_episodes is None else args.num_episodes
    if num_episodes < 1 or num_episodes > remaining:
        raise SystemExit("--num-episodes must be between 1 and %d" % remaining)

    # The agent reads this variable while being imported. Keeping a separate cache
    # prevents this evaluation from mixing artifacts with previous experiments.
    os.environ["WEBSHOP_CACHE_DIR"] = args.cache_dir

    # Preserve the caller's working directory because the agent intentionally uses
    # it to locate the WebShop repository and writes logs/results relative to it.
    agent_module = load_agent_module(agent_path)
    install_custom_environment(
        agent_module,
        supplied_goals,
        args.mapping_report.resolve(),
    )

    class CustomRunConfig(object):
        task_name = "webshop"
        model_name = agent_module.MODEL
        start = args.start
        num_examples = num_episodes

    print(
        "[Custom Goal Runner] running indices %d..%d with unchanged agent logic"
        % (args.start, args.start + num_episodes - 1)
    )
    agent = agent_module.PreferenceFaithfulAgent(CustomRunConfig())
    rewards = agent.run()

    summary = {
        "start": args.start,
        "num_episodes": num_episodes,
        "mean_reward": (sum(rewards) / len(rewards)) if rewards else None,
        "success_rate": (
            sum(1 for reward in rewards if abs(float(reward) - 1.0) <= 1e-9)
            / float(len(rewards))
        ) if rewards else None,
        "rewards": rewards,
    }
    summary_path = Path(
        "laser_agent_summary_%d-%d.json"
        % (args.start, args.start + num_episodes)
    )
    with summary_path.open("w", encoding="utf-8") as handle:
        json.dump(summary, handle, indent=2)
    print("[Custom Goal Runner] summary: %s" % summary_path.resolve())
    print(json.dumps({k: v for k, v in summary.items() if k != "rewards"}, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
