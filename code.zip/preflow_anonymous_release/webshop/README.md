# PREFLOW on WebShop

## Setup
1. Install WebShop (https://github.com/princeton-nlp/WebShop) at the commit in `patches/UPSTREAM_COMMIT`, then apply `patches/webshop_env.patch`.
2. Copy this folder's files into the WebShop root and set `OPENROUTER_API_KEY`.

## Files
- `preflow_webshop_agent.py`: PREFLOW. It extends LASER's policy (`helper_scripts/prompt_library.py`, from the LASER repository). Components are switched by environment variables: `ENABLE_PREFERENCE_LAYER` (the preference-evidence memory) and `ENABLE_COMMIT_VERIFIER` (the Commit Verifier Agent). With `ENABLE_PREFERENCE_LAYER=0` the agent runs LASER's policy unchanged.
- `run_agent_on_custom_goals.py`: runs the agent on an ordered instruction set (`laser_goals.json`: 100 instructions).
- `run_webshop.sh`: the exact commands for the reported results.
- Baselines (Act, ReAct, ASH, AskAct, LASER) were run with their authors' implementations: [ReAct/Act](https://github.com/ysymyth/ReAct), [ASH](https://github.com/robert1003/ash-prompting), [LASER](https://github.com/Mayer123/LASER).
- `analysis/`: scripts for the ablation tables, paired statistics and figures.

## Notes
- `LOG_GOLD_TARGET=1` prints WebShop's hidden target for each episode, for evaluation diagnostics. The agent never reads it.
- `ENABLE_PLAN_TO_CONTROLLER` (default off) was added after the reported runs. Turning it on left the reward unchanged in all 495 episodes completed in our rerun of the 500-instruction split.

