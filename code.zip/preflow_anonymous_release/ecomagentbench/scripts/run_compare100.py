"""Frozen, resumable PREFLOW run with one shared $22 ledger.

Prediction never sees target/rubric/generation fields. Environment-only persona
and clarification scripts are passed to the agent's public tool constructors.
The scorer is separate and may read labels. Exact matches certify accuracy for
free; they do NOT imply that a judge scored every rubric as satisfied.
"""
from __future__ import annotations

import argparse
from concurrent.futures import FIRST_COMPLETED, ThreadPoolExecutor, wait
from contextlib import contextmanager
import fcntl
import hashlib
import json
import math
import os
from pathlib import Path
import random
import sys
import urllib.error
import urllib.request

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from dotenv import load_dotenv
import yaml

from src.database.product_db import ProductDB
from src.evaluation.judge import RubricJudge
from src.evaluation.metrics import compute_metrics
from src.evaluation.run_eval import _evaluate_one_sample
from src.llm import LLMClient, resolve_llm_config


def digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, ensure_ascii=False).encode()).hexdigest()


def rows(path):
    if not path.exists():
        return {}
    result = {}
    with path.open(encoding='utf-8') as f:
        for line in f:
            if line.strip():
                row = json.loads(line)
                if row['id'] in result:
                    raise ValueError(f'Duplicate ID in {path}: {row["id"]}')
                result[row['id']] = row
    return result


def append(path, row):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('a') as f:
        f.write(json.dumps(row, ensure_ascii=False) + '\n')
        f.flush()
        os.fsync(f.fileno())


@contextmanager
def lock(path):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('a') as f:
        fcntl.flock(f.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        yield


def freeze(path, metadata):
    if path.exists():
        if json.loads(path.read_text()) != metadata:
            raise ValueError(f'Resume fingerprint differs: {path}. Preserve this run; use a new output directory.')
    else:
        path.write_text(json.dumps(metadata, indent=2) + '\n')


def validate_predictions(predictions, samples):
    for sid, pred in predictions.items():
        if (sid not in samples or pred.get('finished') is not True or
                not isinstance(pred.get('predicted_product_id'), str) or
                not pred['predicted_product_id'].strip() or pred.get('error') or
                not isinstance(pred.get('total_tool_calls'), int) or
                not 1 <= pred['total_tool_calls'] <= 100):
            raise ValueError(f'Invalid completed prediction: {sid}')


def validate_judgments(judgments, predictions, samples):
    for sid, judgment in judgments.items():
        if sid not in predictions or judgment.get('predicted_product_id') != predictions[sid].get('predicted_product_id'):
            raise ValueError('Saved judgment and prediction differ')
        if judgment.get('runtime_error'):
            raise ValueError('Runtime-error judgment must not be used as a completed score')
        rubrics = judgment.get('rubric_results', [])
        expected = {r['id'] for r in samples[sid].get('rubrics', [])}
        if (not expected or len(rubrics) != len(expected) or
                {r.get('rubric_id') for r in rubrics} != expected or
                any(type(r.get('satisfied')) is not bool for r in rubrics) or
                judgment.get('all_satisfied') != all(r['satisfied'] for r in rubrics)):
            raise ValueError(f'Malformed rubric judgment for {sid}')


def source_hash():
    paths = sorted((ROOT / 'src').rglob('*.py')) + [Path(__file__)]
    return digest({str(p.relative_to(ROOT)): hashlib.sha256(p.read_bytes()).hexdigest() for p in paths})


def samples_and_ids(config, split):
    path = ROOT / config['data']['benchmark_dir'] / 'benchmark.jsonl'
    samples = {s: r for s, r in rows(path).items() if r.get('sample_status', 'ok') == 'ok'}
    splits = json.loads((ROOT / 'configs/split_dev_test_seed2028.json').read_text())
    if split == 'all662':
        ids = sorted(samples)
        if len(ids) != 662:
            raise ValueError('Expected exactly 662 benchmark tasks')
    elif split == 'compare100':
        ids = json.loads((ROOT / 'configs/compare100_test_seed20261019.json').read_text())['sample_ids']
        if not set(ids) <= set(splits['test_ids']):
            raise ValueError('compare100 must come from the held-out test split')
    else:
        ids = sorted(splits['test_ids' if split == 'test412' else 'dev_ids'])
        if split == 'dev60':
            # Fixed before outcomes: stratified round-robin shuffled dev IDs.
            groups = {}
            rng = random.Random(20261017)
            for sid in ids:
                groups.setdefault(samples[sid]['intent_category'], []).append(sid)
            for group in groups.values():
                rng.shuffle(group)
            ids = []
            while len(ids) < 60:
                for intent in sorted(groups):
                    if groups[intent] and len(ids) < 60:
                        ids.append(groups[intent].pop())
    if len(ids) != len(set(ids)) or not set(ids) <= samples.keys():
        raise ValueError('Invalid manifest IDs')
    return samples, ids, hashlib.sha256(path.read_bytes()).hexdigest()


def metadata(config, benchmark_hash):
    # Config file contains no credentials; reject accidental embedded ones.
    def reject_secrets(obj):
        if isinstance(obj, dict):
            for key, value in obj.items():
                if key.lower() in {'api_key', 'authorization', 'access_token'} and value:
                    raise ValueError('Keep credentials in the environment, not the run configuration')
                reject_secrets(value)
        elif isinstance(obj, list):
            for item in obj:
                reject_secrets(item)
    reject_secrets(config)
    db_path = ROOT / config['data']['db_path']
    stat = db_path.stat()
    return {'code_sha256': source_hash(), 'benchmark_sha256': benchmark_hash,
            'config': config, 'db_size': stat.st_size, 'db_mtime_ns': stat.st_mtime_ns}


def validate_budget_config(config):
    budgets = [resolve_llm_config(config, stage).get('budget') for stage in ('prediction', 'evaluation')]
    if any(not isinstance(b, dict) for b in budgets):
        raise ValueError('Both prediction and evaluation must use the shared spending ledger')
    for budget in budgets:
        total, stage = float(budget['total_limit_usd']), float(budget['stage_limit_usd'])
        if not (math.isfinite(total) and math.isfinite(stage) and 0 < stage <= total <= 32):
            raise ValueError('Budget must be positive and cannot exceed the authorized $22')
    if budgets[0]['total_limit_usd'] != budgets[1]['total_limit_usd']:
        raise ValueError('Stages must share one total cap')
    if Path(budgets[0]['ledger_path']).resolve() != Path(budgets[1]['ledger_path']).resolve():
        raise ValueError('Stages must share the same ledger file')
    if budgets[0]['stage'] == budgets[1]['stage']:
        raise ValueError('Prediction and judging must have separate stage allocations')


def get_json(url, key=None):
    headers = {'Authorization': 'Bearer ' + key} if key else {}
    request = urllib.request.Request(url, headers=headers)
    with urllib.request.urlopen(request, timeout=30) as response:
        return json.load(response)


def preflight(config):
    key = os.environ.get('OPENROUTER_API_KEY')
    if not key:
        print('BLOCKED: configure OPENROUTER_API_KEY locally in .env. No paid calls made.')
        return 3
    key_info = get_json('https://openrouter.ai/api/v1/key', key).get('data', {})
    print(json.dumps({'key': {k: key_info.get(k) for k in (
        'limit', 'limit_remaining', 'limit_reset', 'usage', 'usage_daily',
        'is_free_tier', 'rate_limit')}}, indent=2))
    credit_info = get_json('https://openrouter.ai/api/v1/credits', key).get('data', {})
    remaining = float(credit_info['total_credits']) - float(credit_info['total_usage'])
    print(json.dumps({'account_remaining_usd': remaining}))
    available = {m['id']: m for m in get_json('https://openrouter.ai/api/v1/models')['data']}
    for stage in ('prediction', 'evaluation'):
        cfg = resolve_llm_config(config, stage)
        model = available.get(cfg['model'])
        if model is None:
            raise ValueError(f'Model is unavailable: {cfg["model"]}')
        pricing = model.get('pricing', {})
        actual_in = float(pricing.get('prompt', 'nan')) * 1e6
        actual_out = float(pricing.get('completion', 'nan')) * 1e6
        budget = cfg['budget']
        if not (0 <= actual_in <= budget['input_usd_per_million'] and
                0 <= actual_out <= budget['output_usd_per_million']):
            raise ValueError(f'Model price exceeds configured bound: {cfg["model"]}')
        print(json.dumps({'stage': stage, 'model': cfg['model'], 'pricing': pricing,
                          'context_length': model.get('context_length')}))
    print('Read-only preflight passed. Model listing does not guarantee account-specific generation quota.')
    return 0


def predict(config, samples, ids, output, workers, limit):
    from src.prediction.preflow_compact_agent_v11 import CompactPreflowShoppingAgentV11
    completed = rows(output)
    validate_predictions(completed, samples)
    todo = [sid for sid in ids if sid not in completed]
    if limit:
        todo = todo[:limit]
    db = ProductDB(str(ROOT / config['data']['db_path']))
    llm_config = resolve_llm_config(config, 'prediction')

    def one(sid):
        llm = LLMClient(mode='openrouter', config=llm_config)
        agent = CompactPreflowShoppingAgentV11(db, llm, **config['prediction']['compact_preflow'])
        sample = samples[sid]
        # Ground truth never crosses into the agent, even accidentally.
        visible = {k: sample[k] for k in ('id', 'user_query', 'user_persona', 'clarification_script') if k in sample}
        result = agent.run(visible)
        if not result.get('finished') or not result.get('predicted_product_id'):
            raise RuntimeError(f'{sid}: no valid recommendation')
        if result.get('total_tool_calls', 0) > 100:
            raise RuntimeError(f'{sid}: tool budget exceeded')
        return {**result, 'id': sid, 'intent_category': sample['intent_category'],
                'model': llm.model, 'agent': 'PREFLOW-v11',
                'pilot_task_usage': {**llm.get_token_usage(), 'api_requests': llm.get_api_attempts()}}

    failed = False
    iterator = iter(todo)
    with ThreadPoolExecutor(max_workers=workers) as executor:
        pending = {}
        for sid in list(todo)[:workers]:
            next(iterator)
            pending[executor.submit(one, sid)] = sid
        while pending:
            ready, _ = wait(pending, return_when=FIRST_COMPLETED)
            for future in ready:
                sid = pending.pop(future)
                try:
                    result = future.result()
                    append(output, result)
                    completed[sid] = result
                    print(f'Saved {sid}: {len(set(completed) & set(ids))}/{len(ids)}, tools={result["total_tool_calls"]}', flush=True)
                except Exception as exc:
                    failed = True
                    # Provider exception bodies can contain request data. Store only type.
                    append(output.with_suffix('.failures.jsonl'), {'id': sid, 'error_type': type(exc).__name__})
                    print(f'STOP: {sid}: {type(exc).__name__}. No more tasks scheduled.', flush=True)
            if not failed:
                while len(pending) < workers:
                    sid = next(iterator, None)
                    if sid is None:
                        break
                    pending[executor.submit(one, sid)] = sid
    return 3 if failed else 0


PARTIAL = False


def judgment_cache():
    cache = {}
    for path in [ROOT / 'results/budget22/judgments.jsonl', *sorted((ROOT / 'results/compare100').glob('*/judgments.jsonl'))]:
        for sid, j in rows(path).items():
            if j.get('predicted_product_id') and not j.get('runtime_error'):
                cache[(sid, j['predicted_product_id'])] = j
    return cache


def score(config, samples, ids, prediction_path, output, rubrics):
    predictions = rows(prediction_path)
    cache = judgment_cache()
    if PARTIAL:
        ids = [sid for sid in ids if sid in predictions]
    missing = set(ids) - predictions.keys()
    if missing:
        raise ValueError(f'Cannot score the requested manifest: {len(missing)} predictions missing')
    done = rows(output)
    validate_judgments(done, predictions, samples)
    llm = None
    db = ProductDB(str(ROOT / config['data']['db_path']))
    for sid in ids:
        pred = predictions[sid]
        if sid in done:
            if done[sid]['predicted_product_id'] != pred['predicted_product_id']:
                raise ValueError('Saved judgment and prediction differ')
            continue
        exact = pred.get('predicted_product_id') == samples[sid]['target_product']['product_id']
        if exact and not rubrics:
            continue  # Accuracy known; no invented per-rubric judgments.
        cached = cache.get((sid, pred.get('predicted_product_id')))
        if cached:
            # Verdict depends only on task and product, not on which agent chose it.
            result = {**cached, 'judgment_cached': True}
            validate_judgments({sid: result}, predictions, samples)
            append(output, result)
            done[sid] = result
            print(f'Cached {sid}: {len(done)} judgments saved', flush=True)
            continue
        if llm is None:
            llm = LLMClient(mode='openrouter', config=resolve_llm_config(config, 'evaluation'))
            judge = RubricJudge(llm)
        try:
            result = _evaluate_one_sample(pred, samples[sid], db, judge)
            validate_judgments({sid: result}, predictions, samples)
            if any(r.get('reasoning') == 'Judge response structure mismatch' for r in result['rubric_results']):
                raise ValueError('Judge returned an invalid response structure')
        except Exception as exc:
            print(f'STOP scoring at {sid}: {type(exc).__name__}; completed judgments retained.')
            return 3
        append(output, result)
        done[sid] = result
        print(f'Scored {sid}: {len(done)} judgments saved', flush=True)
    return 0


def report(config, samples, ids, prediction_path, judgments_path, output):
    predictions, judgments = rows(prediction_path), rows(judgments_path)
    if PARTIAL:
        ids = [sid for sid in ids if sid in predictions]
    validate_judgments(judgments, predictions, samples)
    exact = {sid for sid in ids if sid in predictions and predictions[sid].get('predicted_product_id') == samples[sid]['target_product']['product_id']}
    judged_correct = {sid for sid in ids if sid in judgments and judgments[sid].get('all_satisfied')}
    unresolved = set(ids) - exact - judgments.keys()
    correct = len(exact | judged_correct)
    summary = {'n': len(ids), 'prediction_count': len(set(ids) & predictions.keys()),
               'exact_correct': len(exact), 'confirmed_correct': correct,
               'judgment_count': len(set(ids) & judgments.keys()),
               'unresolved_count': len(unresolved), 'accuracy_complete': not unresolved,
               'accuracy_lower_bound': correct / len(ids),
               'accuracy_upper_bound': (correct + len(unresolved)) / len(ids),
               'rubric_metrics_complete': set(ids) <= judgments.keys(),
               'exceeds_opus_published_57_1': len(ids) == 662 and set(ids) <= predictions.keys() and correct >= 379}
    if summary['rubric_metrics_complete']:
        summary['official_metrics'] = compute_metrics([judgments[sid] for sid in ids], samples)
    budget_cfg = resolve_llm_config(config, 'prediction').get('budget') if config.get('prediction') else None
    if budget_cfg and Path(budget_cfg['ledger_path']).exists():
        from src.llm.budget import BudgetLedger
        summary['budget'] = BudgetLedger(budget_cfg).snapshot()
    if set(ids) <= set(json.loads((ROOT / 'configs/split_dev_test_seed2028.json').read_text())['dev_ids']):
        prior = rows(ROOT / 'data/benchmark/predictions_preflow_compact_v9.1_google_gemini-3-flash-preview_full662.jsonl')
        base = {sid for sid in ids if prior[sid]['predicted_product_id'] == samples[sid]['target_product']['product_id']}
        paired = set(ids) & predictions.keys()
        summary['dev_comparison'] = {'v91_exact_all_requested': len(base), 'v91_exact_paired': len(base & paired),
                                     'v11_exact_paired': len(exact), 'paired_count': len(paired),
                                     'gained': len(exact - base), 'lost': len((base & paired) - exact),
                                     'complete': set(ids) <= predictions.keys()}
    output.write_text(json.dumps(summary, indent=2) + '\n')
    print(json.dumps(summary, indent=2))


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('action', choices=['preflight', 'prepare', 'predict', 'score', 'report'])
    ap.add_argument('--config', default='configs/compare100_judge.yaml')
    ap.add_argument('--split', choices=['dev60', 'dev250', 'test412', 'all662', 'compare100'], default='dev60')
    ap.add_argument('--output-dir', default='results/compare100/preflow_deepseek')
    ap.add_argument('--workers', type=int, default=2)
    ap.add_argument('--limit', type=int, default=0)
    ap.add_argument('--predictions', default=None, help='Score this prediction file (any agent) instead of OUTPUT_DIR/predictions.jsonl')
    ap.add_argument('--partial', action='store_true', help='Score/report only tasks that have predictions')
    ap.add_argument('--rubrics', action='store_true', help='Also judge exact matches for complete rubric metrics')
    args = ap.parse_args()
    global PARTIAL
    PARTIAL = args.partial
    if PARTIAL and args.action == 'report':
        pass
    os.chdir(ROOT)
    load_dotenv(ROOT / '.env')
    config = yaml.safe_load(Path(args.config).read_text())
    validate_budget_config(config)
    if args.action == 'preflight':
        return preflight(config)
    samples, ids, benchmark_hash = samples_and_ids(config, args.split)
    out = Path(args.output_dir)
    out.mkdir(parents=True, exist_ok=True)
    manifest = out / (args.split + '.manifest.json')
    freeze(manifest, {'sample_ids': ids, 'benchmark_sha256': benchmark_hash})
    prediction_path, judgment_path = Path(args.predictions) if args.predictions else out / 'predictions.jsonl', out / 'judgments.jsonl'
    if args.action == 'prepare':
        print(f'Prepared {len(ids)} IDs at {manifest}; no API calls.')
        return 0
    if args.action == 'report':
        report(config, samples, ids, prediction_path, judgment_path, out / (args.split + '.summary.json'))
        return 0
    if not 1 <= args.workers <= 4 or args.limit < 0:
        raise ValueError('Workers must be 1–4; limit must be nonnegative')
    if not os.environ.get('OPENROUTER_API_KEY'):
        print('BLOCKED: configure OPENROUTER_API_KEY locally in .env. No paid calls made.')
        return 3
    with lock(out / 'run.lock'):
        if not (out / 'run.fingerprint.json').exists() and any(p.exists() and p.stat().st_size for p in ((judgment_path,) if args.predictions else (prediction_path, judgment_path))):
            raise ValueError('Existing outputs have no provenance fingerprint; refusing to adopt them')
        freeze(out / 'run.fingerprint.json', metadata(config, benchmark_hash))
        if args.action == 'predict':
            return predict(config, samples, ids, prediction_path, args.workers, args.limit)
        return score(config, samples, ids, prediction_path, judgment_path, args.rubrics)


if __name__ == '__main__':
    try:
        sys.exit(main())
    except (ValueError, OSError, RuntimeError) as exc:
        print(f'{type(exc).__name__}: {exc}', file=sys.stderr)
        sys.exit(3)
