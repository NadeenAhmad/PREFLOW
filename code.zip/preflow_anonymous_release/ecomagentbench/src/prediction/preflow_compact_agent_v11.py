"""PREFLOW v11: retained candidates, bounded public-tool search and explicit slots.

Four logical model calls: plan, shortlist/refine, verify/repair, optional final
comparison. Local catalog exploration does not require a model call per tool.
The policy never reads task targets, rubric labels or clarification scripts.
"""
from __future__ import annotations

import json
import logging
import re
from typing import Any

from src.preflow import EvidenceLedger, RequirementPlan
from src.preflow.state import normalize_verification_payload
from src.preflow.search_policy import query_variants, rank_candidates, numeric_contradictions
from src.prediction.preflow_compact_agent_v9 import _clean_text, _dedupe
from src.prediction.preflow_compact_agent_v9_1 import CompactPreflowShoppingAgentV91
from src.prompts.preflow_compact_v11 import PLAN_PROMPT, SHORTLIST_PROMPT, VERIFY_PROMPT, FINAL_PROMPT
from src.tools import create_tools

logger = logging.getLogger(__name__)

_QUESTIONS = {
    "price": "What is your budget for this item?",
    "special feature": "Are there any special features you require?",
    "finish type": "Do you require a specific finish type?",
    "shape": "Do you require a specific product shape?",
    "mounting type": "Do you require a specific mounting style?",
    "connector type": "Do you need a specific connector type?",
    "connectivity technology": "Do you need a specific connectivity technology?",
    "screen size": "Do you require a specific screen size?",
    "recommended uses for product": "What will you mainly use it for?",
    "color": "Do you require a specific color?",
    "material": "Do you require a specific material?",
    "average_rating": "Do you have a minimum average rating requirement?",
    "rating_number": "Do you require a minimum number of customer ratings?",
}
_NOISY_FIELDS = {"asin", "upc", "item model number", "model number", "manufacturer", "brand",
                 "date first available", "best sellers rank", "package dimensions", "item weight",
                 "product dimensions", "country of origin", "department", "manufacturer part number",
                 "part number", "is discontinued by manufacturer"}
_STOP = {"the", "a", "an", "i", "it", "and", "or", "to", "of", "for", "with", "my", "is", "be",
         "must", "need", "want", "prefer", "please", "should", "only", "that", "have", "require",
         "would", "like", "looking", "specific", "product", "item", "this", "are", "in", "on"}


class CompactPreflowShoppingAgentV11(CompactPreflowShoppingAgentV91):
    """v9-compatible constructor; task state and tool limits are instance-local."""

    def __init__(self, *args: Any, tool_call_cap: int = 99, **kwargs: Any) -> None:
        super().__init__(*args, **kwargs)
        self.max_model_calls = min(4, max(3, self.max_model_calls))
        self.max_questions = min(4, self.max_questions)
        self.tool_call_cap = min(99, max(1, int(tool_call_cap)))
        self.max_evidence_chars_per_candidate = min(3200, self.max_evidence_chars_per_candidate)

    def _call(self, name: str, args: dict) -> dict:
        if self._tool_calls >= self.tool_call_cap:
            self._blocked_tools += 1
            return {}
        self._tool_calls += 1
        result = self._tools[name].call(args)
        self._ledger.record_tool_result(name, args, result)
        self._trajectory.append({"role": "tool", "name": name, "arguments": args, "result": result})
        return result if isinstance(result, dict) else {}

    def _search(self, queries: list[str], *, call_budget: int, paginate: bool = True) -> int:
        """Union short query families, page only productive result sets, retain all rows."""
        start = self._tool_calls
        next_pages = []
        for query in _dedupe(queries):
            for variant in query_variants(query, entity=self._entity, max_variants=3):
                if self._tool_calls - start >= call_budget or self._tool_calls >= self.tool_call_cap:
                    return self._tool_calls - start
                if (variant.casefold(), 0) in self._seen_searches:
                    continue
                self._seen_searches.add((variant.casefold(), 0))
                result = self._call("search_products", {"query": variant, "page": 0})
                products = result.get("products", []) or []
                novel = self._add_rows(products, variant)
                self._search_diagnostics.append({"query": variant, "page": 0, "hits": len(products), "novel": novel})
                # total_found is capped by the search tool; a full page is the only
                # reliable indication that an additional page might be useful.
                if paginate and len(products) == 20 and novel >= 8:
                    next_pages.append(variant)
                if products:
                    break
        # Cover distinct query families before deepening a popular first query.
        for variant in next_pages:
            if self._tool_calls - start >= call_budget or self._tool_calls >= self.tool_call_cap:
                break
            if (variant.casefold(), 1) in self._seen_searches:
                continue
            self._seen_searches.add((variant.casefold(), 1))
            more = self._call("search_products", {"query": variant, "page": 1}).get("products", []) or []
            new = self._add_rows(more, variant)
            self._search_diagnostics.append({"query": variant, "page": 1, "hits": len(more), "novel": new})
        return self._tool_calls - start

    def _add_rows(self, products: list[dict], query: str) -> int:
        new = 0
        for product in products:
            pid = str(product.get("product_id", ""))
            if not pid:
                continue
            new += pid not in self._seen_products
            self._seen_products.add(pid)
            # Keep source membership for diversity ranking; never truncate a pool
            # merely because another query or store appeared first.
            self._rows.append({"product_id": pid, "title": _clean_text(product.get("title"), 300), "query": query})
        return new

    def _stores(self, plan: RequirementPlan, max_calls: int = 4) -> None:
        calls = 0
        for store in self._rescue_required_store_names(plan):
            for page in range(2):
                if calls >= max_calls or self._tool_calls >= self.tool_call_cap:
                    return
                result = self._call("get_store_products", {"store_name": store, "page": page})
                calls += 1
                products = result.get("products", []) or []
                self._add_rows(products, f"store:{store}")
                if len(products) < 20 or (page + 1) * 20 >= int(result.get("total_count", 0) or 0):
                    break

    def _rank(self, plan: RequirementPlan, limit: int = 80, excluded: set[str] | None = None) -> list[str]:
        rows = [r for r in self._rows if r["product_id"] not in (excluded or set())]
        return rank_candidates(rows, plan.as_list(), entity=self._entity, limit=limit)

    def _inspect(self, ids: list[str], plan: RequirementPlan, review_queries: list[str], review_budget: int = 8) -> dict[str, dict]:
        snapshots: dict[str, dict] = {}
        for pid in _dedupe(ids):
            if self._tool_calls >= self.tool_call_cap - 1:
                break  # reserve a statistics call when possible
            product = self._call("get_product_details", {"product_id": pid}).get("product", {}) or {}
            if not product.get("title"):
                continue
            snapshots[pid] = {"product_id": pid, "title": _clean_text(product.get("title"), 300),
                              "store": product.get("store"), "price": product.get("price"),
                              "details": {str(k): _clean_text(v, 320) for k, v in (product.get("details", {}) or {}).items()},
                              "features": [_clean_text(x, 400) for x in (product.get("features", []) or [])],
                              "description": [_clean_text(x, 500) for x in (product.get("description", []) or [])],
                              "rating": {}, "reviews": []}
        ids = list(snapshots)
        for offset in range(0, len(ids), 10):
            stats = self._call("get_product_review_stats", {"product_ids": ids[offset:offset + 10]})
            for item in stats.get("products", []) or []:
                if item.get("product_id") in snapshots:
                    snapshots[item["product_id"]]["rating"] = {k: item.get(k) for k in ("average_rating", "rating_number")}
        calls = 0
        # Cover every candidate once before spending a second query on one item.
        for query in _dedupe(review_queries, 2):
            for pid in ids:
                if calls >= review_budget or self._tool_calls >= self.tool_call_cap:
                    break
                result = self._call("get_review_content", {"product_id": pid, "query": query})
                calls += 1
                reviews = result.get("reviews", []) or []
                if not reviews and len(query.split()) > 1 and calls < review_budget:
                    result = self._call("get_review_content", {"product_id": pid, "query": query.split()[0]})
                    calls += 1
                    reviews = result.get("reviews", []) or []
                snapshots[pid]["reviews"].extend({"rating": r.get("rating"), "title": _clean_text(r.get("title"), 100),
                                                 "text": _clean_text(r.get("text"), 650)} for r in reviews[:2])
        return snapshots

    def _slots(self, plan: RequirementPlan, snapshots: dict[str, dict]) -> list[dict]:
        fields: dict[str, set[str]] = {"price": set()}
        for snapshot in snapshots.values():
            if snapshot.get("price") is not None:
                fields["price"].add(str(snapshot["price"]))
            for key, value in snapshot.get("details", {}).items():
                fields.setdefault(key.casefold().strip(), set()).add(str(value).casefold())
            for key, value in snapshot.get("rating", {}).items():
                if value is not None:
                    fields.setdefault(key, set()).add(str(value))
        slots = []
        for name, values in fields.items():
            terms = {"price": ("price", "budget", "cost", "dollar", "$"),
                     "average_rating": ("rating", "stars"), "rating_number": ("rating count", "number of ratings")}.get(name, (name,))
            covered = any(any(term in r.field_hint.casefold() or term in r.text.casefold() for term in terms) for r in plan.requirements)
            if name == "price":
                # Merely mentioning "budget" (e.g. budget headphones) does not
                # specify a spending limit. Ask unless a value or waiver exists.
                covered = any(any(term in r.field_hint.casefold() or term in r.text.casefold() for term in terms)
                              and bool(re.search(r"\d|no (?:budget|price) limit|any price", r.text, re.I))
                              for r in plan.requirements)
            answered = getattr(self, "_answered_slots", {}).get(name)
            state = "unconstrained" if answered == "unconstrained" else "specified" if covered or answered else "unknown"
            slots.append({"slot": name, "state": state,
                          "observed_values": sorted(values)[:8], "varies": len(values) > 1,
                          "origin": "transaction.price" if name == "price" else "observed_product_field"})
        return slots

    def _clarify(self, plan: RequirementPlan, snapshots: dict[str, dict]) -> list[dict]:
        if not snapshots:
            return []
        slots = self._slots(plan, snapshots)
        bank_order = {k: i for i, k in enumerate(_QUESTIONS)}
        candidates = [s for s in slots if s["state"] == "unknown" and s["slot"] not in _NOISY_FIELDS
                      and len(s["slot"]) < 39 and (s["slot"] in _QUESTIONS or s["varies"])]
        candidates.sort(key=lambda s: (0 if s["slot"] == "price" else 3 if s["slot"] == "rating_number" else 1 if s["varies"] else 2,
                                       bank_order.get(s["slot"], 20), s["slot"]))
        transcript = []
        for slot in candidates[:self.max_questions]:
            if self._tool_calls >= self.tool_call_cap:
                break
            key = slot["slot"]
            question = _QUESTIONS.get(key, f"Do you require a specific {key}?")
            response = self._call("ask_user", {"question": question[:99]})
            answer = str(response.get("user_response", ""))
            answer_field = self._answer_field(answer, key, snapshots)
            transcript.append({"question": question[:99], "answer": answer, "slot": answer_field, "requested_slot": key})
            if re.search(r"\b(?:no preference|do not care|don't care|any (?:color|material|price)|no budget limit)\b", answer, re.I):
                self._answered_slots[key] = "unconstrained"
            elif not self._is_nonanswer(answer):
                # Preserve the actual answer; do not relabel incidental matches as
                # the requested slot when the answer names another property.
                plan.add(answer, source="clarification", field_hint=answer_field)
                if answer_field:
                    self._answered_slots[answer_field] = "specified"
            if response.get("turns_remaining") == 0:
                break
        return transcript

    @staticmethod
    def _answer_field(answer: str, requested: str, snapshots: dict[str, dict]) -> str:
        """An answer can address another field; the question is not evidence."""
        text = answer.casefold()
        if re.search(r"(?:\$\s*\d|\d\s*(?:dollars|usd)\b|\bbudget\b.*\d)", text):
            return "price"
        if re.search(r"\d[\d,]*\s+(?:customer\s+)?(?:ratings|reviews)\b", text):
            return "rating_number"
        if re.search(r"\d(?:\.\d+)?\s*(?:stars?\b|out of 5)", text):
            return "average_rating"
        matches: dict[str, int] = {}
        for snapshot in snapshots.values():
            for raw_key, value in snapshot.get("details", {}).items():
                key = raw_key.casefold().strip()
                if key in _NOISY_FIELDS:
                    continue
                score = 3 if key in text else 0
                val = str(value).casefold().strip()
                if len(val) >= 3 and val in text:
                    score += 2
                if score:
                    matches[key] = max(matches.get(key, 0), score)
        if matches:
            return max(matches, key=lambda k: (matches[k], k == requested))
        # A generic unanswered question must not become a specified budget slot.
        return ""

    def _clarification_queries(self, transcript: list[dict]) -> list[str]:
        queries = []
        for turn in transcript:
            answer = turn["answer"]
            if self._is_nonanswer(answer) or turn["slot"] in {"price", "average_rating", "rating_number"}:
                continue
            tokens = [t for t in re.findall(r"[A-Za-z0-9][A-Za-z0-9+.-]*", answer)
                      if t.casefold() not in _STOP and len(t) > 1]
            if tokens:
                queries.append(f"{self._entity} {' '.join(tokens[:2])}")
        return _dedupe(queries, 3)

    def _evidence_text(self, plan: RequirementPlan, snapshots: dict[str, dict]) -> str:
        tokens = set(re.findall(r"[a-z0-9]+", plan.render().casefold())) - _STOP
        blocks = []
        per_candidate_limit = min(self.max_evidence_chars_per_candidate, max(1200, 28000 // max(1, len(snapshots))))
        for pid, snapshot in snapshots.items():
            data = dict(snapshot)
            def relevance(value: Any) -> int:
                return len(tokens & set(re.findall(r"[a-z0-9]+", str(value).casefold())))
            details = sorted(snapshot.get("details", {}).items(), key=lambda kv: (-relevance(kv), kv[0]))
            data["details"] = dict(details[:16])
            data["features"] = sorted(snapshot.get("features", []), key=lambda x: -relevance(x))[:4]
            data["description"] = sorted(snapshot.get("description", []), key=lambda x: -relevance(x))[:1]
            data["numeric_contradictions"] = numeric_contradictions(plan.as_list(), snapshot)
            # Preserve valid JSON and relevant details; do not slice serialized
            # evidence midway through a value or silently lose all reviews.
            while len(json.dumps(data, ensure_ascii=False)) > per_candidate_limit:
                if data["description"]:
                    data["description"].pop()
                elif data["features"]:
                    data["features"].pop()
                elif len(data["details"]) > 2:
                    data["details"].pop(next(reversed(data["details"])))
                else:
                    break
            blocks.append(json.dumps(data, ensure_ascii=False, separators=(",", ":")))
        return "\n".join(blocks)

    def _verify(self, plan: RequirementPlan, snapshots: dict[str, dict], incumbent: str | None = None):
        if not snapshots:
            return None, None, []
        payload = self._json_call(FINAL_PROMPT if incumbent else VERIFY_PROMPT,
                                 "REQUIREMENTS:\n" + json.dumps(plan.as_list(), ensure_ascii=False)
                                 + ("\nINCUMBENT: " + incumbent if incumbent else "")
                                 + "\nCANDIDATE EVIDENCE:\n" + self._evidence_text(plan, snapshots), max_tokens=1900)
        pid = str(payload.get("selected_product_id", ""))
        if pid not in snapshots:
            pid = incumbent if incumbent in snapshots else next(iter(snapshots))
            # A verification for an invalid/other ID is not evidence for fallback.
            payload = {"selected_product_id": pid, "results": [], "repair_search_queries": []}
        verification = normalize_verification_payload(payload, plan, pid)
        for rid, reason in numeric_contradictions(plan.as_list(), snapshots[pid]).items():
            verification.statuses[rid] = "contradicted"
            verification.reasons[rid] = reason
        for rid, status in list(verification.statuses.items()):
            if status == "supported" and not self._quote_grounded(verification.evidence_quotes.get(rid, ""), snapshots[pid]):
                verification.statuses[rid] = "unresolved"
                verification.reasons[rid] = "Supporting quote could not be located in this candidate's observed evidence."
        self._ledger.set_verification(verification)
        repairs = _dedupe([str(x) for x in payload.get("repair_search_queries", []) if isinstance(x, str)], 3)
        return pid, verification, repairs

    @staticmethod
    def _quote_grounded(quote: str, snapshot: dict) -> bool:
        """Require a literal evidence span before declaring support sufficient to stop."""
        def normalized(value: str) -> str:
            return " ".join(re.findall(r"[a-z0-9]+", str(value).casefold()))
        evidence = " " + normalized(json.dumps(snapshot, ensure_ascii=False)) + " "
        # A verifier may join several short quotations with ellipses/semicolons.
        # At least one complete span must be present in the selected product.
        parts = re.split(r";|\n|\.\.\.|…", quote or "")
        spans = [normalized(part) for part in parts]
        return any(span and " " + span + " " in evidence for span in spans)

    def run(self, sample: dict) -> dict[str, Any]:
        self._model_calls = self._tool_calls = self._blocked_tools = 0
        self.json_recoveries = self.json_retries = 0
        self._tools = create_tools(self.db, sample_data=sample)
        self._ledger = EvidenceLedger()
        self._rows: list[dict] = []
        self._seen_products: set[str] = set()
        self._seen_searches: set[tuple[str, int]] = set()
        self._search_diagnostics: list[dict] = []
        self._trajectory: list[dict] = []
        self._answered_slots: dict[str, str] = {}
        query = str(sample["user_query"])
        profile = self._call("get_user_profile", {}).get("profile", {}) or {}
        planning = self._json_call(PLAN_PROMPT, "REQUEST:\n" + query + "\nPROFILE:\n" + json.dumps(profile, ensure_ascii=False), max_tokens=1000)
        plan = self._build_plan(query, profile, planning)
        self._entity = _clean_text(planning.get("product_entity"), 90)
        if not self._entity:
            self._entity = " ".join(query.split()[:3])
        queries = [str(q) for q in planning.get("search_queries", []) if isinstance(q, str)]
        self._search(queries or [self._entity], call_budget=16)
        self._stores(plan)
        if not self._rows:
            self._search([self._entity], call_budget=4)
        ranked = self._rank(plan)
        row_by_id = {r["product_id"]: r for r in self._rows}
        shortlist = self._json_call(SHORTLIST_PROMPT, "REQUIREMENTS:\n" + plan.render()
                                   + "\nTRIED QUERIES:\n" + json.dumps(sorted({q for q, _ in self._seen_searches}))
                                   + "\nSEARCH RESULTS:\n" + json.dumps([row_by_id[pid] for pid in ranked], ensure_ascii=False), max_tokens=650)
        ids = _dedupe([str(pid) for pid in shortlist.get("candidate_ids", []) if str(pid) in row_by_id], 7)
        if not ids:
            ids = ranked[:7]
        review_queries = _dedupe([str(q) for q in planning.get("review_queries", []) if isinstance(q, str)], 2)
        snapshots = self._inspect(ids, plan, review_queries, review_budget=8)
        clarifications = self._clarify(plan, snapshots)
        # Search again after dialogue, so newly learned preferences can retrieve a
        # new product instead of only eliminating the original shortlist.
        refine = [str(q) for q in shortlist.get("refine_queries", []) if isinstance(q, str)]
        self._search(self._clarification_queries(clarifications) + refine, call_budget=12)
        extra_ids = self._rank(plan, limit=3, excluded=set(snapshots))
        snapshots.update(self._inspect(extra_ids, plan, review_queries, review_budget=3))
        selected, verification, repair_queries = self._verify(plan, snapshots)
        events = [verification.as_dict()] if verification else []
        incumbent = selected
        rescue = {"attempted": False, "baseline_selected_product_id": selected, "accepted": False,
                  "candidate_ids_opened": [], "gate_reason": "all requirements supported"}
        if verification and not verification.all_supported and self._model_calls < self.max_model_calls:
            rescue["attempted"] = True
            self._search(repair_queries, call_budget=min(10, max(0, self.tool_call_cap - self._tool_calls - 9)))
            challenger_ids = self._rank(plan, limit=6, excluded=set(snapshots))
            rescue["candidate_ids_opened"] = challenger_ids
            challengers = self._inspect(challenger_ids, plan, review_queries, review_budget=4)
            # No previously inspected alternative expires. The prompt compactor
            # allocates a shared character budget across the complete retained set.
            retained = dict(snapshots)
            retained.update(challengers)
            if challengers or (len(retained) > 1 and numeric_contradictions(plan.as_list(), snapshots[selected])):
                chosen, checked, _ = self._verify(plan, retained, incumbent=selected)
                if checked:
                    # Reject a deterministic numeric regression; model-level
                    # comparisons may correct earlier overconfident support.
                    old_numeric = numeric_contradictions(plan.as_list(), snapshots[selected])
                    new_numeric = numeric_contradictions(plan.as_list(), retained[chosen])
                    accept = not (set(new_numeric) - set(old_numeric))
                    rescue.update(challenger_product_id=chosen, accepted=accept and chosen != selected,
                                  gate_reason="joint evidence comparison" if accept else "numeric contradiction regression")
                    if accept:
                        selected, verification = chosen, checked
                        events.append(checked.as_dict())
        if not selected:
            selected = self._rank(plan, limit=1)[0] if self._rows else None
        reasoning = "Selected using the visible request, saved profile, clarification answers and inspected product evidence."
        recommendation = self._tools["recommend_product"].call({"product_id": selected or "", "reasoning": reasoning})
        self._tool_calls += 1
        self._trajectory.append({"role": "tool", "name": "recommend_product", "arguments": {"product_id": selected, "reasoning": reasoning}, "result": recommendation})
        finished = bool((recommendation or {}).get("recommended_product"))
        return {"predicted_product_id": selected, "reasoning": reasoning, "trajectory": self._trajectory, "reasoning_trace": [],
                "total_tool_calls": self._tool_calls, "ask_user_calls": len(clarifications), "get_profile_calls": 1,
                "finished": finished, "model_calls": self._model_calls, "repair_used": rescue["attempted"],
                "preflow_rescue": rescue, "preflow_requirement_plan": plan.as_list(),
                "preflow_clarification_transcript": clarifications, "preflow_verification_events": events,
                "preflow_evidence_ledger": self._ledger.snapshot(), "preflow_slots": self._slots(plan, snapshots),
                "search_diagnostics": self._search_diagnostics, "tool_cap_reached": self._blocked_tools > 0 or self._tool_calls >= self.tool_call_cap + 1,
                "tool_calls_blocked_by_cap": self._blocked_tools, "preflow_version": "v11",
                "json_recoveries": self.json_recoveries, "json_retries": self.json_retries}


__all__ = ["CompactPreflowShoppingAgentV11"]
