"""Checkpointed runner for the paper's EComAgentBench agent on a fixed task manifest.

NEW file. The original src/prediction/run_predict.py is untouched; this runner calls
the same agent and writes the same prediction fields, so the official
src/evaluation/run_eval.py scores its output unchanged.

What it adds over run_predict.py:
  * runs a fixed manifest (e.g. the 50-task seed-2026 set) or all 662 tasks;
  * appends + fsyncs one JSON line per finished task and resumes automatically;
  * counts every agent outcome as done, including hitting max_steps or
    recommending an unknown id (those are scored as wrong, as in the paper);
    API/infrastructure exceptions are NOT checkpointed: they go to
    <output>.failures.jsonl, no new tasks start, and the task reruns on resume;
  * per-task API calls / tokens / upper-bound USD estimate and a --budget-usd guard;
  * Ctrl+C once = finish running tasks then stop; twice = abandon them after the
    current API call (they rerun on resume);
  * refuses to resume if the config, agent code, prompt or tools changed
    (frozen setup), unless --allow-changed-setup is passed.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import logging
import os
import signal
import threading
import time
from concurrent.futures import FIRST_COMPLETED, ThreadPoolExecutor, wait
from pathlib import Path

import yaml
from dotenv import load_dotenv

from src.database.product_db import ProductDB
from src.llm import LLMClient, resolve_prediction_mode_config
from src.llm.utils import normalize_provider, resolve_api_key, resolve_model
from src.prediction.agent import ShoppingAgent
from src.prediction.agent_gemini_safe import GeminiSafeShoppingAgent

logger = logging.getLogger(__name__)

AGENTS = {
    "gemini_safe": GeminiSafeShoppingAgent,
    "original": ShoppingAgent,
}

# Files whose content defines the agent's behaviour. Hashed into the run lock.
_SETUP_FILES = [
    "src/prediction/agent.py",
    "src/prediction/agent_gemini_safe.py",
    "src/prompts/agent.py",
    "src/llm/client.py",
    "src/llm/utils.py",
    "src/llm/providers/openrouter.py",
    "src/llm/providers/openai.py",
    "src/llm/providers/gemini.py",
]


class TaskAbandoned(RuntimeError):
    """Raised inside a task when the user asked for an immediate stop."""


class StoppableLLMClient(LLMClient):
    """LLMClient that refuses to start a new API call after a hard stop."""

    def __init__(self, *args, hard_stop: threading.Event, **kwargs):
        super().__init__(*args, **kwargs)
        self._hard_stop = hard_stop

    def chat(self, *args, **kwargs):
        if self._hard_stop.is_set():
            raise TaskAbandoned("hard stop requested by user")
        return super().chat(*args, **kwargs)


# ----------------------------------------------------------------------------- helpers

def _sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def _setup_fingerprint(config_path: str, mode: str, agent_name: str, llm_config: dict,
                       max_steps: int, ids: list[str]) -> dict:
    files = {}
    for rel in _SETUP_FILES + sorted(str(p) for p in Path("src/tools").glob("*.py")):
        p = Path(rel)
        if p.is_file():
            files[rel] = _sha256_file(p)
    public_llm = {k: v for k, v in llm_config.items() if k not in {"api_key"}}
    return {
        "config_file": config_path,
        "config_sha256": _sha256_file(Path(config_path)),
        "mode": mode,
        "agent": agent_name,
        "max_steps": max_steps,
        "llm_config": public_llm,
        "task_ids_sha256": hashlib.sha256("\n".join(ids).encode()).hexdigest(),
        "n_tasks": len(ids),
        "code_sha256": files,
    }


def _load_benchmark(path: str) -> dict[str, dict]:
    out: dict[str, dict] = {}
    with open(path, encoding="utf-8") as f:
        for line in f:
            if line.strip():
                s = json.loads(line)
                if s.get("sample_status", "ok") == "ok":
                    out[s["id"]] = s
    return out


def _load_checkpoint(path: Path) -> dict[str, dict]:
    done: dict[str, dict] = {}
    if not path.exists():
        return done
    with open(path, encoding="utf-8") as f:
        for n, line in enumerate(f, 1):
            if not line.strip():
                continue
            try:
                row = json.loads(line)
            except json.JSONDecodeError as exc:
                raise ValueError(
                    f"{path} line {n} is corrupt ({exc}). This usually means the process was "
                    "killed mid-write. Delete that last line and rerun."
                ) from exc
            done[str(row["id"])] = row
    return done


def _append_jsonl(path: Path, row: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "a", encoding="utf-8") as f:
        f.write(json.dumps(row, ensure_ascii=False) + "\n")
        f.flush()
        os.fsync(f.fileno())


def _derive_diagnostics(result: dict) -> dict:
    """Same diagnostics for both agent variants (original agent does not return them)."""
    if "stop_reason" in result:
        return {
            "steps_used": result["steps_used"],
            "multi_tool_turns": result["multi_tool_turns"],
            "stop_reason": result["stop_reason"],
        }
    assistant_turns = [m for m in result["trajectory"] if m.get("role") == "assistant"]
    multi = sum(1 for m in assistant_turns if len(m.get("tool_calls") or []) > 1)
    if not result["finished"]:
        reason = "max_steps_exhausted"
    elif result["predicted_product_id"]:
        reason = "recommend_product"
    else:
        last_calls = (assistant_turns[-1].get("tool_calls") or []) if assistant_turns else []
        if last_calls and last_calls[0]["function"]["name"] == "recommend_product":
            reason = "recommend_product_unknown_id"
        else:
            reason = "no_tool_after_reminder"
    return {"steps_used": len(assistant_turns), "multi_tool_turns": multi, "stop_reason": reason}


def _usd(usage: dict, prices: dict) -> float:
    return (
        usage.get("input_tokens", 0) / 1e6 * float(prices.get("input", 0.0))
        + usage.get("output_tokens", 0) / 1e6 * float(prices.get("output", 0.0))
    )


# ----------------------------------------------------------------------------- one task

def _run_one(sample: dict, *, db, agent_cls, max_steps: int, mode: str, llm_config: dict,
             prices: dict, hard_stop: threading.Event, agent_name: str) -> dict:
    """Run one task with its own LLM client so usage is exact per task.

    Returns {"ok": True, "row": ...} or {"ok": False, "error": ..., "usage": ...}.
    """
    llm = StoppableLLMClient(mode=mode, config=llm_config, hard_stop=hard_stop)
    agent = agent_cls(db, llm, max_steps=max_steps)
    t0 = time.time()
    try:
        result = agent.run(sample)
    except Exception as exc:  # noqa: BLE001 - infrastructure failure, reported to caller
        usage = llm.get_token_usage()
        return {
            "ok": False,
            "abandoned": isinstance(exc, TaskAbandoned),
            "error": f"{type(exc).__name__}: {exc}",
            "usage": usage,
            "api_attempts": llm.get_api_attempts(),
            "est_cost_usd": _usd(usage, prices),
            "wall_seconds": round(time.time() - t0, 1),
        }
    usage = llm.get_token_usage()
    diag = _derive_diagnostics(result)
    row = {
        # identical fields to src/prediction/run_predict.py
        "id": sample["id"],
        "intent_category": sample["intent_category"],
        "user_query": sample["user_query"],
        "predicted_product_id": result["predicted_product_id"],
        "reasoning": result["reasoning"],
        "trajectory": result["trajectory"],
        "reasoning_trace": result["reasoning_trace"],
        "model": llm.model,
        "total_tool_calls": result["total_tool_calls"],
        "ask_user_calls": result["ask_user_calls"],
        "get_profile_calls": result["get_profile_calls"],
        "finished": result["finished"],
        # extra run metadata (ignored by the official evaluator)
        "baseline_meta": {
            "agent": agent_name,
            "mode": mode,
            "max_steps": max_steps,
            **diag,
            "api_attempts": llm.get_api_attempts(),
            "usage": usage,
            "est_cost_usd": round(_usd(usage, prices), 5),
            "wall_seconds": round(time.time() - t0, 1),
        },
    }
    return {"ok": True, "row": row}


# ----------------------------------------------------------------------------- main loop

def run(args: argparse.Namespace) -> int:
    load_dotenv()
    with open(args.config, encoding="utf-8") as f:
        config = yaml.safe_load(f)

    pred_cfg = config["prediction"]
    mode, _, llm_config = resolve_prediction_mode_config(config, args.mode)
    max_steps = int(pred_cfg.get("max_steps", 100))
    threads = int(args.threads or pred_cfg.get("num_threads", 4))
    prices = pred_cfg.get("cost_usd_per_million_tokens", {}) or {}
    agent_cls = AGENTS[args.agent]

    provider = normalize_provider(mode, llm_config)
    if not resolve_api_key(provider, llm_config):
        env = {"openrouter": "OPENROUTER_API_KEY", "gemini": "GEMINI_API_KEY",
               "openai": "OPENAI_API_KEY", "claude": "ANTHROPIC_API_KEY"}.get(provider, "the API key")
        raise SystemExit(
            f"No API key for provider '{provider}'. Put {env}=... in .env "
            f"(project root) or run `export {env}=...` first."
        )
    model_name = resolve_model(provider, llm_config)

    benchmark = _load_benchmark(os.path.join(config["data"]["benchmark_dir"], "benchmark.jsonl"))
    if args.manifest == "all":
        ids = sorted(benchmark)
    else:
        with open(args.manifest, encoding="utf-8") as f:
            ids = [str(x) for x in json.load(f)["sample_ids"]]
    unknown = [i for i in ids if i not in benchmark]
    if unknown:
        raise SystemExit(f"Manifest has ids not in benchmark.jsonl (or not status ok): {unknown[:5]}")
    if len(set(ids)) != len(ids):
        raise SystemExit("Manifest contains duplicate ids.")

    out = Path(args.output)
    failures = out.with_name(out.name + ".failures.jsonl")
    lock = out.with_name(out.name + ".run.json")

    if args.restart:
        stamp = time.strftime("%Y%m%d-%H%M%S")
        for p in (out, failures, lock):
            if p.exists():
                p.rename(p.with_name(p.name + f".bak-{stamp}"))
                logger.warning("Restart: moved %s -> %s.bak-%s", p.name, p.name, stamp)

    fingerprint = _setup_fingerprint(args.config, mode, args.agent, llm_config, max_steps, ids)
    if lock.exists():
        old = json.loads(lock.read_text(encoding="utf-8"))
        old_fp = old.get("fingerprint", {})
        changed = [k for k in fingerprint if old_fp.get(k) != fingerprint[k]]
        if changed and not args.allow_changed_setup:
            detail = changed
            if "code_sha256" in changed:
                a, b = old_fp.get("code_sha256", {}), fingerprint["code_sha256"]
                detail = [c for c in changed if c != "code_sha256"] + [
                    f"code:{k}" for k in sorted(set(a) | set(b)) if a.get(k) != b.get(k)
                ]
            raise SystemExit(
                "The setup changed since this run started, so resuming would mix two setups "
                f"in one result file. Changed: {detail}.\n"
                "Either undo the change, start a fresh file with --restart, or (only if the "
                "change cannot affect behaviour) pass --allow-changed-setup."
            )
    else:
        lock.parent.mkdir(parents=True, exist_ok=True)
        lock.write_text(json.dumps({
            "created": time.strftime("%Y-%m-%d %H:%M:%S"),
            "fingerprint": fingerprint,
        }, indent=2, ensure_ascii=False), encoding="utf-8")

    done = _load_checkpoint(out)
    outside = [i for i in done if i not in set(ids)]
    if outside:
        raise SystemExit(f"{out} has rows for ids outside this manifest: {outside[:5]}")

    target_ids = ids[: args.limit] if args.limit else ids
    todo = [i for i in target_ids if i not in done]

    spent_prev = sum(float(r.get("baseline_meta", {}).get("est_cost_usd", 0.0)) for r in done.values())
    spent_session = 0.0
    budget = args.budget_usd

    print(
        f"Paper agent baseline | model={model_name} mode={mode} agent={args.agent} "
        f"max_steps={max_steps} threads={threads}\n"
        f"manifest={args.manifest} n={len(ids)} done={len(done)} "
        f"this_run={len(todo)}{' (limit ' + str(args.limit) + ')' if args.limit else ''} "
        f"est_spent_so_far=${spent_prev:.2f}"
        + (f" budget=${budget:.2f}" if budget is not None else "")
        + f"\noutput={out}",
        flush=True,
    )
    if not todo:
        print("Nothing to run.", flush=True)
        _print_eval_hint(out, len(done), len(ids))
        return 0

    db = ProductDB(config["data"]["db_path"])

    soft_stop = threading.Event()
    hard_stop = threading.Event()
    stop_reason = None

    def _on_sigint(signum, frame):  # noqa: ARG001
        if not soft_stop.is_set():
            soft_stop.set()
            print("\n[stop] Ctrl+C: no new tasks will start; running tasks will finish and be saved. "
                  "Press Ctrl+C again to abandon them after their current API call.", flush=True)
        elif not hard_stop.is_set():
            hard_stop.set()
            print("\n[stop] Second Ctrl+C: abandoning running tasks after their current API call. "
                  "They are NOT saved and will rerun on resume. (Third Ctrl+C exits immediately.)",
                  flush=True)
        else:
            print("\n[stop] Exiting now. Saved tasks are safe on disk.", flush=True)
            os._exit(130)

    old_handler = signal.signal(signal.SIGINT, _on_sigint)

    queue = list(todo)
    running = {}
    n_total = len(ids)
    n_done = len(done)
    t_start = time.time()
    try:
        with ThreadPoolExecutor(max_workers=threads) as pool:
            while queue or running:
                while queue and len(running) < threads and not soft_stop.is_set():
                    if budget is not None and spent_prev + spent_session >= budget:
                        soft_stop.set()
                        stop_reason = (f"budget reached: est ${spent_prev + spent_session:.2f} "
                                       f">= ${budget:.2f}")
                        print(f"[stop] {stop_reason}. Running tasks will finish. "
                              "To continue, rerun with a higher budget (BUDGET_USD=... or --budget-usd).",
                              flush=True)
                        break
                    sid = queue.pop(0)
                    fut = pool.submit(
                        _run_one, benchmark[sid], db=db, agent_cls=agent_cls, max_steps=max_steps,
                        mode=mode, llm_config=llm_config, prices=prices, hard_stop=hard_stop,
                        agent_name=args.agent,
                    )
                    running[fut] = sid
                if not running:
                    break
                finished, _ = wait(list(running), timeout=1.0, return_when=FIRST_COMPLETED)
                for fut in finished:
                    sid = running.pop(fut)
                    res = fut.result()
                    if res["ok"]:
                        row = res["row"]
                        _append_jsonl(out, row)
                        n_done += 1
                        meta = row["baseline_meta"]
                        spent_session += meta["est_cost_usd"]
                        u = meta["usage"]
                        print(
                            f"[{n_done}/{n_total}] {sid} ({row['intent_category']}) "
                            f"-> {meta['stop_reason']} | steps={meta['steps_used']} "
                            f"tools={row['total_tool_calls']} ask_user={row['ask_user_calls']} "
                            f"profile={row['get_profile_calls']} multi_tool_turns={meta['multi_tool_turns']} | "
                            f"api={meta['api_attempts']} in={u['input_tokens']:,} out={u['output_tokens']:,} "
                            f"~${meta['est_cost_usd']:.3f} | run ~${spent_prev + spent_session:.2f} | "
                            f"{meta['wall_seconds']:.0f}s",
                            flush=True,
                        )
                    else:
                        spent_session += res["est_cost_usd"]
                        _append_jsonl(failures, {
                            "id": sid,
                            "time": time.strftime("%Y-%m-%d %H:%M:%S"),
                            "abandoned_by_user": res["abandoned"],
                            "error": res["error"],
                            "usage": res["usage"],
                            "api_attempts": res["api_attempts"],
                            "est_cost_usd": round(res["est_cost_usd"], 5),
                            "wall_seconds": res["wall_seconds"],
                        })
                        if res["abandoned"]:
                            print(f"[abandoned] {sid} (not saved; reruns on resume)", flush=True)
                        else:
                            soft_stop.set()
                            stop_reason = f"API/infrastructure failure on {sid}"
                            print(
                                f"[FAILURE] {sid}: {res['error'][:500]}\n"
                                f"  Not saved as a result; logged to {failures.name}. No new tasks will start. "
                                "Rerun the same command to retry it.",
                                flush=True,
                            )
    finally:
        signal.signal(signal.SIGINT, old_handler)

    mins = (time.time() - t_start) / 60
    print(
        f"\nSession finished in {mins:.1f} min. Saved {n_done}/{n_total}. "
        f"Est. spend this session ~${spent_session:.2f}, total ~${spent_prev + spent_session:.2f} "
        "(upper bound; check OpenRouter activity for the real number).",
        flush=True,
    )
    if stop_reason:
        print(f"Stopped early: {stop_reason}", flush=True)
    _print_eval_hint(out, n_done, n_total)
    return 0


def _print_eval_hint(out: Path, n_done: int, n_total: int) -> None:
    if n_done >= n_total:
        print(
            "All tasks saved. Evaluate with the SAME judge config as PREFLOW:\n"
            f"  CONFIG=configs/preflow_v9.yaml bash scripts/evaluate.sh --predictions {out}",
            flush=True,
        )
    else:
        print(f"{n_total - n_done} task(s) left. Rerun the same command to resume.", flush=True)


def main() -> None:
    logging.basicConfig(
        level=os.getenv("LOG_LEVEL", "WARNING"),
        format="%(asctime)s %(levelname)s %(name)s %(message)s",
    )
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--config", default="configs/baseline_paper_agent_gemini.yaml")
    p.add_argument("--mode", default=None, help="prediction mode in the config (default: prediction.mode)")
    p.add_argument("--manifest", required=True,
                   help="JSON file with sample_ids, or 'all' for every status-ok task (662)")
    p.add_argument("--output", required=True)
    p.add_argument("--agent", choices=sorted(AGENTS), default="gemini_safe",
                   help="gemini_safe (default) or the untouched original agent")
    p.add_argument("--threads", type=int, default=None)
    p.add_argument("--limit", type=int, default=None,
                   help="only the first N manifest tasks (smoke test); rerun without it to continue")
    p.add_argument("--budget-usd", type=float, default=None,
                   help="stop starting new tasks once the estimated total spend reaches this")
    p.add_argument("--restart", action="store_true",
                   help="move existing output/failures/lock to .bak-<time> and start fresh")
    p.add_argument("--allow-changed-setup", action="store_true")
    raise SystemExit(run(p.parse_args()))


if __name__ == "__main__":
    main()
