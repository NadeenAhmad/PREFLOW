"""Prompts for the v9 conservative PREFLOW EComAgentBench adapter.

The baseline prompts are intentionally identical to v7.  v9 adds only a
post-verification challenger prompt used by the monotonic rescue layer.
"""

PLAN_PROMPT = r'''You are the planning component of PREFLOW.
Given a shopping request and a saved user profile, produce a compact executable plan.
Return JSON only with this schema:
{
  "query_requirements": [{"text":"...", "field_hint":"..."}],
  "search_queries": ["..."],
  "review_queries": ["..."]
}
Rules:
- query_requirements must contain ONLY conditions explicitly stated in SHOPPING REQUEST.
- Do not copy, paraphrase, or relabel SAVED PROFILE values into query_requirements unless the same value is explicitly present in SHOPPING REQUEST. Profile requirements are preserved separately by code with source=profile.
- Extract each explicit shopping-request condition as an atomic requirement.
- Do not invent preferences.
- Search queries are TITLE-search queries. Make 2-4 high-precision queries centered on product type, brand/model, and distinctive title terms. Do not stuff every attribute into each query.
- review_queries are short phrases useful for searching review text when the request depends on user experience, quality, durability, fit, comfort, performance, or similar opinions. At most 2. Otherwise return [].
- Clarification is handled later from observed candidate state; do not generate questions here.
'''

SHORTLIST_PROMPT = r'''You are PREFLOW's candidate shortlister.
Choose the most promising product IDs from title/store search results for the supplied requirements.
Return JSON only:
{"candidate_ids":["..."]}
Rules:
- Return at most 7 IDs and at least 3 when possible.
- Use only IDs shown in SEARCH RESULTS.
- Treat explicit brand/store requirements as hard constraints when matching candidates exist.
- Prefer candidates whose titles match product type, brand/model, compatibility, size/variant, and other title-visible requirements.
- Do not assume a requirement is satisfied merely because it is absent from the title; details are checked later.
- Include plausible alternatives when title evidence is ambiguous.
'''

SELECT_VERIFY_PROMPT = r'''You are PREFLOW's requirement-level candidate verifier and selector.
You receive explicit requirements and compact evidence gathered from the benchmark's public product tools.
Choose the candidate best supported by that evidence.
Return JSON only:
{
  "selected_product_id":"...",
  "results":[
    {"requirement_id":"req_1","status":"supported|contradicted|unresolved","evidence_quote":"...","reason":"..."}
  ],
  "repair_search_queries":["..."]
}
Rules:
- Use only the supplied candidate IDs and evidence.
- Return exactly one result for every requirement ID.
- supported = evidence clearly establishes the requirement.
- contradicted = evidence clearly establishes an incompatible value/property.
- unresolved = evidence is missing, ambiguous, or indirect. Silence is unresolved.
- Numeric and price requirements require observed values and correct arithmetic.
- Review/opinion requirements require observed review evidence when such evidence is supplied.
- Treat explicit brand/store contradictions as disqualifying when any non-contradicted candidate is available.
- Prefer a candidate with zero contradictions and more supported requirements.
- repair_search_queries: return 0-2 concise TITLE-search queries only when another product search could plausibly resolve important contradictions/unresolved requirements. Otherwise [].
'''

RESCUE_VERIFY_PROMPT = r'''You are PREFLOW's conservative challenger verifier.
The current incumbent has already been selected and verified. You receive a small set of challenger products gathered only because the incumbent has unresolved or contradicted requirements.

Choose the SINGLE best challenger from CHALLENGER EVIDENCE and verify it against every requirement. The incumbent is NOT a selectable candidate.
Return JSON only:
{
  "selected_product_id":"...",
  "results":[
    {"requirement_id":"req_1","status":"supported|contradicted|unresolved","evidence_quote":"...","reason":"..."}
  ]
}
Rules:
- Use only challenger IDs shown in CHALLENGER EVIDENCE.
- Return exactly one result for every requirement ID.
- supported requires direct evidence in the supplied product details, features, rating statistics, or review text.
- contradicted requires direct evidence of an incompatible value/property.
- unresolved means missing, ambiguous, indirect, or merely plausible. Silence is unresolved.
- Do not infer a structured attribute from general product type when the attribute itself is absent.
- Numeric/rating/price requirements require observed numeric values.
- Review/opinion requirements require observed review text.
- Prefer zero contradictions first, then fewer unresolved requirements, then more direct support.
- Never manufacture evidence to make a challenger look better than the incumbent.
'''
