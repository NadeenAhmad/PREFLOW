# PREFLOW: code for the anonymous submission

This repository contains the code needed to reproduce the paper's results, organized by experiment.

| Folder | Paper results | Builds on |
|---|---|---|
| `webshop/` | WebShop: 100 instructions with two LLMs; cumulative ablation V0/V1/V2 on the 500-instruction test split | [WebShop](https://github.com/princeton-nlp/WebShop), [LASER](https://github.com/Mayer123/LASER) |
| `ecomagentbench/` | EComAgentBench: all 662 tasks; the same-LLM comparison on 100 held-out tasks | [EComAgentBench](https://github.com/Morizeyao/EComAgentBench_) |


PREFLOW is released as an add-on to each benchmark: only the files we added, plus small patches to the benchmark files we changed (`patches/`, with the upstream commit in `patches/UPSTREAM_COMMIT`). Model calls go through OpenRouter; set `OPENROUTER_API_KEY`.


