"""Explicit requirement and candidate-evidence state for the PREFLOW adapter.

This module is intentionally benchmark-agnostic.  It never reads benchmark rubrics,
target products, or clarification scripts.  It only consumes information that the
agent receives through the public query/profile/dialogue/tool interface.
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from typing import Any


_VALID_STATUSES = {"supported", "contradicted", "unresolved"}


@dataclass
class Requirement:
    id: str
    text: str
    source: str
    field_hint: str = ""

    def as_dict(self) -> dict[str, Any]:
        return {
            "id": self.id,
            "text": self.text,
            "source": self.source,
            "field_hint": self.field_hint,
        }


@dataclass
class RequirementPlan:
    requirements: list[Requirement] = field(default_factory=list)

    def add(self, text: str, source: str, field_hint: str = "") -> Requirement | None:
        text = " ".join(str(text or "").split()).strip()
        if not text:
            return None
        normalized = text.casefold()
        for existing in self.requirements:
            if existing.text.casefold() == normalized:
                return existing
        req = Requirement(
            id=f"req_{len(self.requirements) + 1}",
            text=text,
            source=source,
            field_hint=" ".join(str(field_hint or "").split()).strip(),
        )
        self.requirements.append(req)
        return req

    def extend_from_items(self, items: list[dict[str, Any]], source: str) -> None:
        for item in items or []:
            if not isinstance(item, dict):
                continue
            self.add(
                item.get("text", ""),
                source=source,
                field_hint=item.get("field_hint", ""),
            )

    def render(self) -> str:
        if not self.requirements:
            return "(no requirements recorded yet)"
        return "\n".join(
            f"- [{r.id}] {r.text} (source={r.source}"
            + (f", hint={r.field_hint}" if r.field_hint else "")
            + ")"
            for r in self.requirements
        )

    def as_list(self) -> list[dict[str, Any]]:
        return [r.as_dict() for r in self.requirements]


@dataclass
class EvidenceRecord:
    source: str
    content: str
    tool: str

    def as_dict(self) -> dict[str, str]:
        return {"source": self.source, "content": self.content, "tool": self.tool}


@dataclass
class VerificationResult:
    candidate_id: str
    statuses: dict[str, str]
    reasons: dict[str, str]
    evidence_quotes: dict[str, str]

    @property
    def all_supported(self) -> bool:
        return bool(self.statuses) and all(v == "supported" for v in self.statuses.values())

    @property
    def unresolved_ids(self) -> list[str]:
        return [k for k, v in self.statuses.items() if v == "unresolved"]

    @property
    def contradicted_ids(self) -> list[str]:
        return [k for k, v in self.statuses.items() if v == "contradicted"]

    def as_dict(self) -> dict[str, Any]:
        return {
            "candidate_id": self.candidate_id,
            "all_supported": self.all_supported,
            "statuses": self.statuses,
            "reasons": self.reasons,
            "evidence_quotes": self.evidence_quotes,
        }


class EvidenceLedger:
    """Candidate-specific evidence collected only from tool outputs."""

    def __init__(self) -> None:
        self._records: dict[str, list[EvidenceRecord]] = {}
        self._last_verification: dict[str, VerificationResult] = {}

    def _add(self, product_id: str, source: str, content: str, tool: str) -> None:
        product_id = str(product_id or "").strip()
        content = str(content or "").strip()
        if not product_id or not content:
            return
        rec = EvidenceRecord(source=source, content=content, tool=tool)
        bucket = self._records.setdefault(product_id, [])
        # Keep exact duplicate tool outputs from bloating the verifier context.
        if not any(r.source == rec.source and r.content == rec.content for r in bucket):
            bucket.append(rec)

    def record_tool_result(self, tool_name: str, args: dict[str, Any], result: Any) -> None:
        if not isinstance(result, dict):
            return

        if tool_name == "search_products":
            for p in result.get("products", []) or []:
                self._add(
                    p.get("product_id", ""),
                    source=f"search page {result.get('page', 0)}",
                    content=f"title: {p.get('title', '')}",
                    tool=tool_name,
                )
            return

        if tool_name == "get_store_products":
            for p in result.get("products", []) or []:
                self._add(
                    p.get("product_id", ""),
                    source=f"store listing: {result.get('store', '')}",
                    content=f"title: {p.get('title', '')}",
                    tool=tool_name,
                )
            return

        if tool_name == "get_product_details":
            p = result.get("product") or {}
            pid = p.get("product_id", args.get("product_id", ""))
            if pid:
                self._add(
                    pid,
                    source="product details",
                    content=json.dumps(p, ensure_ascii=False, sort_keys=True),
                    tool=tool_name,
                )
            return

        if tool_name == "get_product_review_stats":
            for p in result.get("products", []) or []:
                pid = p.get("product_id", "")
                self._add(
                    pid,
                    source="rating statistics",
                    content=json.dumps(p, ensure_ascii=False, sort_keys=True),
                    tool=tool_name,
                )
            return

        if tool_name == "get_review_content":
            pid = args.get("product_id", "")
            query = args.get("query", "")
            reviews = result.get("reviews", []) or []
            if pid and reviews:
                compact = [
                    {
                        "rating": r.get("rating"),
                        "title": r.get("title", ""),
                        "text": r.get("text", ""),
                    }
                    for r in reviews[:5]
                ]
                self._add(
                    pid,
                    source=f"reviews matching: {query}",
                    content=json.dumps(compact, ensure_ascii=False),
                    tool=tool_name,
                )
            return

        if tool_name == "filter_by_attribute":
            attr = args.get("attribute_name", "")
            value = args.get("attribute_value", "")
            for pid in result.get("product_ids", []) or []:
                self._add(
                    pid,
                    source="catalog attribute filter",
                    content=f"{attr} contains {value}",
                    tool=tool_name,
                )

    def evidence_for(self, product_id: str, max_chars: int = 16000) -> str:
        records = self._records.get(product_id, [])
        if not records:
            return "(no candidate-specific evidence has been observed)"
        rendered = []
        used = 0
        for i, rec in enumerate(records, 1):
            block = f"[{i}] source={rec.source}; tool={rec.tool}\n{rec.content}\n"
            if rendered and used + len(block) > max_chars:
                break
            if not rendered and len(block) > max_chars:
                block = block[:max_chars]
            rendered.append(block)
            used += len(block)
        return "\n".join(rendered)

    def candidate_ids(self) -> list[str]:
        return list(self._records)

    def set_verification(self, result: VerificationResult) -> None:
        self._last_verification[result.candidate_id] = result

    def last_verification(self, product_id: str) -> VerificationResult | None:
        return self._last_verification.get(product_id)

    def best_observed_candidate(self) -> str | None:
        """Best-effort fallback using only observed evidence/verification state.

        This is used only when the action policy reaches its bounded pilot budget
        without producing a terminal recommendation. It never reads benchmark
        targets or rubrics.
        """
        if not self._records:
            return None

        def key(pid: str):
            verification = self._last_verification.get(pid)
            if verification is None:
                return (0, 0, 0, len(self._records.get(pid, [])))
            supported = sum(v == "supported" for v in verification.statuses.values())
            contradicted = sum(v == "contradicted" for v in verification.statuses.values())
            unresolved = sum(v == "unresolved" for v in verification.statuses.values())
            return (-contradicted, supported, -unresolved, len(self._records.get(pid, [])))

        return max(self._records, key=key)

    def snapshot(self) -> dict[str, Any]:
        return {
            pid: {
                "evidence": [r.as_dict() for r in recs],
                "verification": (
                    self._last_verification[pid].as_dict()
                    if pid in self._last_verification
                    else None
                ),
            }
            for pid, recs in self._records.items()
        }


def normalize_verification_payload(
    payload: dict[str, Any],
    plan: RequirementPlan,
    candidate_id: str,
) -> VerificationResult:
    raw = payload.get("results", []) if isinstance(payload, dict) else []
    by_id = {str(x.get("requirement_id", "")): x for x in raw if isinstance(x, dict)}
    statuses: dict[str, str] = {}
    reasons: dict[str, str] = {}
    quotes: dict[str, str] = {}
    for req in plan.requirements:
        item = by_id.get(req.id, {})
        status = str(item.get("status", "unresolved")).strip().lower()
        if status not in _VALID_STATUSES:
            status = "unresolved"
        statuses[req.id] = status
        reasons[req.id] = str(item.get("reason", "")).strip()
        quotes[req.id] = str(item.get("evidence_quote", "")).strip()
    return VerificationResult(
        candidate_id=candidate_id,
        statuses=statuses,
        reasons=reasons,
        evidence_quotes=quotes,
    )
