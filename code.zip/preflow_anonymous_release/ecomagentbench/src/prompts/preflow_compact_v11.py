"""Compact, public-evidence-only prompts for the v11 search policy."""

PLAN_PROMPT = r'''Extract a shopping plan from the visible REQUEST and PROFILE.
Return JSON only:
{"product_entity":"short product type", "query_requirements":[{"text":"atomic condition","field_hint":"canonical field"}], "search_queries":["short title keywords"], "review_queries":[]}
- Preserve EVERY explicit request condition separately, including exclusions, quantity, compatibility, budget and discount conditions. Do not invent preferences.
- query_requirements contains request conditions only. Code appends profile requirements separately.
- product_entity is 1-3 catalog words naming the thing being bought.
- Give 4 diverse title queries, each 2-4 words: product type plus ONE distinguishing brand/model/property. All words are matched conjunctively; descriptive sentences and many attributes together fail.
- Use profile constraints in searches when relevant. Brand and store are different concepts.
- review_queries: at most 2 short (1-2 word) opinion terms, only when an explicit requirement needs customer review evidence. Numeric ratings use statistics, not review text.
'''

SHORTLIST_PROMPT = r'''Choose candidates for detailed inspection from the supplied public title results.
Return JSON only: {"candidate_ids":["..."],"refine_queries":["..."]}
- Select at most 7 IDs from the supplied results, preserving plausible alternatives.
- Match product identity and hard requirements first. Do not infer missing attributes from silence.
- A required brand is not necessarily the seller/store name. Exclusions must not become required brands.
- Refine_queries: at most 3 NEW title queries, 2-4 words each, based on how observed titles name the required product and properties. Preserve product identity. Do not repeat tried queries.
'''

VERIFY_PROMPT = r'''Select one product using only REQUIREMENTS and public CANDIDATE EVIDENCE.
Return JSON only:
{"selected_product_id":"...","results":[{"requirement_id":"req_1","status":"supported|contradicted|unresolved","evidence_quote":"exact short quote or observed number","reason":"brief"}],"repair_search_queries":["..."]}
- Every query, profile and clarification requirement is binding. Return one result per requirement for the selected candidate.
- Prefer a product satisfying the conjunction of all requirements. Minimize explicit contradictions first, then maximize supported requirements.
- supported requires direct candidate-specific evidence; missing or ambiguous evidence is unresolved. Never treat absent evidence as support.
- Deterministic numeric_contradictions are binding. Check discounts and price arithmetic using only stated rules and observed values.
- Review/opinion conditions require actual review evidence; product marketing or average rating alone cannot establish review sentiment.
- Choose only a supplied ID. repair_search_queries: at most 3 NEW short title queries targeting unresolved requirements, preserving product type; otherwise [].
'''

FINAL_PROMPT = VERIFY_PROMPT + r'''
The previous incumbent remains in CANDIDATE EVIDENCE alongside newly inspected challengers.
Reconsider its evidence and all requirements together. An earlier supported label is not itself evidence.
If candidates are equally supported, retain the incumbent. Do not replace it merely for novelty or a higher average rating.
'''
