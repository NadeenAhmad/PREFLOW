#!/usr/bin/env python3
"""Outcome x internal-evidence 2x2 for PREFLOW on all 662 EComAgentBench tasks.

Same definitions as the dev50 figure (analyze_ecom_dev50.py):
  officially correct = exact target product OR every rubric satisfied (benchmark judge)
  fully verified     = PREFLOW's final verification of the recommended product marks
                       every internal requirement 'supported'
Source: frozen v11 full run (results/budget22). No API calls.
"""
import argparse
import json
from pathlib import Path

import matplotlib.pyplot as plt
from matplotlib.colors import LinearSegmentedColormap
from matplotlib.patches import Rectangle

ROOT = Path(__file__).resolve().parent


def rows(path):
    with open(path, encoding="utf-8") as f:
        return {r["id"]: r for r in map(json.loads, filter(str.strip, f))}


def fully_verified(pred):
    pid = pred["predicted_product_id"]
    events = [e for e in (pred.get("preflow_verification_events") or []) if e.get("candidate_id") == pid]
    if not events:
        return False  # no verification of the recommended product -> not fully verified
    statuses = list((events[-1].get("statuses") or {}).values())
    unknown = set(statuses) - {"supported", "contradicted", "unresolved"}
    if unknown:
        raise RuntimeError(f"{pred['id']}: unexpected states {unknown}")
    return bool(statuses) and all(s == "supported" for s in statuses)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--predictions", default=str(ROOT / "results/budget22/predictions.jsonl"))
    ap.add_argument("--judgments", default=str(ROOT / "results/budget22/judgments.jsonl"))
    ap.add_argument("--benchmark", default=str(ROOT / "data/benchmark/benchmark.jsonl"))
    ap.add_argument("--output", default=str(ROOT / "ecom_full662_outcome_evidence"))
    args = ap.parse_args()

    bench = {k: v for k, v in rows(args.benchmark).items() if v.get("sample_status", "ok") == "ok"}
    preds, judg = rows(args.predictions), rows(args.judgments)
    if len(bench) != 662 or set(preds) != set(bench):
        raise RuntimeError(f"Expected 662 predictions matching the benchmark, found {len(preds)}")

    cells = {(c, v): 0 for c in (True, False) for v in (True, False)}
    for sid, pred in preds.items():
        exact = pred["predicted_product_id"] == bench[sid]["target_product"]["product_id"]
        if not exact and sid not in judg:
            raise RuntimeError(f"{sid}: non-exact recommendation without a judgment")
        correct = exact or bool(judg[sid]["all_satisfied"])
        cells[(correct, fully_verified(pred))] += 1
    n = sum(cells.values())

    grid = [[cells[(True, True)], cells[(True, False)]], [cells[(False, True)], cells[(False, False)]]]
    # Single-hue sequential scale (light -> mid blue), kept light enough for dark text.
    cmap = LinearSegmentedColormap.from_list("seq", ["#E6EEF7", "#9CC6E0"])
    vmax = max(max(r) for r in grid)
    ink = "#17324D"

    fig, ax = plt.subplots(figsize=(5.9, 5.0))
    gap = 0.02
    for i, row in enumerate(grid):
        for j, count in enumerate(row):
            ax.add_patch(Rectangle((j + gap, 1 - i + gap), 1 - 2 * gap, 1 - 2 * gap,
                                   facecolor=cmap(count / vmax), edgecolor="none"))
            ax.text(j + 0.5, 1 - i + 0.6, f"{count}", ha="center", va="center",
                    fontsize=30, fontweight="bold", color=ink)
            ax.text(j + 0.5, 1 - i + 0.33, f"{100 * count / n:.1f}%", ha="center", va="center",
                    fontsize=19, color=ink)
    ax.set_xlim(0, 2)
    ax.set_ylim(0, 2)
    ax.set_aspect("equal")
    ax.set_xticks([0.5, 1.5], ["Fully\nverified", "Not fully\nverified"], fontsize=15)
    ax.set_yticks([1.5, 0.5], ["Officially\ncorrect", "Officially\nincorrect"], fontsize=15)
    ax.xaxis.tick_top()
    ax.tick_params(length=0)
    for side in ax.spines.values():
        side.set_visible(False)
    ax.set_title(f"EComAgentBench: all tasks\n(n={n})", fontsize=21, pad=18)
    ax.set_xlabel("Percentages of all evaluated tasks", fontsize=13, labelpad=12)
    fig.tight_layout()

    out = Path(args.output)
    fig.savefig(out.with_suffix(".pdf"), bbox_inches="tight")
    fig.savefig(out.with_suffix(".png"), dpi=300, bbox_inches="tight")
    summary = {"n": n, "correct_fully_verified": grid[0][0], "correct_not_fully_verified": grid[0][1],
               "incorrect_fully_verified": grid[1][0], "incorrect_not_fully_verified": grid[1][1],
               "precision_of_full_verification": grid[0][0] / max(1, grid[0][0] + grid[1][0]),
               "source": "results/budget22 (PREFLOW v11, Gemini-3-Flash, all 662 tasks)"}
    out.with_suffix(".json").write_text(json.dumps(summary, indent=2) + "\n")
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
