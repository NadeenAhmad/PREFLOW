#!/usr/bin/env python3
"""Bar version of the full-662 outcome x evidence figure, styled like the WebShop companion.

Counts come from ecom_full662_outcome_evidence.json (written by
make_ecom_outcome_evidence_full662.py from the frozen v11 run). No API calls.
"""
import json
from pathlib import Path

import matplotlib.pyplot as plt

ROOT = Path(__file__).resolve().parent

summary = json.loads((ROOT / "ecom_full662_outcome_evidence.json").read_text())
n = summary["n"]
labels = ["Correct +\nfully verified", "Correct +\nnot fully verified",
          "Incorrect +\nfully verified", "Incorrect +\nnot fully verified"]
counts = [summary["correct_fully_verified"], summary["correct_not_fully_verified"],
          summary["incorrect_fully_verified"], summary["incorrect_not_fully_verified"]]
pcts = [100 * c / n for c in counts]

# Checks before saving.
assert n == 662 and sum(counts) == 662, (n, sum(counts))
assert abs(sum(round(p, 1) for p in pcts) - 100.0) <= 0.1, sum(pcts)
assert counts == [217, 103, 41, 301], counts

fig, ax = plt.subplots(figsize=(6.69, 3.08))
bars = ax.bar(labels, pcts, color="C0")
for bar, count, pct in zip(bars, counts, pcts):
    ax.text(bar.get_x() + bar.get_width() / 2, bar.get_height(), f"{count}\n({pct:.1f}%)",
            ha="center", va="bottom")
ax.set_title("EComAgentBench: outcome and evidence at commitment (n=662)", pad=22)
ax.set_ylabel("Tasks (%)")
ax.set_ylim(0, 50)
ax.set_yticks(range(0, 51, 10))
fig.tight_layout()

out = ROOT / "figs" / "ecom_full662_outcome_evidence.pdf"
out.parent.mkdir(exist_ok=True)
fig.savefig(out, bbox_inches="tight")
fig.savefig(out.with_suffix(".png"), dpi=200, bbox_inches="tight")
print("counts", counts, "pcts", [round(p, 1) for p in pcts], "->", out)
