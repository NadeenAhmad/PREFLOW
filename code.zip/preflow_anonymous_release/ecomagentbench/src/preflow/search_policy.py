"""Cheap retrieval decisions using only observed, public agent information.

These are deterministic ranking heuristics, not a claim of optimal Pandora or
secretary stopping. This module has no database, benchmark, or model access.
"""
from __future__ import annotations

import math
import re
from typing import Any


_WORDS = re.compile(r"[A-Za-z0-9]+(?:[+./-][A-Za-z0-9]+)*")
_STOP = set("a an the i my me we our you your please find looking look want need needs "
            "would like must should be is are for of to in with and or that this it "
            "item product products specific require required requirement preference "
            "prefer preferred brand store budget price cost under over below above "
            "least most more less than about around only have has from as at".split())
_NEGATIVE = re.compile(r"\b(?:not|avoid|without|exclude|excluding|except|never)\b", re.I)
_NUM = r"(?:\d{1,3}(?:,\d{3})+|\d+)(?:\.\d+)?"
_MONEY_OR_NUMBER = rf"(?:USD\s*)?\$?\s*({_NUM})"


def _tokens(text: Any) -> list[str]:
    return list(dict.fromkeys(w.casefold() for w in _WORDS.findall(str(text or ""))
                              if w.casefold() not in _STOP))


def _title_text(text: str) -> str:
    """Remove constraints that cannot be searched in product titles."""
    text = str(text or "")
    comparison = r"(?:under|below|over|above|at\s+most|at\s+least|up\s+to|less\s+than|more\s+than)"
    # Capacity, dimensions and power are useful title terms. Keep their values
    # instead of treating every number after a comparison as a dollar budget.
    units = r"(?:gb|tb|mb|ghz|mhz|hz|mah|watts?|volts?|mm|cm|inches?|feet|ft|oz|lbs?|ml|liters?|litres?)"
    text = re.sub(rf"\b{comparison}\s*({_NUM}\s*{units})\b", r"\1", text, flags=re.I)
    text = re.sub(rf"\b(?:under|below|over|above|at\s+most|at\s+least|up\s+to|"
                  rf"less\s+than|more\s+than|budget(?:\s+of)?)\s*\$?{_NUM}"
                  rf"(?:\s*(?:dollars?|USD|stars?|ratings?|reviews?))?(?![A-Za-z0-9.])", " ", text, flags=re.I)
    text = re.sub(rf"\$\s*{_NUM}|\b{_NUM}\s*(?:dollars?|USD|stars?|ratings?|reviews?)\b",
                  " ", text, flags=re.I)
    return text


def query_variants(query: str, entity: str = "", max_variants: int = 4) -> list[str]:
    """Try a concise supplied query, then relax using the product identity.

    Preserve the caller's independently phrased query family: adding every entity
    word to a synonym query would destroy recall under conjunctive title search.
    The final variant keeps just the identity when one is supplied. It is a
    fallback for zero-hit facet conjunctions, not an instruction to issue every
    variant after a successful search.
    """
    if max_variants <= 0:
        return []
    anchors = _tokens(_title_text(entity))[:4]
    tokens = _tokens(_title_text(query))
    facets = [t for t in tokens if t not in anchors]
    base = anchors or tokens[:2]
    room = max(1, 6 - len(base))
    forms: list[list[str]] = [tokens] if 0 < len(tokens) <= 6 else []
    forms.append(base + [t for t in tokens if t not in base][:room])
    if anchors:
        forms.extend([anchors + facets[:2], anchors + facets[-2:]])
        forms.extend(anchors + [facet] for facet in facets)
    elif len(tokens) > 2:
        forms.extend([base + tokens[2:4], base + tokens[-2:]])
    forms.append(base)
    out = list(dict.fromkeys(" ".join(dict.fromkeys(form)) for form in forms if form))
    if len(out) > max_variants:
        out = out[:max_variants - 1] + [" ".join(base)] if max_variants > 1 else out[:1]
    return list(dict.fromkeys(out))


def _positive_requirements(requirements: list[dict]) -> list[tuple[set[str], float]]:
    weighted = []
    for req in requirements:
        text = str(req.get("text", ""))
        if _NEGATIVE.search(text):
            continue
        tokens = set(_tokens(_title_text(text)))
        if not tokens:
            continue
        hint = str(req.get("field_hint", "")).casefold()
        weight = 6.0 if any(w in hint for w in ("brand", "store")) else 2.0
        if any(w in hint for w in ("compatible", "model", "product type", "entity")):
            weight = 4.0
        weighted.append((tokens, weight))
    return weighted


def rank_candidates(rows: list[dict], plan_requirements: list[dict], entity: str = "",
                    limit: int = 16) -> list[str]:
    """Rank the entire observed pool; diversify ties without discarding relevance.

    Title tokens are retrieval signals only. Missing title attributes are never
    classified as contradictions. Duplicate rows preserve all query provenance.
    """
    if limit <= 0:
        return []
    pool: dict[str, dict] = {}
    for row in rows:
        pid = str(row.get("product_id", "")).strip()
        if not pid:
            continue
        if pid not in pool:
            pool[pid] = {"row": row, "sources": set(), "index": len(pool)}
        source = str(row.get("query") or row.get("source") or "unknown").casefold()
        pool[pid]["sources"].add(source)
    anchors = set(_tokens(entity))
    weighted = _positive_requirements(plan_requirements)
    for item in pool.values():
        row = item["row"]
        # A public store-listing source establishes the store even though that
        # tool returns only IDs and titles for each individual row.
        stores = " ".join(source[6:] for source in item["sources"] if source.startswith("store:"))
        title = set(_tokens(str(row.get("title", "")) + " " + str(row.get("store", "")) + " " + stores))
        score = 8.0 * len(anchors & title) / max(1, len(anchors))
        if anchors and anchors <= title:
            score += 2.0
        for tokens, weight in weighted:
            coverage = len(tokens & title) / len(tokens)
            score += weight * coverage
            if tokens <= title:
                score += weight * 0.25
        score += min(0.6, 0.15 * (len(item["sources"]) - 1))
        item["score"] = score
    selected: list[str] = []
    covered: set[str] = set()
    while pool and len(selected) < limit:
        # A small novelty bonus preserves query diversity among close candidates;
        # it cannot displace a clear product-identity or brand match.
        pid = max(pool, key=lambda key: (
            pool[key]["score"] + (0.5 if pool[key]["sources"] - covered else 0),
            -pool[key]["index"],
        ))
        item = pool.pop(pid)
        selected.append(pid)
        covered.update(item["sources"])
    return selected


def _number(value: Any) -> float | None:
    if isinstance(value, bool):
        return None
    try:
        parsed = float(str(value).replace(",", "").strip().lstrip("$"))
    except (TypeError, ValueError):
        return None
    return parsed if math.isfinite(parsed) else None


def _numeric_field(text: str, hint: str) -> str | None:
    combined = f"{hint} {text}".casefold()
    if any(term in combined for term in ("coupon", "voucher", "discount", "cashback", "promo", "percent", "%")):
        return None
    # Currency conversion and product quantities are deliberately outside this checker.
    if re.search(r"[€£¥]|\b(?:eur|gbp|egp|yen|euros?|pounds?)\b", combined):
        return None
    if re.search(r"\b(?:if|unless|depending|after|before)\b", combined):
        return None
    price = "$" in combined or bool(re.search(r"\b(?:price|budget|cost|dollars?|usd)\b", combined))
    count = any(t in combined for t in ("rating_number", "rating count", "review count", "number of ratings", "number of reviews"))
    count = count or bool(re.search(rf"{_NUM}\s*(?:customer\s+)?(?:ratings|reviews)\b", combined))
    rating = any(t in combined for t in ("average_rating", "average rating", "stars", "star rating"))
    if sum((price, count, rating)) != 1:
        return None
    return "price" if price else "rating_number" if count else "average_rating"


def numeric_contradictions(requirements: list[dict], snapshot: dict) -> dict[str, str]:
    """Flag only clear numeric violations; unknown and conditional values abstain.

    Prices are catalog prices, so coupon/voucher/discount requirements are left to
    the verifier. Count checks use rating_number, never number of fetched reviews.
    """
    violations: dict[str, str] = {}
    for req in requirements:
        text = str(req.get("text", ""))
        hint = str(req.get("field_hint", ""))
        rid = str(req.get("id", req.get("requirement_id", "")))
        field = _numeric_field(text, hint)
        # Parse direct comparator negations, but abstain on wider linguistic
        # negation such as "I don't want a price over $50". Treating "over" as
        # a lower bound there would reverse the shopper's requirement.
        negation_check = re.sub(r"\b(?:no|not)\s+(?:more|less|greater|fewer)\s+than\b|\bnot exceeding\b",
                                "", text, flags=re.I)
        ambiguous_negation = re.search(r"\b(?:no|not|never|avoid|except|without|exclude|excluding|cannot)\b|n't\b",
                                       negation_check, re.I)
        if not rid or field is None or ambiguous_negation:
            continue
        raw = snapshot.get("price") if field == "price" else (snapshot.get("rating") or {}).get(field)
        value = _number(raw)
        if value is None:
            continue
        constraints: list[tuple[str, float]] = []
        range_match = re.search(rf"\bbetween\s*{_MONEY_OR_NUMBER}\s*(?:and|to)\s*{_MONEY_OR_NUMBER}", text, re.I)
        if range_match:
            constraints.extend([(">=", float(range_match[1].replace(",", ""))),
                                ("<=", float(range_match[2].replace(",", "")))])
        patterns = [
            ("<=", r"(?:at most|(?:no|not) more than|(?:no|not) greater than|up to|maximum(?: of)?|not exceeding|less than or equal to)"),
            (">=", r"(?:at least|(?:no|not) less than|(?:no|not) fewer than|minimum(?: of)?|greater than or equal to)"),
            ("<", r"(?:under|below|less than)"),
            (">", r"(?:over|above|more than|greater than)"),
        ]
        labels = {
            "price": r"(?:(?:price|cost|budget)(?:\s+(?:of|is))?\s*:?\s*)?",
            "average_rating": r"(?:(?:average\s+)?rating(?:\s+(?:of|is))?\s*:?\s*)?",
            "rating_number": r"(?:(?:number\s+of\s+(?:ratings|reviews)|(?:rating|review)\s+count)(?:\s+(?:of|is))?\s*:?\s*)?",
        }
        occupied: list[tuple[int, int]] = []
        for op, prefix in patterns:
            for match in re.finditer(rf"\b{prefix}\s*{labels[field]}{_MONEY_OR_NUMBER}", text, re.I):
                if any(match.start() < end and start < match.end() for start, end in occupied):
                    continue
                occupied.append(match.span())
                constraints.append((op, float(match[1].replace(",", ""))))
        for match in re.finditer(rf"(<=|>=|<|>)\s*{_MONEY_OR_NUMBER}", text, re.I):
            constraints.append((match[1], float(match[2].replace(",", ""))))
        if not constraints and field == "price":
            match = re.search(rf"\bbudget(?:\s+(?:of|is))?\s*:?\s*{_MONEY_OR_NUMBER}", text, re.I)
            if match:
                constraints.append(("<=", float(match[1].replace(",", ""))))
        if not constraints:
            suffix = re.search(rf"{_MONEY_OR_NUMBER}\s*(?:dollars?|usd|stars?|ratings?|reviews?)?\s*(maximum|max|or less|or lower|minimum|min|or more|or higher)\b", text, re.I)
            if suffix:
                op = "<=" if suffix[2].casefold() in {"maximum", "max", "or less", "or lower"} else ">="
                constraints.append((op, float(suffix[1].replace(",", ""))))
        for op, bound in constraints:
            satisfied = {"<=": value <= bound, ">=": value >= bound, "<": value < bound, ">": value > bound}[op]
            if not satisfied:
                violations[rid] = f"Observed {field}={value:g} violates {op} {bound:g}."
                break
    return violations


def clarification_query(answer: str, entity: str) -> str | None:
    """A short optional repair query for a substantive, title-visible answer."""
    if not entity or re.search(r"\b(?:not sure|no preference|anything|don't know|do not know)\b", answer, re.I):
        return None
    facets = [word for word in _tokens(_title_text(answer)) if word not in _tokens(entity)]
    if not facets or re.search(r"\b(?:budget|rating|ratings|reviews|price|cost)\b|\$", answer, re.I):
        return None
    variants = query_variants(entity + " " + " ".join(facets), entity=entity, max_variants=1)
    return variants[0] if variants else None


__all__ = ["query_variants", "rank_candidates", "numeric_contradictions", "clarification_query"]
