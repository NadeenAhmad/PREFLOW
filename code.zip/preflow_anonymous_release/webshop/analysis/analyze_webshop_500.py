#!/usr/bin/env python3
"""Analyze PREFLOW's WebShop logs and generate two component-satisfaction figures.

Python 3.10+. Figure generation requires matplotlib:
    python -m pip install matplotlib

Use the directory containing v0_500.log, v1_500.log, and v2_500.log:
    python analyze_webshop_500.py --logs-dir /path/to/logs --output-dir webshop_500

Check the logs without importing matplotlib or writing any files:
    python analyze_webshop_500.py --logs-dir /path/to/logs --validate-only

Write CSV/JSON analysis and captions, without generating figures:
    python analyze_webshop_500.py --logs-dir /path/to/logs --analysis-only

Analyze a different full-PREFLOW run, without the ablation:
    python analyze_webshop_500.py --preflow-log /path/to/run.log --preflow-only

Inputs
------
These are the detailed logs produced by the supplied PreflowScriptForWebshop.py,
with [Episode], episode ..., [Gold Target], and [Reward Breakdown] records.
Final aggregate summaries alone cannot supply the component breakdown.
By default, V2 is also the full PREFLOW run; it is parsed only once. The script
does not pool separate runs, substitute a 100-task sample, or filter to 470 tasks.

Outputs
-------
webshop_preflow_500_components.pdf/.svg: full-PREFLOW Type/Price/Option/Attribute.
webshop_ablation_500_components.pdf/.svg: the same components for V0/V1/V2.
episodes.csv: one row per unique episode and condition, with source line numbers.
component_summary.csv: CPS, MPS, and component means with their denominators.
preference_set_size.csv: the same metrics in 3, 4, 5, and 6+ preference bins
    (other observed bin sizes are retained). This uses ALL evaluated episodes.
analysis.json: input hashes, deduplication counts, pairing checks, and summaries.
figure_captions.txt: proposed captions with the actual sample sizes.
The filename's episode count changes when --expected-episodes is changed.

Scoring and limitations
-----------------------
* CPS = proportion with the environment's final reward exactly 1; MPS = mean
  final reward. Neither is an unweighted mean of the four component means.
* Components use r_type, r_price, r_option, r_att, not weighted contributions.
* Non-applicable components are excluded, never scored as failures. Applicability
  is checked against the logged goal, which is used only for offline analysis.
* Attribute/option components were logged to THREE decimal places. Their means
  inherit that rounding; the script does not invent unlogged precision. Charts
  display one decimal percentage point. CPS/MPS use the full-precision reward
  line rather than the four-decimal value in [Reward Breakdown].
* Preference count = one type + number of required attributes + number of
  required options + one price ceiling when present. This is a count of the
  benchmark's scored requirements, not a linguistic count of the instruction.
* Timestamped logger and buffered stdout are parsed as separate streams. Their
  duplicate records are merged by episode ID only when they agree. Conflicting,
  incomplete, or concatenated runs stop with an error rather than being averaged.
* Ablation pairing checks both IDs and logged goal metadata. This does not prove
  identical prompts or settings; those must still come from the run configuration.
* No confidence intervals or significance claims are added by these descriptive
  component plots. Existing paired CPS/MPS statistics remain a separate analysis.
* No evidence-count figure is generated, and no manuscript file is edited.
"""

from __future__ import annotations

import argparse
import ast
import csv
import hashlib
import json
import math
import re
import sys
from collections import Counter
from dataclasses import dataclass, field
from pathlib import Path


COMPONENTS = ("Type", "Price", "Option", "Attribute")
PREFIX = re.compile(
    r"\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}[,.]\d+"
    r"\s+-\s+(?:INFO|DEBUG|WARNING|ERROR|CRITICAL)\s+-\s+"
)
START = re.compile(r"^\[Episode\] start (\d+)\s*$")
RESULT = re.compile(r"^episode (\d+), reward ([^,\s]+), term_status\b")
GOAL = re.compile(
    r"^\[Gold Target\] asin=(.*?) \| category=(.*?) \| query=(.*?)"
    r" \| price_upper=(.*?) \| gold_attributes=(.*?) \| gold_options=(.*)$"
)
FIELDS = {
    "Type": r"r_type\(([^)]+)\)",
    "Price": r"\br_price=([^\s|]+)",
    "Option": r"\br_option=([^\s|]+)",
    "Attribute": r"\br_att=([^\s|]+)",
    "reward": r"\breward=([^\s|]+)",
}
NOTES = [
    "All unique evaluated episodes are retained; no 470-task gold-reference filter.",
    "CPS is 100 * mean(final reward == 1); MPS is 100 * mean(final reward).",
    "Component percentages are 100 * mean(applicable component rewards).",
    "Logged attribute/option components have three-decimal precision.",
    "Goal metadata is used for offline applicability, counts, and pairing only.",
    "Descriptive plots contain no new significance tests or confidence intervals.",
]


class LogError(ValueError):
    """An input cannot support a complete, unambiguous analysis."""


@dataclass
class Episode:
    episode_id: int
    values: dict = field(default_factory=dict)
    sources: dict = field(default_factory=dict)

    def add(self, key, value, channel, line, path, stats):
        if key in self.values:
            if self.values[key] != value:
                first = self.sources[key][0]
                raise LogError(
                    f"{path.name}:{line}: conflicting {key} for episode "
                    f"{self.episode_id}; earlier record at line {first['line']}. "
                    "Use a single intact run; do not concatenate different runs."
                )
            stats[f"duplicate_{key}_records_merged"] += 1
        else:
            self.values[key] = value
            self.sources[key] = []
        self.sources[key].append({"stream": channel, "line": line})
        stats[f"{channel}_{key}_records"] += 1


def chunks(line):
    """Recognize logger prefixes even when buffered stdout precedes one midline."""
    matches = list(PREFIX.finditer(line))
    if not matches:
        yield "stdout", line.strip()
        return
    if matches[0].start():
        yield "stdout", line[:matches[0].start()].strip()
    for i, match in enumerate(matches):
        end = matches[i + 1].start() if i + 1 < len(matches) else len(line)
        yield "logger", line[match.end():end].strip()


def number(value, nullable=False):
    if nullable and value.lower() in {"n/a", "none", "null"}:
        return None
    result = float({"True": "1", "False": "0"}.get(value, value))
    if not math.isfinite(result) or not 0 <= result <= 1:
        raise LogError(f"Reward outside [0, 1]: {value!r}")
    return result


def parse_goal(match):
    goal = {
        "asin": match[1],
        "category": ast.literal_eval(match[2]),
        "query": ast.literal_eval(match[3]),
        "price_upper": ast.literal_eval(match[4]),
        "attributes": ast.literal_eval(match[5]),
        "options": ast.literal_eval(match[6]),
    }
    for key in ("attributes", "options"):
        if not isinstance(goal[key], (list, tuple, dict)):
            raise LogError(f"Expected a collection of goal {key}.")
    price = goal["price_upper"]
    if price is not None and (
        not isinstance(price, (int, float)) or not math.isfinite(price) or price < 0
    ):
        raise LogError("Invalid goal price ceiling.")
    return goal


def parse_breakdown(message):
    if "no verbose_info" in message:
        raise LogError(
            "Missing component scores (no verbose_info). Do not replace these "
            "with zero or drop the episode; export the missing evaluator data."
        )
    result = {}
    for key, pattern in FIELDS.items():
        match = re.search(pattern, message)
        if not match:
            raise LogError(f"Incomplete [Reward Breakdown]: missing {key}.")
        result[key] = number(match[1], nullable=key in COMPONENTS)
    return result


def task_hash(goal):
    data = json.dumps(goal, sort_keys=True, ensure_ascii=False).encode("utf-8")
    return hashlib.sha256(data).hexdigest()


def validate_episode(episode, path):
    missing = {"reward", "breakdown", "goal"} - episode.values.keys()
    context = f"{path.name}, episode {episode.episode_id}"
    if missing:
        raise LogError(f"{context}: missing {', '.join(sorted(missing))}.")
    reward = episode.values["reward"]
    breakdown = episode.values["breakdown"]
    if abs(reward - breakdown["reward"]) > 0.00005001:
        raise LogError(f"{context}: final reward and breakdown reward disagree.")
    goal = episode.values["goal"]
    n_attr, n_option = len(goal["attributes"]), len(goal["options"])
    applicable = {
        "Type": True, "Price": goal["price_upper"] is not None,
        "Option": n_option > 0, "Attribute": n_attr > 0,
    }
    components = {}
    for key in COMPONENTS:
        value = breakdown[key]
        if applicable[key] and value is None:
            raise LogError(f"{context}: applicable {key} score is missing.")
        # r_att may be printed as zero when there are no required attributes.
        if not applicable[key] and key != "Attribute" and value is not None:
            raise LogError(f"{context}: {key} applicability conflicts with the goal.")
        components[key] = value if applicable[key] else None
    # Sanity-check the documented WebShop formula using the exact goal counts.
    # A three-decimal rounded component can introduce up to 0.0005 error.
    if applicable["Price"]:
        reconstructed = components["Type"] * (
            (components["Attribute"] or 0) * n_attr
            + (components["Option"] or 0) * n_option + components["Price"]
        ) / (n_attr + n_option + 1)
        if abs(reconstructed - reward) > 0.000501:
            raise LogError(f"{context}: components do not reproduce final reward within rounding tolerance.")
    episode.values["components"] = components
    episode.values["preference_count"] = 1 + n_attr + n_option + int(applicable["Price"])
    episode.values["task_sha256"] = task_hash(goal)


def parse_log(path, expected):
    path = path.expanduser().resolve()
    raw = path.read_bytes()
    episodes, stats = {}, Counter()
    current = {"logger": None, "stdout": None}
    starts_seen = set()
    for lineno, line in enumerate(raw.decode("utf-8-sig").splitlines(), 1):
        for channel, message in chunks(line):
            try:
                if match := START.match(message):
                    current[channel] = int(match[1])
                    start_key = (channel, current[channel])
                    if start_key in starts_seen:
                        raise LogError(
                            f"Episode {current[channel]} restarts in the {channel} stream. "
                            "Use one run rather than concatenated runs."
                        )
                    starts_seen.add(start_key)
                    episodes.setdefault(current[channel], Episode(current[channel]))
                    continue
                if match := RESULT.match(message):
                    episode_id = int(match[1])
                    if current[channel] not in (None, episode_id):
                        raise LogError("Episode start/result IDs disagree within a log stream.")
                    current[channel] = episode_id
                    key, value = "reward", number(match[2])
                elif message.startswith("[Gold Target] asin="):
                    match = GOAL.fullmatch(message)
                    if not match:
                        raise LogError("Incomplete [Gold Target] record.")
                    key, value = "goal", parse_goal(match)
                elif message.startswith("[Reward Breakdown]"):
                    key, value = "breakdown", parse_breakdown(message)
                elif message.startswith("[Episode] end "):
                    current[channel] = None
                    continue
                else:
                    continue
                episode_id = current[channel]
                if episode_id is None:
                    raise LogError(f"Cannot associate {key} with an episode in the {channel} stream.")
                record = episodes.setdefault(episode_id, Episode(episode_id))
                record.add(key, value, channel, lineno, path, stats)
            except (ValueError, SyntaxError, TypeError) as error:
                raise LogError(f"{path.name}:{lineno}: {error}") from error
    if len(episodes) != expected:
        raise LogError(f"{path.name}: expected {expected} unique episodes, found {len(episodes)}.")
    for episode in episodes.values():
        validate_episode(episode, path)
    return {
        "path": str(path), "sha256": hashlib.sha256(raw).hexdigest(),
        "episodes": dict(sorted(episodes.items())), "parser_counts": dict(stats),
    }


def check_pairing(runs):
    reference_name = next(iter(runs))
    reference = runs[reference_name]["episodes"]
    for name, run in runs.items():
        other = run["episodes"]
        if reference.keys() != other.keys():
            raise LogError(f"Episode IDs differ between {reference_name} and {name}.")
        for episode_id in reference:
            a, b = reference[episode_id], other[episode_id]
            if a.values["task_sha256"] != b.values["task_sha256"]:
                raise LogError(f"Goal metadata differs between {reference_name} and {name}, episode {episode_id}.")
    return {"verified": True, "reference": reference_name,
            "conditions": list(runs), "paired_episodes": len(reference),
            "checked": "Episode IDs and complete logged goal metadata"}


def summarize(episodes):
    records = list(episodes)
    n = len(records)
    result = {
        "episodes": n,
        "complete_episodes": sum(e.values["reward"] == 1 for e in records),
        "CPS_percent": 100 * sum(e.values["reward"] == 1 for e in records) / n,
        "MPS_percent": 100 * math.fsum(e.values["reward"] for e in records) / n,
    }
    for component in COMPONENTS:
        values = [e.values["components"][component] for e in records
                  if e.values["components"][component] is not None]
        result[f"{component}_n"] = len(values)
        result[f"{component}_excluded"] = n - len(values)
        result[f"{component}_percent"] = 100 * math.fsum(values) / len(values) if values else None
    return result


def size_breakdown(episodes):
    groups = {}
    for episode in episodes:
        count = episode.values["preference_count"]
        group = "6+" if count >= 6 else str(count)
        groups.setdefault(group, []).append(episode)
    return [{"preference_count_bin": group, **summarize(groups[group])}
            for group in sorted(groups, key=lambda x: int(x.rstrip("+")))]


def write_csv(path, rows):
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def draw_figures(output, summaries, preflow_key, ablation, model, formats):
    try:
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
    except ImportError as error:
        raise LogError("Install matplotlib: python -m pip install matplotlib") from error
    plt.rcParams.update({
        "font.family": "DejaVu Sans", "font.size": 8, "axes.titlesize": 9,
        "axes.labelsize": 8, "xtick.labelsize": 7, "ytick.labelsize": 8,
        "pdf.fonttype": 42, "ps.fonttype": 42, "svg.fonttype": "none",
    })
    blue, grey, light = "#0072B2", "#596775", "#AAB4BC"
    paths = []

    def style(axis):
        axis.set_xlim(0, 103)
        axis.set_xticks([0, 50, 100])
        axis.set_axisbelow(True)
        axis.grid(axis="x", color="#E3E7EB", linewidth=0.6)
        axis.tick_params(axis="both", length=0, pad=4)
        for spine in axis.spines.values():
            spine.set_visible(False)

    def label(axis, row, value, color):
        if value is None:
            axis.text(3, row, "n/a", va="center", fontsize=7)
            return
        inside = value >= 78
        axis.text(value - 3 if inside else value + 3, row, f"{value:.1f}",
                  ha="right" if inside else "left", va="center", fontsize=7,
                  color="white" if inside and color != light else "#202830")

    def save(fig, stem):
        for extension in formats:
            path = output / f"{stem}.{extension}"
            fig.savefig(path, bbox_inches="tight", pad_inches=0.05, dpi=300,
                        facecolor="white")
            paths.append(path.name)
        plt.close(fig)

    full = summaries[preflow_key]
    n = full["episodes"]
    fig, axis = plt.subplots(figsize=(3.55, 2.45))
    values = [full[f"{c}_percent"] for c in COMPONENTS]
    axis.barh(range(4), [v if v is not None else 0 for v in values], height=0.53, color=blue)
    axis.set_yticks(range(4))
    axis.set_yticklabels([f"{c} (n={full[f'{c}_n']})" for c in COMPONENTS])
    axis.set_ylim(3.6, -0.6)
    style(axis)
    for row, value in enumerate(values):
        label(axis, row, value, blue)
    axis.set_xlabel("Preference satisfaction (%)", labelpad=7)
    axis.set_title(f"PREFLOW · {model}\n{n} WebShop instructions", pad=10)
    fig.subplots_adjust(left=0.34, right=0.99, bottom=0.23, top=0.76)
    save(fig, f"webshop_preflow_{n}_components")

    if ablation:
        names = ("V0", "V1", "V2")
        fig, axes = plt.subplots(1, 4, figsize=(7.0, 2.45), sharey=True)
        for column, (axis, component) in enumerate(zip(axes, COMPONENTS)):
            values = [summaries[name][f"{component}_percent"] for name in names]
            counts = [summaries[name][f"{component}_n"] for name in names]
            if len(set(counts)) != 1:
                raise LogError(f"{component}: applicability differs across paired conditions.")
            axis.barh(range(3), [v if v is not None else 0 for v in values],
                      height=0.52, color=[grey, light, blue])
            for row, (value, color) in enumerate(zip(values, [grey, light, blue])):
                label(axis, row, value, color)
            style(axis)
            axis.set_ylim(2.6, -0.6)
            axis.set_yticks(range(3))
            if column == 0:
                axis.set_yticklabels(["V0", "V1", "V2 (PREFLOW)"])
                axis.get_yticklabels()[-1].set_color(blue)
                axis.get_yticklabels()[-1].set_fontweight("bold")
            else:
                axis.tick_params(axis="y", labelleft=False)
            axis.set_title(f"{component}\n(n={counts[0]})", pad=8)
        n = summaries["V2"]["episodes"]
        fig.suptitle(f"Cumulative ablation · {model} · {n} WebShop instructions", y=0.98, fontsize=10)
        fig.text(0.56, 0.04, "Preference satisfaction (%)", ha="center")
        fig.subplots_adjust(left=0.17, right=0.99, bottom=0.21, top=0.69, wspace=0.30)
        save(fig, f"webshop_ablation_{n}_components")
    return paths


def main():
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--logs-dir", type=Path, default=Path("."), help="Directory containing v0_500.log, v1_500.log, v2_500.log.")
    parser.add_argument("--preflow-log", type=Path, help="Alternative full-PREFLOW log; default: LOGS_DIR/v2_500.log.")
    parser.add_argument("--preflow-only", action="store_true", help="Analyze only the full-PREFLOW log.")
    parser.add_argument("--expected-episodes", type=int, default=500)
    parser.add_argument("--output-dir", type=Path, default=Path("webshop_500_analysis"))
    parser.add_argument("--model", default="Gemini-3-Flash", help="Display label; this does not verify the model configuration.")
    parser.add_argument("--formats", nargs="+", choices=("pdf", "svg", "png"), default=["pdf", "svg"])
    mode = parser.add_mutually_exclusive_group()
    mode.add_argument("--validate-only", action="store_true", help="Print checks and scores; write nothing.")
    mode.add_argument("--analysis-only", action="store_true", help="Write analysis and captions, without figures.")
    args = parser.parse_args()
    if args.expected_episodes < 1:
        parser.error("--expected-episodes must be positive")
    try:
        runs = {}
        if not args.preflow_only:
            for name in ("V0", "V1", "V2"):
                runs[name] = parse_log(args.logs_dir / f"{name.lower()}_500.log", args.expected_episodes)
        preflow_path = (args.preflow_log or args.logs_dir / "v2_500.log").expanduser().resolve()
        preflow_key = "V2"
        if args.preflow_only or str(preflow_path) != runs["V2"]["path"]:
            preflow_key = "PREFLOW"
            runs[preflow_key] = parse_log(preflow_path, args.expected_episodes)
        pairing = check_pairing({k: runs[k] for k in ("V0", "V1", "V2")}) if not args.preflow_only else None
        summaries = {name: summarize(run["episodes"].values()) for name, run in runs.items()}
        size_rows = [{"condition": name, **row} for name, run in runs.items()
                     for row in size_breakdown(run["episodes"].values())]
        print("All scores below are percentages. Component means use applicable episodes.")
        print(f"{'Condition':<12} {'N':>4} {'CPS':>7} {'MPS':>7}  " + "  ".join(f"{c:>17}" for c in COMPONENTS))
        for name, summary in summaries.items():
            cells = []
            for component in COMPONENTS:
                value = summary[f"{component}_percent"]
                score = f"{value:.1f}" if value is not None else "n/a"
                cells.append(f"{score} (n={summary[f'{component}_n']})")
            print(f"{name:<12} {summary['episodes']:>4} {summary['CPS_percent']:>7.1f} "
                  f"{summary['MPS_percent']:>7.1f}  " + "  ".join(f"{c:>17}" for c in cells))
        if pairing:
            print(f"Pairing verified: {pairing['paired_episodes']} matching episode IDs and goals across V0/V1/V2.")
        print(f"Full PREFLOW figure source: {runs[preflow_key]['path']}")
        print("Note: attribute/option component means inherit the log's three-decimal rounding.")
        if args.validate_only:
            print("Validation complete. No files or figures written.")
            return 0
        output = args.output_dir.expanduser().resolve()
        output.mkdir(parents=True, exist_ok=True)
        figures = [] if args.analysis_only else draw_figures(
            output, summaries, preflow_key, not args.preflow_only, args.model,
            list(dict.fromkeys(args.formats)),
        )
        write_csv(output / "component_summary.csv", [{"condition": k, **v} for k, v in summaries.items()])
        write_csv(output / "preference_set_size.csv", size_rows)
        episode_rows = []
        for name, run in runs.items():
            for episode in run["episodes"].values():
                data, goal = episode.values, episode.values["goal"]
                episode_rows.append({
                    "condition": name, "episode_id": episode.episode_id,
                    "task_sha256": data["task_sha256"], "preference_count": data["preference_count"],
                    "attribute_count": len(goal["attributes"]), "option_count": len(goal["options"]),
                    "final_reward": data["reward"], "complete": int(data["reward"] == 1),
                    **{f"{c}_reward": data["components"][c] for c in COMPONENTS},
                    **{f"{key}_source_lines": ";".join(f"{s['stream']}:{s['line']}" for s in sources)
                       for key, sources in sorted(episode.sources.items())},
                })
        write_csv(output / "episodes.csv", episode_rows)
        report = {
            "schema_version": 1, "model_label": args.model, "full_preflow_condition": preflow_key,
            "notes": NOTES, "ablation_pairing": pairing, "summaries": summaries,
            "preference_set_size": size_rows, "figures": figures,
            "sources": {name: {k: v for k, v in run.items() if k != "episodes"}
                        for name, run in runs.items()},
        }
        (output / "analysis.json").write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
        full = summaries[preflow_key]
        denominators = "; ".join(f"{c}: n={full[f'{c}_n']}" for c in COMPONENTS)
        captions = [
            f"Full PREFLOW: Per-preference satisfaction over all {full['episodes']} WebShop instructions "
            f"with {args.model}. {denominators}. Non-applicable components are excluded from their "
            "respective means. These are environment reward components, not internal verification counts.",
            "Component values inherit the three-decimal precision of the attribute/option scores in "
            "the logs. Error bars are not shown; the plots summarize one run per condition.",
            "The accompanying preference_set_size.csv uses all evaluated instructions. It does not "
            "reproduce or apply the manuscript's 470-instruction gold-reference filter.",
        ]
        if not args.preflow_only:
            summary = summaries["V2"]
            counts = "; ".join(f"{c}: n={summary[f'{c}_n']} per condition" for c in COMPONENTS)
            captions.insert(1,
                f"Cumulative ablation: Per-preference satisfaction on the same {summary['episodes']} "
                f"WebShop instructions with {args.model}. V0: Executive Controller only; V1: jointly "
                "adds the typed plan, Evidence Ledger, bounded candidate acquisition, preference-aware "
                "option handling, and recovery logic; V2: adds the Commit Verifier and is full PREFLOW. "
                f"{counts}. Non-applicable components are excluded. The cumulative contrasts do not "
                "isolate the individual mechanisms added together in V1."
            )
        (output / "figure_captions.txt").write_text("\n\n".join(captions) + "\n", encoding="utf-8")
        print(f"Wrote analysis to {output}")
        print("Figures: " + ", ".join(figures) if figures else "No figures generated (--analysis-only).")
        return 0
    except (OSError, UnicodeError, LogError) as error:
        print(f"ERROR: {error}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
