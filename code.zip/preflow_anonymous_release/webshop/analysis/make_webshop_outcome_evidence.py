#!/usr/bin/env python3
import argparse, json
from pathlib import Path
import matplotlib.pyplot as plt

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--summary", default="webshop_metrics_summary.json")
    ap.add_argument("--output", default="webshop_outcome_evidence")
    args = ap.parse_args()

    with open(args.summary, "r", encoding="utf-8") as f:
        d = json.load(f)

    ev = d["v2_evidence_at_commit"]
    n = d["validation"]["v2_episodes"]

    correct_fv = ev["correct_and_fully_verified_count"]
    correct_not_fv = ev["correct_but_not_fully_verified_count"]
    fv_total = ev["fully_verified_commits_count"]
    incorrect_fv = fv_total - correct_fv
    incorrect_not_fv = n - correct_fv - correct_not_fv - incorrect_fv

    counts = [correct_fv, correct_not_fv, incorrect_fv, incorrect_not_fv]
    labels = [
        "Complete +\nfully verified",
        "Complete +\nnot fully verified",
        "Incomplete +\nfully verified",
        "Incomplete +\nnot fully verified",
    ]
    pcts = [100 * x / n for x in counts]

    fig, ax = plt.subplots(figsize=(6.8, 3.2))
    bars = ax.bar(labels, pcts)
    for bar, count, pct in zip(bars, counts, pcts):
        ax.text(bar.get_x() + bar.get_width()/2, bar.get_height(),
                f"{count}\n({pct:.1f}%)", ha="center", va="bottom", fontsize=9)

    ax.set_ylabel("Tasks (%)")
    ax.set_ylim(0, max(pcts) * 1.22)
    ax.set_title(f"WebShop: outcome and evidence at commitment (n={n})")
    fig.tight_layout()

    pdf = Path(args.output + ".pdf")
    png = Path(args.output + ".png")
    fig.savefig(pdf, bbox_inches="tight")
    fig.savefig(png, dpi=300, bbox_inches="tight")
    print("Counts:", counts)
    print("Wrote", pdf)
    print("Wrote", png)

if __name__ == "__main__":
    main()
