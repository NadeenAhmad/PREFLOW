"""Opt-in, cross-process spending reservations for text-only OpenRouter calls.

Amounts are integer microdollars. Reservations are committed *before* network I/O;
unknown failures and interrupted processes retain their entire reservation. The
ledger is an admission guard, not a provider billing limit: configure an API-key
credit limit too when an absolute external billing cap is required.
"""
from __future__ import annotations

import json
import sqlite3
import uuid
from contextlib import contextmanager
from decimal import Decimal, ROUND_CEILING, ROUND_FLOOR
from pathlib import Path
from typing import Any


class BudgetError(RuntimeError):
    """Non-retryable spending-control failure."""


class BudgetExceeded(BudgetError):
    """The next request cannot fit within its reserved spending envelope."""


class BudgetAccountingError(BudgetError):
    """Billing data or budget settings are unsafe or inconsistent."""


def _decimal(value: Any) -> Decimal:
    try:
        number = Decimal(str(value))
    except Exception as exc:
        raise BudgetAccountingError("Invalid budget amount") from exc
    if not number.is_finite() or number < 0:
        raise BudgetAccountingError("Budget amounts must be finite and nonnegative")
    return number


def _microdollars(value: Any) -> int:
    return int((_decimal(value) * 1_000_000).to_integral_value(rounding=ROUND_CEILING))


class BudgetLedger:
    """Persistent shared total and per-stage caps; config is immutable on resume."""

    def __init__(self, config: dict[str, Any]):
        self.path = Path(config["ledger_path"]).expanduser().resolve()
        self.stage = str(config["stage"])
        self.total_limit = int((_decimal(config["total_limit_usd"]) * 1_000_000).to_integral_value(rounding=ROUND_FLOOR))
        self.stage_limit = int((_decimal(config["stage_limit_usd"]) * 1_000_000).to_integral_value(rounding=ROUND_FLOOR))
        self.input_rate = _decimal(config["input_usd_per_million"])
        self.output_rate = _decimal(config["output_usd_per_million"])
        if not self.stage or not 0 < self.stage_limit <= self.total_limit:
            raise BudgetAccountingError("Require a stage and 0 < stage cap <= total cap")
        if not self.input_rate or not self.output_rate:
            raise BudgetAccountingError("Explicit positive input and output prices are required")
        self.path.parent.mkdir(parents=True, exist_ok=True)
        with self._connect() as db:
            db.execute("BEGIN IMMEDIATE")
            db.execute("CREATE TABLE IF NOT EXISTS metadata (key TEXT PRIMARY KEY, value TEXT NOT NULL)")
            db.execute("CREATE TABLE IF NOT EXISTS stages (name TEXT PRIMARY KEY, cap INTEGER NOT NULL)")
            db.execute("""CREATE TABLE IF NOT EXISTS requests (
                id TEXT PRIMARY KEY, stage TEXT NOT NULL, model TEXT NOT NULL,
                reserved INTEGER NOT NULL, charged INTEGER NOT NULL,
                status TEXT NOT NULL, created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                detail TEXT NOT NULL DEFAULT '')""")
            prior = db.execute("SELECT value FROM metadata WHERE key='total_limit'").fetchone()
            if prior and int(prior[0]) != self.total_limit:
                raise BudgetAccountingError("Global budget differs from existing ledger; do not reset its cap")
            db.execute("INSERT OR IGNORE INTO metadata VALUES ('total_limit', ?)", (str(self.total_limit),))
            prior_stage = db.execute("SELECT cap FROM stages WHERE name=?", (self.stage,)).fetchone()
            if prior_stage and prior_stage[0] != self.stage_limit:
                raise BudgetAccountingError("Stage budget differs from existing ledger")
            db.execute("INSERT OR IGNORE INTO stages VALUES (?, ?)", (self.stage, self.stage_limit))

    @contextmanager
    def _connect(self):
        db = sqlite3.connect(self.path, timeout=30)
        try:
            db.execute("PRAGMA busy_timeout=30000")
            db.execute("PRAGMA synchronous=FULL")
            with db:
                yield db
        finally:
            db.close()

    def estimate_request(self, messages: list[dict], tools: list[dict] | None,
                         max_tokens: int) -> int:
        if not isinstance(max_tokens, int) or isinstance(max_tokens, bool) or max_tokens <= 0:
            raise BudgetAccountingError("An explicit positive max_tokens is required")
        if any(not isinstance(m.get("content"), (str, type(None))) for m in messages):
            raise BudgetAccountingError("Budgeted client supports text-only content")
        if any(t.get("type") != "function" for t in (tools or [])):
            raise BudgetAccountingError("Budgeted client permits only locally executed function tools")
        # UTF-8 bytes dominate byte-tokenizers' token count; extra room covers
        # provider role delimiters, schema framing and JSON mode instructions.
        payload = json.dumps({"messages": messages, "tools": tools}, ensure_ascii=False)
        input_upper = len(payload.encode("utf-8")) + 4096 + 64 * (len(messages) + len(tools or []))
        # Providers can report a few tokens past max_tokens at a stop boundary.
        return self.token_cost(input_upper, max_tokens + 256)

    def token_cost(self, input_tokens: int, output_tokens: int) -> int:
        # $/million tokens equals microdollars/token. Completion tokens already
        # include reasoning tokens; never add reasoning a second time.
        value = Decimal(input_tokens) * self.input_rate + Decimal(output_tokens) * self.output_rate
        return int(value.to_integral_value(rounding=ROUND_CEILING))

    def reserve(self, amount_microdollars: int, model: str = "") -> str:
        if not isinstance(amount_microdollars, int) or amount_microdollars <= 0:
            raise BudgetAccountingError("Reservation must be positive integer microdollars")
        request_id = uuid.uuid4().hex
        with self._connect() as db:
            db.execute("BEGIN IMMEDIATE")
            violation = db.execute("SELECT value FROM metadata WHERE key='halted'").fetchone()
            if violation:
                raise BudgetAccountingError("Ledger halted after an accounting failure")
            total = db.execute("SELECT COALESCE(SUM(charged),0) FROM requests").fetchone()[0]
            stage = db.execute("SELECT COALESCE(SUM(charged),0) FROM requests WHERE stage=?", (self.stage,)).fetchone()[0]
            if total + amount_microdollars > self.total_limit or stage + amount_microdollars > self.stage_limit:
                raise BudgetExceeded(
                    f"Budget cannot reserve ${amount_microdollars / 1e6:.6f}; "
                    f"total committed ${total / 1e6:.6f}/${self.total_limit / 1e6:.2f}, "
                    f"stage {self.stage} ${stage / 1e6:.6f}/${self.stage_limit / 1e6:.2f}"
                )
            db.execute("INSERT INTO requests (id,stage,model,reserved,charged,status) VALUES (?,?,?,?,?,'reserved')",
                       (request_id, self.stage, model, amount_microdollars, amount_microdollars))
        return request_id

    def uncertain(self, request_id: str, detail: str = "unknown request outcome") -> None:
        # Detail must be a classification, never an exception body containing
        # remote response data, credentials, prompts or products.
        with self._connect() as db:
            db.execute("UPDATE requests SET status='uncertain',detail=? WHERE id=? AND status='reserved'",
                       (detail[:120], request_id))

    def settle(self, request_id: str, message: dict[str, Any]) -> None:
        input_tokens = message.get("input_tokens")
        output_tokens = message.get("output_tokens")
        if (not message.get("_budget_usage_present") or
                any(not isinstance(n, int) or isinstance(n, bool) or n < 0
                    for n in (input_tokens, output_tokens))):
            self.uncertain(request_id, "missing or invalid usage")
            raise BudgetAccountingError("Missing provider usage; reservation retained")
        reported_cost = message.get("_budget_cost_usd")
        try:
            charge = (_microdollars(reported_cost) if reported_cost is not None
                      else self.token_cost(input_tokens, output_tokens))
        except BudgetAccountingError:
            self.uncertain(request_id, "invalid provider cost")
            raise
        overrun = False
        with self._connect() as db:
            db.execute("BEGIN IMMEDIATE")
            row = db.execute("SELECT reserved,status FROM requests WHERE id=?", (request_id,)).fetchone()
            if not row or row[1] != "reserved":
                raise BudgetAccountingError("Cannot settle an absent or previously finalized reservation")
            overrun = charge > row[0]
            db.execute("UPDATE requests SET charged=?,status=?,detail=? WHERE id=?",
                       (charge, "overrun" if overrun else "settled", "provider usage", request_id))
            if overrun:
                db.execute("INSERT OR REPLACE INTO metadata VALUES ('halted','reservation overrun')")
        if overrun:
            raise BudgetAccountingError("Provider cost exceeded its reservation; ledger halted")

    def snapshot(self) -> dict[str, Any]:
        with self._connect() as db:
            rows = db.execute("SELECT stage,status,COUNT(*),SUM(charged) FROM requests GROUP BY stage,status").fetchall()
            limits = dict(db.execute("SELECT name,cap FROM stages").fetchall())
            halted = bool(db.execute("SELECT value FROM metadata WHERE key='halted'").fetchone())
        stages = {name: {"limit_usd": cap / 1e6, "committed_usd": 0.0,
                         "settled_usd": 0.0, "reserved_or_uncertain_usd": 0.0, "requests": 0}
                  for name, cap in limits.items()}
        committed = 0
        for stage, status, count, amount in rows:
            committed += amount
            stages[stage]["committed_usd"] += amount / 1e6
            stages[stage]["requests"] += count
            field = "settled_usd" if status in ("settled", "overrun") else "reserved_or_uncertain_usd"
            stages[stage][field] += amount / 1e6
        return {"ledger_path": str(self.path), "limit_usd": self.total_limit / 1e6,
                "committed_usd": committed / 1e6, "remaining_usd": (self.total_limit - committed) / 1e6,
                "halted": halted, "stages": stages}
