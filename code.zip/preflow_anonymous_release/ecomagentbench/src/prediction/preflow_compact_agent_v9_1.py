"""PREFLOW compact v9.1 = v9 + JSON-parsing robustness. NEW file; v9 is not modified.

What changes: only how the model's JSON answer is read back.
  1. The request is byte-identical to v9 (same messages, json_mode, max_tokens; same 4-call budget).
  2. The ORIGINAL parser (src/llm/utils.parse_json_text) runs first. Whenever it succeeds, the
     result is identical to v9.
  3. Only if it fails (e.g. Gemini returned the JSON object twice -> "Extra data"), the first
     complete JSON object in the reply is used.
  4. If the reply still contains no JSON object, the same request is sent once more (the benchmark
     harness retries malformed JSON by default). This retry does not count toward PREFLOW's 4
     logical calls. It does count in the recorded API usage.

No prompt, retrieval, clarification, verification or selection logic changes, and no benchmark
targets, rubrics or hidden fields are read.
"""
from __future__ import annotations

import json
import logging
from typing import Any

from src.llm.utils import parse_json_text
from src.prediction.preflow_compact_agent_v9 import CompactPreflowShoppingAgent

logger = logging.getLogger(__name__)
_DECODER = json.JSONDecoder()
LAST_RUN_STATS = {"json_recoveries": 0, "json_retries": 0}  # read by the v9.1 runner (sequential)


def first_json_object(text: str) -> dict[str, Any] | None:
    """Return the first complete JSON object in ``text``, or None."""
    text = text or ""
    pos = text.find("{")
    tries = 0
    while pos != -1 and tries < 50:
        try:
            obj, _ = _DECODER.raw_decode(text, pos)
            if isinstance(obj, dict):
                return obj
        except json.JSONDecodeError:
            pass
        pos = text.find("{", pos + 1)
        tries += 1
    return None


class CompactPreflowShoppingAgentV91(CompactPreflowShoppingAgent):
    json_recoveries = 0
    json_retries = 0

    def _json_call(self, system: str, user: str, max_tokens: int) -> dict[str, Any]:
        if self._model_calls >= self.max_model_calls:
            raise RuntimeError("PREFLOW compact model-call budget exhausted")
        self._model_calls += 1
        messages = [{"role": "system", "content": system}, {"role": "user", "content": user}]
        last_exc: Exception | None = None
        for attempt in range(2):
            # Same request chat_json() would send: no tools, json_mode=True, same max_tokens.
            msg = self.llm.chat(messages, tools=None, json_mode=True, max_tokens=max_tokens)
            content = msg.get("content", "") or ""
            if msg.get("tool_calls"):
                last_exc = ValueError("JSON mode received unexpected tool calls")
                continue
            try:
                result = parse_json_text(content)          # original v9 behaviour
            except Exception as exc:                     # noqa: BLE001
                result = first_json_object(content)
                if result is None:
                    last_exc = exc
                    logger.warning("Malformed JSON from model (attempt %d/2): %s", attempt + 1, exc)
                    if attempt == 0:
                        self.json_retries += 1
                    continue
                self.json_recoveries += 1
                logger.warning("Recovered first JSON object after parser error: %s", exc)
            result["input_tokens"] = msg.get("input_tokens", 0)
            result["thinking_tokens"] = msg.get("thinking_tokens", 0)
            result["output_tokens"] = msg.get("output_tokens", 0)
            return result
        assert last_exc is not None
        raise last_exc

    def run(self, sample: dict) -> dict:
        self.json_recoveries = 0
        self.json_retries = 0
        LAST_RUN_STATS.update(json_recoveries=0, json_retries=0)
        try:
            return super().run(sample)
        finally:
            LAST_RUN_STATS.update(json_recoveries=self.json_recoveries, json_retries=self.json_retries)


__all__ = ["CompactPreflowShoppingAgentV91", "first_json_object"]
