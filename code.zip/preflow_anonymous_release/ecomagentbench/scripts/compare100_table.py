"""Paired PREFLOW vs benchmark-agent comparison on the fixed compare100 test sample.

No API calls. Accuracy = exact target or every rubric satisfied (official definition).
Tasks without a recommendation count as incorrect. Gemini PREFLOW rows come from the
frozen v11 full-662 run; each comparison uses only tasks both agents completed.
"""
import json
import math
import sqlite3
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
C = ROOT / 'results/compare100'


def rows(path):
    out = {}
    if Path(path).exists():
        for line in open(path):
            if line.strip():
                r = json.loads(line)
                out[r['id']] = r
    return out


def mcnemar(b, c):
    """Exact two-sided McNemar p-value from discordant counts."""
    n = b + c
    if n == 0:
        return 1.0
    k = min(b, c)
    p = sum(math.comb(n, i) for i in range(k + 1)) / 2 ** n
    return min(1.0, 2 * p)


bench = rows(ROOT / 'data/benchmark/benchmark.jsonl')
ids = json.load(open(ROOT / 'configs/compare100_test_seed20261019.json'))['sample_ids']
ledger = sqlite3.connect(C / 'spend.sqlite3')
stage_cost = dict(ledger.execute('SELECT stage, SUM(charged)/1e6 FROM requests GROUP BY stage'))

systems = {
    ('gemini', 'PREFLOW'): (ROOT / 'results/budget22/predictions.jsonl', C / 'judge_preflow_gemini/judgments.jsonl', None),
    ('gemini', 'Benchmark agent'): (C / 'paper_agent_gemini/predictions.jsonl', C / 'judge_paper_agent_gemini_final/judgments.jsonl', 'paper_agent_gemini'),
    ('deepseek', 'PREFLOW'): (C / 'preflow_deepseek/predictions.jsonl', C / 'judge_preflow_deepseek/judgments.jsonl', 'preflow_deepseek'),
    ('deepseek', 'Benchmark agent'): (C / 'paper_agent_deepseek/predictions.jsonl', C / 'judge_paper_agent_deepseek/judgments.jsonl', 'paper_agent_deepseek'),
    ('qwen', 'PREFLOW'): (C / 'preflow_qwen/predictions.jsonl', C / 'judge_preflow_qwen/judgments.jsonl', 'preflow_qwen'),
    ('qwen', 'Benchmark agent'): (C / 'paper_agent_qwen/predictions.jsonl', C / 'judge_paper_agent_qwen/judgments.jsonl', 'paper_agent_qwen'),
}


def outcome(pred, judg, sid):
    pid = pred.get('predicted_product_id')
    if pid and pid == bench[sid]['target_product']['product_id']:
        return True
    if sid in judg:
        return bool(judg[sid].get('all_satisfied'))
    return None  # not yet judged


def satisfaction(judg, common):
    """Share of satisfied rubrics, overall and by source; None until every task is judged."""
    if any(s not in judg for s in common):
        return None
    ok, tot = {}, {}
    for s in common:
        for r in judg[s]['rubric_results']:
            for key in ('overall', r.get('info_source')):
                tot[key] = tot.get(key, 0) + 1
                ok[key] = ok.get(key, 0) + bool(r['satisfied'])
    return {k: 100 * ok[k] / tot[k] for k in tot}


def calls(pred):
    if 'baseline_meta' in pred:
        return pred['baseline_meta'].get('api_attempts') or pred['baseline_meta'].get('steps_used', 0)
    return pred.get('pilot_task_usage', {}).get('api_requests') or pred.get('model_calls', 0)


def finished(pred):
    if 'baseline_meta' in pred:
        return pred['baseline_meta'].get('stop_reason') == 'recommend_product' and bool(pred.get('predicted_product_id'))
    return bool(pred.get('finished'))


print('| LLM | Agent | Tasks | Accuracy (%) | Overall (%) | Instruction (%) | Profile (%) | Clarification (%) | Finish (%) | Model calls/task | Cost/task (USD) | Paired: PREFLOW-only / benchmark-only correct | McNemar p |')
print('|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---|---:|')
for llm in ('gemini', 'deepseek', 'qwen'):
    loaded = {agent: (rows(p), rows(j), st) for (l, agent), (p, j, st) in systems.items() if l == llm}
    if llm == 'deepseek':  # second process ran the last 40 tasks; keep the first copy of any overlap
        pred, judg, st = loaded['Benchmark agent']
        tail = rows(C / 'paper_agent_deepseek_tail/predictions.jsonl')
        loaded['Benchmark agent'] = ({**tail, **pred}, judg, st)
    pf, bm = loaded['PREFLOW'][0], loaded['Benchmark agent'][0]
    common = [s for s in ids if s in pf and s in bm]
    res = {}
    for agent, (pred, judg, stage) in loaded.items():
        out = [outcome(pred[s], judg, s) for s in common]
        pending = sum(o is None for o in out)
        acc = 100 * sum(bool(o) for o in out) / max(1, len(common))
        fin = 100 * sum(finished(pred[s]) for s in common) / max(1, len(common))
        mc = sum(calls(pred[s]) for s in common) / max(1, len(common))
        if stage:
            cost = stage_cost.get(stage, 0) / max(1, len(pred))
        else:  # frozen v11 Gemini PREFLOW: list-price token cost of these tasks
            cost = sum(pred[s]['pilot_task_usage']['input_tokens'] * 0.5e-6 + pred[s]['pilot_task_usage']['output_tokens'] * 3e-6
                       for s in common) / max(1, len(common))
        res[agent] = out
        res[agent + '_row'] = (len(common), acc, fin, mc, cost, pending, satisfaction(judg, common))
    b = sum(1 for x, y in zip(res['PREFLOW'], res['Benchmark agent']) if x and not y)
    c = sum(1 for x, y in zip(res['PREFLOW'], res['Benchmark agent']) if y and not x)
    for agent in ('Benchmark agent', 'PREFLOW'):
        n, acc, fin, mc, cost, pending, sat = res[agent + '_row']
        sats = ' | '.join(f'{sat[k]:.1f}' if sat and k in sat else '…' for k in ('overall', 'query', 'persona', 'clarification'))
        note = f' ({pending} pending)' if pending else ''
        pair = f'{b} / {c}' if agent == 'PREFLOW' else ''
        pv = f'{mcnemar(b, c):.3f}' if agent == 'PREFLOW' else ''
        print(f'| {llm} | {agent} | {n} | {acc:.1f}{note} | {sats} | {fin:.1f} | {mc:.1f} | {cost:.4f} | {pair} | {pv} |')
