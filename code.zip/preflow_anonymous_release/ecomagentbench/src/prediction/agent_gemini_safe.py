"""The paper's ShoppingAgent with one transport-level change for Gemini 3.

NEW file. src/prediction/agent.py is not modified.

Everything here is a line-for-line copy of ShoppingAgent.run() (same system
prompt, tools, step budget, reminders, one-action-per-turn policy and output
fields) except for ONE branch: what is replayed to the model after it emits
more than one tool call in a single turn.

Original agent.py
    Drops tool calls 2..n from the assistant message, replays only call 1 plus
    its result, then adds the "only one tool call is allowed" reminder.

This variant
    Replays the assistant message exactly as returned (all n calls plus its
    reasoning_details), executes ONLY call 1 as before, answers calls 2..n with
    a "not executed" tool result, then adds the same reminder.

Why: Gemini 3 binds thought signatures to the full model turn and expects a
function response for every function call in it. Editing the turn before
replay risks HTTP 400 "thought signature" errors, which would turn into
infrastructure failures rather than agent outcomes. The model still learns
exactly what the original tells it: only the first call ran, and multi-call
turns are not allowed. Single-call turns, by far the common case, are
byte-identical to the original agent. The number of affected turns is
reported per task as ``multi_tool_turns`` so it can be disclosed.
"""

import json
import logging

from src.prediction.agent import (
    ShoppingAgent,
    _MULTI_TOOL_CALL_REMINDER,
    _TOOL_REMINDER,
    _assistant_message_for_trajectory,
)
from src.prompts.agent import SYSTEM_PROMPT
from src.tools import create_tools, get_all_schemas

logger = logging.getLogger(__name__)

_NOT_EXECUTED_RESULT = {
    "error": (
        "Not executed: only one tool call is allowed per assistant turn, "
        "so only the first tool call in this turn was run."
    )
}


class GeminiSafeShoppingAgent(ShoppingAgent):
    """ShoppingAgent that never edits a model turn before replaying it."""

    def run(self, sample: dict, system_prompt: str | None = None) -> dict:
        tools = create_tools(
            self.db,
            sample_data=sample,
        )
        tool_schemas = get_all_schemas(tools)

        user_query = sample["user_query"]
        messages = [
            {"role": "system", "content": system_prompt or SYSTEM_PROMPT},
            {"role": "user", "content": user_query},
        ]
        llm_messages = list(messages)
        trajectory_messages = list(messages)

        total_tool_calls = 0
        ask_user_calls = 0
        get_profile_calls = 0
        predicted_id = None
        reasoning = ""
        reasoning_trace = []
        finished = False
        no_tool_corrections = 0
        # --- added bookkeeping (does not affect behaviour) ---
        steps_used = 0
        multi_tool_turns = 0
        stop_reason = "max_steps_exhausted"

        for step in range(self.max_steps):
            logger.info("Step %d/%d", step + 1, self.max_steps)
            steps_used = step + 1

            assistant_msg = self.llm.chat(llm_messages, tools=tool_schemas)
            step_reasoning = []
            for entry in assistant_msg.get("reasoning_trace", []) or []:
                enriched_entry = dict(entry)
                enriched_entry.setdefault("step", step + 1)
                step_reasoning.append(enriched_entry)
                reasoning_trace.append(enriched_entry)
            trajectory_messages.append(
                _assistant_message_for_trajectory(assistant_msg, step_reasoning or None)
            )

            tool_calls = assistant_msg.get("tool_calls")
            if not tool_calls:
                llm_messages.append(assistant_msg)
                if no_tool_corrections < 1:
                    logger.info("No tool calls; prompting for tool use")
                    no_tool_corrections += 1
                    reminder_msg = {"role": "user", "content": _TOOL_REMINDER}
                    llm_messages.append(reminder_msg)
                    trajectory_messages.append(reminder_msg)
                    continue
                logger.info("No tool calls after reminder, agent finished")
                reasoning = assistant_msg.get("content", "") or reasoning
                finished = True
                stop_reason = "no_tool_after_reminder"
                break

            no_tool_corrections = 0
            multi_tool_call_violation = False
            extra_tool_calls = []
            if len(tool_calls) > 1:
                logger.warning("Multiple tool calls; only first will run")
                extra_tool_calls = list(tool_calls[1:])
                tool_calls = [tool_calls[0]]
                multi_tool_call_violation = True
                multi_tool_turns += 1
            # COMPAT CHANGE 1/2: replay the model turn unedited (all tool calls,
            # reasoning_details). The original replays only tool_calls[0].
            llm_messages.append(dict(assistant_msg))

            for tc in tool_calls:
                total_tool_calls += 1
                func_name = tc["function"]["name"]
                try:
                    func_args = json.loads(tc["function"]["arguments"])
                except json.JSONDecodeError as exc:
                    result = {"error": f"Invalid tool arguments JSON: {exc}"}
                    tool_msg = {
                        "role": "tool",
                        "tool_call_id": tc.get("call_id", tc["id"]),
                        "content": json.dumps(result, ensure_ascii=False),
                    }
                    llm_messages.append(tool_msg)
                    trajectory_messages.append(tool_msg)
                    continue

                logger.info("Tool call: %s(%s)", func_name, json.dumps(func_args, ensure_ascii=False)[:200])

                if func_name == "ask_user":
                    ask_user_calls += 1
                elif func_name == "get_user_profile":
                    get_profile_calls += 1

                tool = tools.get(func_name)
                if not tool:
                    result = {"error": f"Unknown tool: {func_name}"}
                else:
                    try:
                        result = tool.call(func_args)
                    except Exception as exc:
                        logger.warning("Tool %s raised: %s", func_name, exc)
                        result = {"error": f"Tool call failed: {exc}"}

                if func_name == "recommend_product":
                    pid = func_args.get("product_id", "")
                    if pid and self.db.get_product(pid):
                        predicted_id = pid
                    reasoning = func_args.get("reasoning", "")
                    finished = True
                    stop_reason = "recommend_product" if predicted_id else "recommend_product_unknown_id"

                tool_msg = {
                    "role": "tool",
                    "tool_call_id": tc.get("call_id", tc["id"]),
                    "content": json.dumps(result, ensure_ascii=False),
                }
                llm_messages.append(tool_msg)
                trajectory_messages.append(tool_msg)

            # COMPAT CHANGE 2/2: every replayed function call gets a response.
            for extra_tc in extra_tool_calls:
                stub_msg = {
                    "role": "tool",
                    "tool_call_id": extra_tc.get("call_id", extra_tc.get("id", "")),
                    "content": json.dumps(_NOT_EXECUTED_RESULT, ensure_ascii=False),
                }
                llm_messages.append(stub_msg)
                trajectory_messages.append(stub_msg)

            if multi_tool_call_violation:
                reminder_msg = {"role": "user", "content": _MULTI_TOOL_CALL_REMINDER}
                llm_messages.append(reminder_msg)
                trajectory_messages.append(reminder_msg)

            if finished:
                break

        return {
            "predicted_product_id": predicted_id,
            "reasoning": reasoning,
            "trajectory": trajectory_messages,
            "reasoning_trace": reasoning_trace,
            "total_tool_calls": total_tool_calls,
            "ask_user_calls": ask_user_calls,
            "get_profile_calls": get_profile_calls,
            "finished": finished,
            # added diagnostics
            "steps_used": steps_used,
            "multi_tool_turns": multi_tool_turns,
            "stop_reason": stop_reason,
        }


__all__ = ["GeminiSafeShoppingAgent"]
